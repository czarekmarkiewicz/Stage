# Gdzie z dzieckiem v1.9.0

Poprawki Android:
- poprawiono wysokość i typografię żółtego banera, żeby tekst się nie ucinał;
- dodano natywną historię WebView dla linków wewnątrz strony;
- systemowy Wstecz cofa po ścieżce użytkownika w WebView;
- z ostatniej strony WWW systemowy Wstecz wraca do natywnego ekranu Start;
- na ekranie Start systemowy Wstecz pokazuje komunikat: „Aby wyjść z aplikacji, naciśnij wstecz jeszcze raz”;
- linki wewnętrzne w stronie są przejmowane przez natywną nawigację i pokazują ekran Ładowanie zamiast białego ekranu;
- doprecyzowano wykrywanie linków wewnętrznych domeny gdziezdzieckiem.eu.
