# Gdzie z dzieckiem — release notes v1.1

## Cel wersji

Wersja v1.1 zmienia aplikację z prostej pseudo-przeglądarki WebView w bardziej aplikacyjne doświadczenie mobilne. Dodano własny ekran startowy, dolną nawigację, lokalne Ulubione, lokalną historię Ostatnio oglądanych miejsc, natywne udostępnianie oraz dopracowany tryb offline.

Zmiany są przygotowane wspólnie dla Androida i iOS, z wykorzystaniem wspólnej warstwy aplikacyjnej oraz natywnych poprawek platformowych.

## Najważniejsze zmiany dla użytkownika

### 1. Nowy ekran startowy aplikacji

Dodano własny ekran startowy aplikacji w stylu mobilnego dashboardu. Ekran startowy zawiera:

- logo aplikacji w lewym górnym rogu,
- duży żółty baner w kolorze marki `#f8c401`,
- sekcję „Szybkie akcje”,
- duży przycisk „Wyszukaj na mapie”,
- kafelki „Na powietrzu”, „Pod dachem”, „Superblog” i „Dodaj miejsce”,
- sekcję „Ulubione”,
- sekcję „Ostatnio oglądane”.

Nowy ekran startowy ładuje się w aplikacji i nie wygląda jak zwykła otwarta strona internetowa.

### 2. Dolna nawigacja

Dodano dolną nawigację aplikacji. Nawigacja jest dostępna w aplikacji i prowadzi do głównych sekcji:

- Start,
- Mapa,
- Blog,
- Ulubione,
- Więcej.

Usunięto pozycję „Profil”.

### 3. Ulubione zapisywane lokalnie

Aplikacja umożliwia lokalne zapisywanie ulubionych atrakcji. Funkcja działa bez logowania i bez wysyłania danych na serwer.

Serduszko pojawia się tylko wtedy, gdy użytkownik ogląda konkretną atrakcję. Po kliknięciu:

- puste serce dodaje miejsce do Ulubionych,
- pełne czerwone serce usuwa miejsce z Ulubionych.

Dane zapisywane lokalnie:

- ID atrakcji,
- nazwa atrakcji,
- adres URL,
- zdjęcie,
- miasto,
- data dodania.

Na ekranie startowym wyświetlane są ostatnie zapisane ulubione miejsca. Pełna lista jest dostępna w zakładce „Ulubione”.

### 4. Ostatnio oglądane

Dodano lokalną historię ostatnio oglądanych atrakcji. Aplikacja zapisuje maksymalnie 10 ostatnio oglądanych miejsc.

Na ekranie startowym sekcja „Ostatnio oglądane” znajduje się pod sekcją „Ulubione”. W nagłówku zamiast „Zobacz wszystkie” znajduje się przycisk „Więcej”.

Na kartach ostatnio oglądanych miejsc pokazujemy:

- zdjęcie,
- nazwę atrakcji,
- miasto.

Nie pokazujemy kategorii.

Jeśli użytkownik otworzy tę samą atrakcję ponownie, aplikacja nie tworzy duplikatu, tylko przesuwa tę atrakcję na początek listy.

### 5. Dane atrakcji z `gzd-place-data`

Aplikacja korzysta z danych osadzonych na stronie atrakcji w formacie:

```html
<script type="application/json" id="gzd-place-data">...</script>
```

Dzięki temu aplikacja może odczytać:

- tytuł atrakcji,
- URL,
- zdjęcie z galerii,
- miasto,
- kategorię,
- ID wpisu.

Ten sam mechanizm zasila zarówno „Ulubione”, jak i „Ostatnio oglądane”.

### 6. Natywne udostępnianie

Na stronie konkretnej atrakcji aplikacja pokazuje przycisk udostępniania obok serduszka.

Po kliknięciu otwiera się systemowe menu udostępniania telefonu, np. SMS, Mail, Messenger, WhatsApp, Facebook albo kopiowanie linku.

Udostępniany jest tytuł atrakcji oraz link do strony atrakcji.

### 7. Tryb iOS bez Google Play

W aplikacji ukrywane są odniesienia do Google Play, linki do Google Play i badge Google Play. Ma to znaczenie szczególnie dla App Store Review.

### 8. Tryb offline

Dopracowano ekran offline:

- tło w kolorze `#f8c401`,
- logo aplikacji,
- komunikat: „Aplikacja do działania wymaga połączenia z Internetem.”,
- przycisk „Spróbuj ponownie”.

Na Androidzie ekran offline jest obsługiwany natywnie. Na iOS dodano lokalną stronę offline jako `server.errorPath`.

## Zmiany techniczne

### Wspólna warstwa aplikacyjna

Dodano plik:

```text
src/gzd-app-ui.js
```

Plik odpowiada za:

- ekran startowy,
- dolną nawigację,
- Ulubione,
- Ostatnio oglądane,
- przyciski serduszka i udostępniania,
- ukrywanie odniesień do Google Play,
- lokalny zapis danych w `localStorage`.

### Android

Zaktualizowano `scripts/patch-android.js`.

Android nadal działa jako natywna pseudo-przeglądarka WebView. Po załadowaniu strony aplikacja wstrzykuje `gzd-app-ui.js` do WebView i dodaje funkcje aplikacyjne.

Dodano natywny bridge `GZDNative.share(...)`, który uruchamia systemowe udostępnianie Androida.

### iOS

Zaktualizowano `scripts/patch-ios.js`.

Skrypt dopisuje `GZDViewController` do `AppDelegate.swift`, dzięki czemu klasa jest w targetcie Xcode. Kontroler wstrzykuje `gzd-app-ui.js` do WKWebView i obsługuje natywne udostępnianie przez `UIActivityViewController`.

Dodatkowo skrypt ustawia:

```text
ITSAppUsesNonExemptEncryption=false
```

### Capacitor

Zaktualizowano `capacitor.config.ts`:

- aplikacja ładuje `https://gdziezdzieckiem.eu/?gzd_app=1`,
- dodano `errorPath: 'offline.html'`,
- zachowano żółty splash screen `#f8c401`.

### Pakiety

Dodano zależność:

```text
@capacitor/share
```

## Krótki opis do sklepów

Nowa wersja aplikacji dodaje wygodny ekran startowy, dolną nawigację, lokalne Ulubione, historię Ostatnio oglądanych miejsc, natywne udostępnianie atrakcji oraz ulepszony ekran offline.

## Notatka dla App Review

This version adds a more app-like mobile experience on top of the family attractions guide. The app now includes a custom home screen, bottom navigation, locally saved favorite places, locally saved recently viewed places, native sharing for individual attractions, and an improved offline screen. Favorites and recently viewed places are stored locally on the user's device and do not require login or server-side storage. The iOS app experience also removes Google Play references from the content visible inside the app.
