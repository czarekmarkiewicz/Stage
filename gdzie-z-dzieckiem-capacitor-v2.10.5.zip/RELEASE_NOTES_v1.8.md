# Gdzie z dzieckiem v1.8.0

Zmiana architektury Androida:
- ekran Start jest natywny Android, a nie warstwa wstrzykiwana do strony WWW;
- dolny pasek jest natywny Android, więc CSS strony nie może go rozjechać;
- systemowy Wstecz zawsze wraca do natywnego ekranu Start;
- wejścia z kafelków pokazują natywny ekran Ładowanie i dopiero potem stronę;
- serduszko ze strony WWW nie jest widoczne na ekranie Start, bo WebView jest ukryty;
- Ulubione i Ostatnio oglądane są renderowane natywnie na Androidzie;
- miejsca zapisywane są tylko z gzd-place-data typu place.
