# Gdzie z dzieckiem v2.1.0

Poprawki zgodnie z zaakceptowanymi grafikami:
- baner Start używa zaakceptowanej grafiki bez kropek slidera;
- ekran Ulubione ma żółty baner „Twoje ulubione miejsca”;
- ekran Ostatnio oglądane ma własny żółty baner;
- przyciski Ulubione i Udostępnij na stronie atrakcji są dużymi białymi kołami w prawym górnym rogu;
- ikona Udostępnij jest czarna i rysowana w stylu załącznika;
- pozostają przyciski „Wyczyść ulubione” i „Wyczyść ostatnio oglądane”.
