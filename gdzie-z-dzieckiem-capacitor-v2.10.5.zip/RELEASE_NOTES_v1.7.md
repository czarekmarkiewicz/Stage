# Gdzie z dzieckiem v1.7.0

Poprawki po testach Androida:
- warstwa aplikacji przeniesiona do Shadow DOM, żeby style strony WWW nie rozbijały kafelków, ulubionych i dolnego paska;
- systemowy przycisk Wstecz przechwytuje także zdarzenie klawisza i wymusza ekran Start;
- ekran Start nie pokazuje dolnego paska ani serduszka;
- mocniejsze ukrywanie zewnętrznych pływających serduszek ze strony WWW;
- poprawione ładowanie stron pod ekranem „Ładowanie…”;
- dodatkowe odświeżanie WebView po wejściu w atrakcję, żeby ograniczyć biały ekran;
- historia nadal zapisuje wyłącznie miejsca z gzd-place-data/type=place.
