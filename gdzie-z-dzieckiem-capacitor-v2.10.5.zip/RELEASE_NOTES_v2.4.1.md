# Gdzie z dzieckiem v2.4.1

Poprawka kompilacji Androida:
- dodano brakujący import `android.os.Message` wymagany przez `WebChromeClient.onCreateWindow`;
- zachowano poprawki z v2.4.0 dotyczące otwierania wszystkich linków `gdziezdzieckiem.eu` w aplikacji.
