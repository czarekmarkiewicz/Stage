# Gdzie z dzieckiem v2.8.1

Poprawka Android:
- dodano natywny splash screen Android z żółtym tłem `#f8c401`;
- splash używa ikony aplikacji;
- Android 12+ używa `Theme.SplashScreen`;
- starsze wersje Androida używają `windowBackground` z logo na żółtym tle;
- po starcie aplikacja przełącza się na zwykły motyw bez belki systemowej.
