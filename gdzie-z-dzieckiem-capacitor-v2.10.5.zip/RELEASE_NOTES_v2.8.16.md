# Gdzie z dzieckiem v2.8.16

Naprawione:
- Android: aktywnego guzika dolnej nawigacji nie da się kliknąć ponownie;
- iPhone: po kliknięciu Mapa / Wyszukaj na mapie pokazuje się natywny ekran ładowania nad WebView;
- iPhone: mapa ładuje się i przewija w tle, a użytkownik nie powinien widzieć zjeżdżania strony do mapy;
- iPhone: ekran ładowania znika dopiero po załadowaniu strony i wykonaniu scrolla do mapy;
- Start: dodano twardy spacer pod notch / Dynamic Island bez zależności od `env(safe-area-inset-top)`;
- zachowano reset historii Wstecz, blokadę aktywnego guzika na iOS oraz poprzednie poprawki mapy.
