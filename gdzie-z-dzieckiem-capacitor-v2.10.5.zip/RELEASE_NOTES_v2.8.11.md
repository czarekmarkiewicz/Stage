# Gdzie z dzieckiem v2.8.11

Naprawione:
- pierwsze kliknięcie „Wyszukaj na mapie”/Mapa na iPhone wymusza pełne załadowanie przez tymczasowy URL `?gzd_app_map=1#brxe-qnovlp`, a po załadowaniu aplikacja ustawia adres na `https://gdziezdzieckiem.eu/#brxe-qnovlp` i ponawia scroll do mapy;
- kafelki Ulubione i Ostatnio na ekranie Start mają osobny markup `gzd-home-card`, bez dziedziczenia starych reguł `gzd-place-card`;
- usunięto serduszko z kart na ekranie Start i wymuszono usuwanie floating actions przy renderowaniu Start;
- zwiększono odstęp pod notch/Dynamic Island na ekranach Ulubione i Ostatnio oglądane;
- zachowano blokadę UI w iframe i `forMainFrameOnly: true` na iOS;
- zachowano blokadę podwójnego panelu udostępniania.
