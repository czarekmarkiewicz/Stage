# Gdzie z dzieckiem v2.8.24

Naprawione:
- Android: reset ścieżki Wstecz na ekranie głównym, dolnej nawigacji oraz przy wejściu z `gzd-reset:`;
- Android: `GZDNative.resetNavigation()` czyści teraz natywną historię WebView;
- Android: wejście w Mapę i Dodaj z dolnej nawigacji resetuje historię, więc Wstecz wraca do Startu;
- Android: mapa ładuje się i doscrollowuje w tle, a WebView pozostaje niewidoczny do momentu ustawienia mapy;
- Android: dodano pływający guzik Wstecz na stronach WebView dla urządzeń bez systemowego przycisku Wstecz;
- Android: banery Ulubione/Ostatnio dostały czysty asset w stylu startowego banera, bez starej białej ramki;
- iPhone: dodano numer wersji `v2.8.24` na dole ekranów aplikacyjnych.
