# Gdzie z dzieckiem v2.8.2

Poprawka iOS:
- dodano natywny splash screen iPhone/iPad;
- LaunchScreen ma żółte tło `#f8c401`;
- na środku pokazuje ikonę aplikacji;
- ustawiono `UILaunchStoryboardName = LaunchScreen`;
- dodano asset `SplashLogo.imageset` używany przez LaunchScreen.storyboard.

Android:
- zachowano splash screen dodany w v2.8.1.
