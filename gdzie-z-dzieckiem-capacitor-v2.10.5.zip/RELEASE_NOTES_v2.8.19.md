# Gdzie z dzieckiem v2.8.19

Naprawione:
- iPhone: po przewinięciu do mapy tytuł „Wyszukaj na mapie” ma zostać niżej, pod Dynamic Island / status bar;
- iPhone: scroll do mapy używa bezpiecznego offsetu 154 px i jest ponawiany dłużej;
- iPhone: natywny ekran ładowania mapy zostaje dłużej, żeby użytkownik nie widział końcowego doscrollowania;
- iPhone: ekran Start dostaje dolny spacer i większą wysokość dokumentu, żeby dało się przewijać już po pierwszym wejściu;
- iPhone: po powrocie na ekran Start aplikacja wymusza przewinięcie na samą górę kilkukrotnie;
- zachowano: Android aktywny guzik dolnej nawigacji disabled, iOS/Android reset ścieżki Wstecz, natywny loading mapy.
