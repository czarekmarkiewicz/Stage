# Gdzie z dzieckiem v2.1.1

Poprawka kompilacji Androida:
- naprawiono teksty w banerze Ulubione/Ostatnio oglądane;
- zamieniono realne przełamania linii w stringach Javy na poprawne `\\n`;
- funkcjonalnie wersja odpowiada v2.1.0.
