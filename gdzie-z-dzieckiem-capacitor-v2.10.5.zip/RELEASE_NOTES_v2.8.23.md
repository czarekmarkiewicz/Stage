# Gdzie z dzieckiem v2.8.23

Naprawione:
- iPhone: osłona powrotu na Start nie jest już ukrywana przez reguły `body.gzd-app-home-active`;
- iPhone: dolna nawigacja „Start” używa teraz tej samej bezpiecznej ścieżki `__GZD_RENDER_HOME__`, która pokazuje osłonę i resetuje scroll;
- iPhone: osłona zostaje widoczna przez ok. 520 ms i dopiero potem znika, po kilku resetach scrolla;
- iPhone: natywna osłona przy `renderAppHomeFromNative()` zostaje minimalnie dłużej;
- zachowano wcześniejsze poprawki: ograniczony dół Startu, pasek notch, map offset 70 px, loading mapy, reset ścieżki Wstecz.
