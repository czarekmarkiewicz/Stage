# Gdzie z dzieckiem v2.8.13

Naprawione:
- dodano przycisk Wstecz na ekranach „Ulubione” i „Ostatnio oglądane”;
- ekran Start po powrocie zawsze ustawia scroll na górze;
- iOS ma wyłączony bounce WebView, żeby po pociągnięciu w dół Start nie wchodził pod notch/Dynamic Island;
- przejścia z dolnej nawigacji i szybkich akcji resetują natywną ścieżkę Wstecz do bieżącej strony, więc Wstecz nie wraca po wcześniejszych kliknięciach nav buttonów;
- iOS obsługuje prefiks `gzd-reset:` w mostku `GZDNative.openUrl`;
- Android ignoruje prefiks `gzd-reset:` i dalej ładuje właściwy URL;
- zachowano poprawki mapy, iframe, safe-area dla WebView i App Preview.
