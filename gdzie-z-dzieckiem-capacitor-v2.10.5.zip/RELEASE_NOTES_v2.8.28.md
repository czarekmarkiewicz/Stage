# Gdzie z dzieckiem v2.8.28

Naprawione:
- Android: banery Ulubione/Ostatnio mają czysty asset w stylu banera startowego, bez starego tekstu i bez jaśniejszego paska u dołu;
- Android: aktywny przycisk dolnej nawigacji nadal wygląda jak nieaktywny, ale konsumuje dotyk i nie przepuszcza kliknięcia do WebView pod spodem;
- Android: mapa ładuje się bez fragmentu `#brxe-qnovlp`, żeby WebView nie wykonywał automatycznego scrolla po pokazaniu;
- Android: WebView mapy jest widoczny technicznie z `alpha=0`, przewijany w tle kilka razy, a loading znika dopiero po końcowym ustawieniu pozycji;
- Android: usunięto opóźnione `scrollIntoView` dla mapy, żeby po przesunięciu mapy nie było jednorazowego cofnięcia;
- Android: pływający Wstecz zostaje tylko przy nawigacji gestami, z poprawioną pełną ścieżką `android.provider.Settings.Secure`.
