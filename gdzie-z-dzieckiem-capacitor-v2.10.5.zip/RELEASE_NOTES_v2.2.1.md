# Gdzie z dzieckiem v2.2.1

Poprawka banerów na listach:
- baner Ulubione i Ostatnio oglądane nie używa już obrazka startowego z tekstem w tle;
- usunięto podwójne/nałożone napisy;
- dodano prostą dekorację po prawej stronie banera;
- zwiększono wysokość banera i poprawiono zawijanie tekstu.
