# Wersja 2.10.5

- Poprawiono odtwarzanie pozycji strony po użyciu przycisku Wstecz w Androidzie.
- Techniczny adres mapy używany przez Android WebView i publiczny adres mapy korzystają teraz z tego samego klucza zapisanego przewinięcia.
- Powrót z atrakcji przywraca miejsce, w którym użytkownik otworzył odnośnik: na mapie albo w dowolnym innym miejscu przewiniętej strony.
- Zachowano dotychczasową kolejność cofania dla ekranów „Ulubione” i „Ostatnio oglądane”.
- Bez zmian funkcjonalnych poza korektą historii i odtwarzania pozycji w Androidzie.
- Android nadal kompilowany z compileSdk/targetSdk 37.
