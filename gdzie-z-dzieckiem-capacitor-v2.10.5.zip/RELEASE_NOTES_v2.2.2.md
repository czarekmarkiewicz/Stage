# Gdzie z dzieckiem v2.2.2

Poprawka kompilacji Androida:
- usunięto dekorację emoji z banera Ulubione/Ostatnio oglądane;
- baner list jest teraz czysty: żółte tło + tekst;
- naprawia błąd `illegal character` / `unclosed string literal` w MainActivity.java;
- pozostałe poprawki z v2.2.1 zostają.
