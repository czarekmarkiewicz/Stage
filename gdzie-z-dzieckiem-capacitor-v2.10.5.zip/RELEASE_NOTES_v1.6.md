# Gdzie z dzieckiem v1.6.0

Poprawki stabilności Android/WebView:

- systemowy przycisk Wstecz wraca do natywnego ekranu Start,
- poprawiono białe ekrany przy otwieraniu atrakcji przez czekanie na widocznie wyrenderowaną stronę WebView,
- usunięto serduszko z ekranu startowego i ekranów lokalnych,
- wzmocniono izolację CSS ekranu startowego, listy Ulubione i dolnego paska,
- poprawiono układ dolnego paska na stronie Dodaj atrakcję,
- poprawiono układ kafelków Ulubione / Ostatnio oglądane,
- nawigacja z kafelków korzysta bezpośrednio z natywnego mostka Androida, bez zostawiania starej nakładki ładowania.
