# Gdzie z dzieckiem v2.10.3

- Naprawiono pozycję strony po powrocie z atrakcji otwartej z pinezki mapy na iPhonie.
- Powrót do mapy korzysta z dedykowanego odtworzenia sekcji mapy zamiast mechanizmu kotwic przeznaczonego dla list atrakcji.
- Nie wprowadzono zmian funkcjonalnych ani zmian konfiguracji Android API 37.

Wersja aplikacji: **2.10.3**.
