# Gdzie z dzieckiem v2.8.18

Naprawione:
- iPhone: logo i żółty baner Start dostają poprawiony spacer 96 px pod Dynamic Island;
- iPhone: ochronna warstwa notch jest nad treścią, więc przy pociągnięciu ekran nie powinien pokazywać logo/banera pod wycięciem;
- iPhone: ekran Start ma wymuszoną przewijalną wysokość i touch-action pan-y;
- iPhone: usunięto programowe scrollTo z pierwszego renderowania Startu, które mogło blokować pierwszy scroll w App Preview;
- iPhone: ekran ładowania mapy przesunięty niżej, żeby napis nie chował się pod notch;
- mapa: wydłużony czas na narysowanie loadingu przed startem natywnego ładowania;
- zachowano natywny overlay ładowania mapy oraz nieklikalny aktywny guzik dolnej nawigacji na Androidzie/iOS.
