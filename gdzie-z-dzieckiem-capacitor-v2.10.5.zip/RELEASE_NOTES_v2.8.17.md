# Gdzie z dzieckiem v2.8.17

Naprawione:
- iPhone: zmniejszono odstęp pod notch / Dynamic Island na ekranie Start;
- iPhone: logo i baner są niżej niż status bar, ale bez przesadnie dużej pustej przestrzeni;
- iPhone: ekran Start ma wymuszoną przewijalną wysokość, aby dało się scrollować już po pierwszym wejściu;
- iPhone: przywrócono naturalny bounce WebView, bo wcześniejsze wyłączenie mogło blokować pierwszy scroll w App Preview;
- iPhone: ekran ładowania mapy jest delikatnie przesunięty niżej, żeby napis nie chował się pod notch;
- zachowano natywny overlay ładowania mapy, ładowanie/przewijanie mapy w tle i Androidową blokadę kliknięcia aktywnego guzika dolnej nawigacji.
