# Gdzie z dzieckiem v2.2.0

Poprawki:
- naprawiono pusty baner Start: plik `hero-banner.png` jest teraz kopiowany do `dist` przy każdym buildzie;
- baner Start ma poprawioną wysokość;
- baner Ulubione/Ostatnio oglądane ma większą wysokość i mniejsze teksty, żeby nie ucinał napisu;
- przyciski Ulubione i Udostępnij na stronie atrakcji przeniesiono nad dolny pasek nawigacji;
- usunięto cień spod przycisków Ulubione i Udostępnij;
- przyciski mają delikatną obwódkę zamiast cienia.
