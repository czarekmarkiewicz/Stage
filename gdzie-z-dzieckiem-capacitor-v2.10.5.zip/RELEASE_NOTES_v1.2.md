# Gdzie z dzieckiem v1.2 — poprawka Android/iOS shell

Poprawka po testach Androida:

- przywrócono ikonę aplikacji generowaną w Codemagic bez użycia zawieszającego się capacitor-assets,
- poprawiono start aplikacji, aby ekran startowy aplikacji był aktywowany na stronie głównej,
- usunięto parametr startowy `?gzd_app=1`, który blokował wykrycie ekranu startowego,
- wzmocniono wstrzykiwanie warstwy aplikacyjnej do WebView na Androidzie,
- dodano wielokrotne bezpieczne uruchomienie UI aplikacji po załadowaniu strony,
- dodano odporność na błędy w ukrywaniu odniesień do Google Play,
- zachowano funkcje: ekran startowy, dolna nawigacja, ulubione, ostatnio oglądane, udostępnianie i offline.
