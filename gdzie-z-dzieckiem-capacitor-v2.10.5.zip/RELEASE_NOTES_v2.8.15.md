# Gdzie z dzieckiem v2.8.15

Naprawione:
- po kliknięciu „Wyszukaj na mapie” albo ikony Mapa ekran ładowania jest renderowany przed uruchomieniem natywnego przejścia;
- przejścia z ekranu Start i dolnej nawigacji używają `gzd-reset:`, więc natywna ścieżka Wstecz zaczyna się od bieżącego przejścia;
- dodano `GZDNative.resetNavigation()` na iOS i Androidzie;
- renderowanie ekranu Start czyści natywną historię aplikacyjną;
- aktywnego guzika w dolnej nawigacji nie da się kliknąć;
- zwiększono bezpieczny odstęp ekranu Start pod notch / Dynamic Island;
- dodano ochronną warstwę u góry ekranu Start i wyłączono bounce WebView na iOS.
