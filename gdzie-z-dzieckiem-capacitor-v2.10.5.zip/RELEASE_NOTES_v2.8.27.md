# Gdzie z dzieckiem v2.8.27

Naprawione:
- Android: poprawiony błąd kompilacji `package Settings does not exist`;
- `Settings.Secure.getInt(...)` zostało zastąpione przez pełną ścieżkę `android.provider.Settings.Secure.getInt(...)`;
- zachowano poprawki z v2.8.26: pływający Wstecz tylko przy nawigacji gestami oraz ukryte ładowanie mapy bez automatycznego scrolla po hash.
