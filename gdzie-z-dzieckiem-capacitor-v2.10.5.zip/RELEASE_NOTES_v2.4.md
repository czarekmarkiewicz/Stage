# Gdzie z dzieckiem v2.4.0

Poprawka nawigacji:
- wszystkie linki do `gdziezdzieckiem.eu` powinny otwierać się w aplikacji, a nie w zewnętrznej przeglądarce;
- dotyczy linków zwykłych, linków z `target="_blank"`, popupów, breadcrumbów oraz formularzy GET;
- dodano przechwytywanie `window.open`;
- dodano zabezpieczenie w `openExternalIntent`, które zawraca wewnętrzne adresy do aplikacji.
