# Gdzie z dzieckiem v2.8.37

## Poprawki

- naprawiono błąd kompilacji Androida w poziomym banerze; znaki nowej linii są teraz poprawnie escapowane w generowanym `MainActivity.java`;
- zachowano szerokość banera równą niebieskiemu kaflowi i zwężony tekst tylko w poziomie;
- zachowano ujednolicony ekran przywracania listy z ekranem ładowania;
- bez zmian w widokach pionowych i mechanizmie cofania.

Wersja aplikacji: **2.8.37**.
