# Gdzie z dzieckiem v2.8.8

Poprawki iPhone/iPad:
- usunięto duplikat żółtego banera na ekranie startowym;
- wymuszono aktualizację CSS w Shadow DOM przy każdym wstrzyknięciu JS;
- usunięto niepasujący żółty pasek pod notchem;
- treść webowa ma tylko bezpieczny odstęp pod status bar / notch;
- „Dodaj atrakcję” ma tylko dolną nawigację, bez dodatkowego górnego paska aplikacji;
- przycisk „Wstecz” wraca do ekranu Start na pierwszej stronie po wejściu z kafelka;
- historia iOS pamięta wewnętrzne przejścia i pozwala wracać krok po kroku;
- „Wyszukaj na mapie” najpierw ustawia hash lokalnie i kilkukrotnie doscrollowuje do mapy;
- powiększono ikony „Ulubione” i „Udostępnij”;
- poprawiono układ kart Ulubione/Ostatnio na ekranie Start.

Wspólne Android/iOS:
- podmieniono grafikę `hero-art.png` na ładniejszy crop z głównego banera startowego;
- banery Ulubione/Ostatnio używają teraz grafiki zgodnej stylistycznie ze Startem.
