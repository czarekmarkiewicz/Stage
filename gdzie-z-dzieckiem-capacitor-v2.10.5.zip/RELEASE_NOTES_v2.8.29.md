# Gdzie z dzieckiem v2.8.29

Naprawione:
- Android: baner Ulubione/Ostatnio używa tła wygenerowanego z banera Start, z widoczną ilustracją po prawej i bez starego napisu startowego;
- Android: aktywny guzik dolnej nawigacji konsumuje dotyk i nie przepuszcza kliknięcia do WebView;
- Android: mapa ląduje wyżej, bliżej wskazanej czerwonej kreski;
- Android: loading mapy jest dłużej na wierzchu, a WebView jest pokazany dopiero po końcowym doscrollowaniu;
- Android: pływający Wstecz zostaje tylko przy nawigacji gestami;
- iPhone i Android/Web UI: pod numerem wersji dodany automatyczny copyright: © 2026 Gdzie z dzieckiem. Wszystkie prawa zastrzeżone.
