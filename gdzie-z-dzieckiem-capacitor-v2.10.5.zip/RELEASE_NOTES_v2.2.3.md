# Gdzie z dzieckiem v2.2.3

Poprawka zabezpieczająca Androida:
- usunięto stary blok dekoracji emoji z generatora MainActivity.java;
- dodano dodatkowy sanitizer w patch-android.js, który usuwa ten blok nawet gdyby pojawił się ze starego fragmentu;
- wersja zachowuje poprawki v2.2.2.
