# Gdzie z dzieckiem v2.8.0

Poprawki iOS:
- poprawiono otwieranie wszystkich wewnętrznych linków w aplikacji przez WKNavigationDelegate i WKUIDelegate;
- dodano natywny mostek `GZDNative.openUrl` dla iOS;
- poprawiono linki `target="_blank"` i `window.open`, żeby nie wychodziły do Safari;
- poprawiono renderowanie mapy przez wymuszenie `resize` i `invalidateSize` dla Leaflet;
- ukryto dolny pasek aplikacji na stronie „Dodaj miejsce”, żeby nie zasłaniał formularza;
- ograniczono ciężką obserwację zmian DOM, żeby wejście w atrakcje działało płynniej.
