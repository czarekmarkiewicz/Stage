# Gdzie z dzieckiem v2.0.0

Poprawki ekranu startowego i akcji:
- żółty baner na ekranie Start jest wygenerowany z zaakceptowanego wzoru, bez kropek slidera;
- dodano przycisk „Wyczyść ulubione” na ekranie Ulubione;
- dodano przycisk „Wyczyść ostatnio oglądane” na ekranie Ostatnio oglądane;
- przycisk udostępniania atrakcji ma czarną ikonę w stylu załącznika;
- zachowano natywny ekran Start, natywne listy i natywny pasek Androida.
