# Gdzie z dzieckiem v2.8.30

Naprawione:
- Android: baner Ulubione/Ostatnio powstaje z tego samego `hero-banner.png` co Start, ale stary napis startowy został usunięty z tła;
- Android: listowe banery używają `FIT_XY` i wysokości 154 dp, tak jak baner Start, bez cropowania i bez dolnej łezki;
- Android: mapa ląduje do nagłówka „Wyszukaj na mapie”, a nie do wcześniejszego elementu z przyciskiem „Więcej”;
- Android: aktywny guzik dolnej nawigacji konsumuje kliknięcie i nie przepuszcza go do WebView;
- Android: pod numerem wersji dodany copyright;
- iPhone/Web UI: pod numerem wersji dodany copyright: © 2026 Gdzie z dzieckiem. Wszystkie prawa zastrzeżone..
