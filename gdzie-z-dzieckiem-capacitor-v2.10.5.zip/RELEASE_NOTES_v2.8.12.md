# Gdzie z dzieckiem v2.8.12

Naprawione:
- na stronach WebView dodano stały bezpieczny obszar pod notch / Dynamic Island;
- WebView dodaje białą warstwę ochronną u góry i odsuwa nagłówek strony (`#brx-header`, `header`, `.brx-header`) poniżej status baru;
- na „Dodaj atrakcję” przywrócono pływający przycisk Wstecz;
- przycisk Wstecz jest w warstwie aplikacji, nad dolną nawigacją;
- zachowano blokadę UI w iframe (`window.top !== window.self`) oraz `forMainFrameOnly: true` na iOS, żeby nie wrócił drugi pasek w edytorze formularza.
