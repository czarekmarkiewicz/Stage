# Gdzie z dzieckiem v2.8.32

Zmienione:
- podniesiono wersję aplikacji z 2.8.31 do 2.8.32;
- dodano do Android WebView i iOS WKWebView znacznik User-Agent `GdzieZDzieckiemMobileApp/1.0`;
- znacznik pozwala odróżnić ruch z aplikacji mobilnej od ruchu ze zwykłej przeglądarki.
- konfigurację Capacitor przeniesiono z TypeScript do `capacitor.config.json`, aby usunąć błąd parsera w Codemagic;
- poprawiono instalację zależności w Codemagic: lockfile korzysta wyłącznie z publicznego rejestru npm;
- usunięto nieużywane podczas builda pakiety `sharp` i `@capacitor/assets`, które powodowały długie pobieranie binariów;
- przypięto Node.js 22 w `codemagic.yaml` i dodano czytelne logowanie wersji Node/npm oraz używanego rejestru.
- naprawiono znacznik User-Agent w niestandardowym Android WebView: `GdzieZDzieckiemMobileApp/1.0`;
