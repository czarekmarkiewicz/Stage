# Gdzie z dzieckiem v2.3.1

Poprawka grafiki banerów:
- hero-art.png został narysowany od zera, bez tekstu z ekranu Start;
- na banerach Ulubione i Ostatnio oglądane nie powinno być już widocznych resztek napisu „Co dziś robimy...”;
- zachowano ten sam motyw: dzieci, balony i plac zabaw;
- delikatnie obniżono przezroczystość grafiki, żeby tekst był czytelny.
