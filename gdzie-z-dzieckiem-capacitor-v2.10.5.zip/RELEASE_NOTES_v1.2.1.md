# Gdzie z dzieckiem v1.2.1

Poprawka techniczna Androida: naprawiono generowanie kodu Java dla natywnego udostępniania, które powodowało błąd kompilacji `unclosed string literal` podczas budowy AAB w Codemagic.
