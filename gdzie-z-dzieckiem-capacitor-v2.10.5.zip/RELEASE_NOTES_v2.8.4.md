# Gdzie z dzieckiem v2.8.4

Poprawka iOS:
- naprawiono problem, w którym po splash screenie aplikacja mogła automatycznie otworzyć Safari z białym ekranem;
- Safari nie otwiera się już dla automatycznych popupów, iframe i przekierowań strony;
- zewnętrzne linki otwierają Safari tylko po świadomym kliknięciu użytkownika;
- linki `gdziezdzieckiem.eu` i `gdziezdzieckiem.pl` nadal zostają w aplikacji;
- splash screen minimum 1s / maksimum 5s zostaje bez zmian.

Android:
- bez zmian funkcjonalnych względem v2.8.3.
