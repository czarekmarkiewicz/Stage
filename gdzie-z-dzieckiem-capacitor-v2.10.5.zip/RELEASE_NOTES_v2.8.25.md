# Gdzie z dzieckiem v2.8.25

Naprawione:
- Android: strzałka w pływającym guziku Wstecz jest teraz centrowana w osobnym okrągłym kontenerze;
- Android: ekrany Ulubione i Ostatnio oglądane dostały dodatkowy pływający guzik Wstecz nad dolną nawigacją;
- Android: strzałka Wstecz w nagłówku Ulubione/Ostatnio też używa tego samego centrowanego komponentu;
- Android: mapa jest przewijana kilka razy, gdy WebView jest nadal niewidoczny, a ekran ładowania pozostaje na wierzchu;
- Android: usunięto opóźniony `scrollIntoView` dla `#brxe-qnovlp`, żeby po załadowaniu mapy nie było jednorazowego cofania do poprzedniej pozycji;
- zachowano: reset ścieżki Wstecz Android, nowy baner list, aktywny guzik dolnej nawigacji disabled i numer wersji iPhone.
