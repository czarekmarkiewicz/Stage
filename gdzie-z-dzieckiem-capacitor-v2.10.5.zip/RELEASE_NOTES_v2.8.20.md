# Gdzie z dzieckiem v2.8.20

Naprawione:
- iPhone: ekran Start ma własny przewijalny kontener `.gzd-home`, więc przewijanie działa od pierwszego wejścia;
- iPhone: usunięto nakładkę `::before`, która wchodziła na logo;
- iPhone: notch na Start obsługuje teraz spacer 84 px bez przykrywania logo;
- iPhone: po powrocie na Start kontener jest ustawiany na górę natychmiast, bez widocznego przewijania z dołu do góry;
- iPhone: offset przewijania do mapy zmniejszony z 154 px do 92 px, żeby sekcja „Wyszukaj na mapie” nie była przesunięta zbyt agresywnie;
- zachowano natywny loading mapy oraz blokadę aktywnego guzika dolnej nawigacji na Androidzie.
