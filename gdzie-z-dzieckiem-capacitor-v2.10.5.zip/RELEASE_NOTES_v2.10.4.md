# Wersja 2.10.4

- Cofanie z atrakcji przywraca dokładną pozycję poprzedniej strony, także na stronie mapy.
- Powrót nie wymusza już sekcji mapy, jeżeli użytkownik przed otwarciem atrakcji przewinął stronę w inne miejsce.
- Atrakcja otwarta z pełnego ekranu „Ulubione” wraca najpierw do „Ulubionych”, a dopiero kolejne cofnięcie do ekranu startowego.
- Atrakcja otwarta z pełnego ekranu „Ostatnio oglądane” wraca najpierw do „Ostatnio oglądanych”, a dopiero kolejne cofnięcie do ekranu startowego.
- Bez zmian funkcjonalnych poza korektą historii i odtwarzania pozycji.
- Android nadal kompilowany z compileSdk/targetSdk 37.
