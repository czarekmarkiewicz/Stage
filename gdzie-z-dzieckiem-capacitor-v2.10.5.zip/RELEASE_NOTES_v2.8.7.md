# Gdzie z dzieckiem v2.8.7

Poprawki iPhone/iPad:
- usunięto źle wyglądający górny pasek webowych stron;
- treść webowa ma bezpieczny odstęp pod status bar / notch bez dodatkowego żółtego appbara;
- na stronie „Dodaj atrakcję” zostaje tylko dolny pasek nawigacji;
- przycisk „Wstecz” przeniesiono nad dolną nawigację i wyśrodkowano ikonę;
- pierwsze wejście w „Wyszukaj na mapie” obsługuje hash lokalnie, żeby nie zostawało na ekranie ładowania;
- baner startowy używa pełnej grafiki `hero-banner.png` tak jak Android;
- banery „Ulubione” i „Ostatnio oglądane” używają grafiki `hero-art.png` z przezroczystością jak Android;
- powiększono ikony „Ulubione” i „Udostępnij” w białych kółkach.

Android:
- zachowano przycisk wstecz, splash i dotychczasowe poprawki.
