Umieść tutaj:

- app-icon.png — ikona z https://gdziezdzieckiem.pl/p/ikona.png
- splash-logo.webp — logo splash z https://gdziezdzieckiem.eu/wp-content/webp-express/webp-images/uploads/2025/12/y-logo.png.webp

Możesz spróbować pobrać automatycznie poleceniem:

./scripts/download-assets.sh
