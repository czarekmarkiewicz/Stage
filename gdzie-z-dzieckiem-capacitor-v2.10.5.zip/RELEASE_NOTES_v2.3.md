# Gdzie z dzieckiem v2.3.0

Poprawki:
- banery Ulubione i Ostatnio oglądane mają grafikę z tego samego motywu co ekran Start;
- grafika na banerach list jest osobnym plikiem `hero-art.png`, bez tekstu i bez kropek slidera;
- zachowano czytelny tekst na banerach list;
- zachowano przyciski czyszczenia list;
- zachowano przeniesione przyciski Ulubione/Udostępnij nad dolny pasek.
