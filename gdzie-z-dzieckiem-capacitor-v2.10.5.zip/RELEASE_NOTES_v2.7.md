# Gdzie z dzieckiem v2.7.0

Poprawka linków wychodzących do przeglądarki:
- część linków na stronie nadal wskazuje starą domenę `gdziezdzieckiem.pl`;
- aplikacja traktuje teraz `gdziezdzieckiem.pl` tak samo jak `gdziezdzieckiem.eu`;
- linki `.pl` są normalizowane do `.eu` i otwierane w aplikacji;
- dotyczy breadcrumbs, formularza „Szukaj”, popupów, `target="_blank"` i `window.open`;
- dodano intent-filter także dla domeny `.pl`.
