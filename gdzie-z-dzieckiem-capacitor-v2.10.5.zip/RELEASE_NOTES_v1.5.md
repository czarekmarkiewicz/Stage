# Gdzie z dzieckiem v1.5.0

Poprawki stabilności Android/WebView:

- systemowy przycisk cofania wraca do ekranu startowego aplikacji,
- dolny pasek nawigacji jest ukryty na ekranie startowym,
- usunięto niepotrzebne serduszko z ekranu startowego,
- przejścia z kafelków ładują stronę pod ekranem ładowania i pokazują dopiero gotową stronę,
- dodano natywny ekran ładowania, aby ograniczyć biały ekran podczas przechodzenia między stronami,
- poprawiono układ kafelków szybkich akcji na wąskich ekranach,
- doprecyzowano grafikę w żółtym banerze,
- historia Ostatnio oglądane nadal zapisuje wyłącznie miejsca z `gzd-place-data` i `type: place`.
