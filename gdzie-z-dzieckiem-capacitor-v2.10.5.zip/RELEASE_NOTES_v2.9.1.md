# Gdzie z dzieckiem v2.9.1

## Poprawka kompilacji i lokalizacji

- zachowano obsługę lokalizacji użytkownika w Android WebView i iOS WKWebView;
- Android nadal prosi o `ACCESS_COARSE_LOCATION` i `ACCESS_FINE_LOCATION` dopiero po użyciu funkcji „Zlokalizuj mnie”;
- utrzymano ograniczenie dostępu do lokalizacji do zaufanych domen przez HTTPS;
- generator Androida zawiera dokładnie jedną metodę `onDestroy()`, dzięki czemu nie występuje błąd `method onDestroy() is already defined`;
- test regresyjny oraz workflow Codemagic sprawdzają liczbę metod `onDestroy()` przed kompilacją;
- podniesiono numer aplikacji i artefaktów do **2.9.1**.

Wersja aplikacji: **2.9.1**.
