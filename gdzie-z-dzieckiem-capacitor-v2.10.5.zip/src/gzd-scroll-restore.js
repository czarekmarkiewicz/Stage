(function () {
  'use strict';

  if (window.top !== window.self) return;
  if (!/(^|\.)gdziezdzieckiem\.(eu|pl)$/i.test(location.hostname || '')) return;

  if (window.__GZD_SCROLL_RESTORE_MODULE_V6__) {
    try { window.__GZD_RESTORE_SCROLL_STATE__ && window.__GZD_RESTORE_SCROLL_STATE__(); } catch (_) {}
    return;
  }

  // Jeżeli pełny skrypt interfejsu zdążył już zainstalować ten sam mechanizm,
  // nie dokładamy drugiego zestawu listenerów.
  if (window.__GZD_NAVIGATION_STATE_INSTALLED_V3__
      && typeof window.__GZD_CAPTURE_SCROLL_STATE__ === 'function'
      && typeof window.__GZD_RESTORE_SCROLL_STATE__ === 'function') {
    try { window.__GZD_RESTORE_SCROLL_STATE__(); } catch (_) {}
    return;
  }

  window.__GZD_SCROLL_RESTORE_MODULE_V6__ = true;

  const HOME_URL = 'https://gdziezdzieckiem.eu/';
  const LOGO_URL = 'https://gdziezdzieckiem.eu/p/ikona.png';

  function cleanText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function getPathFromUrl(url) {
    try { return new URL(url, HOME_URL).pathname.replace(/\/$/, ''); }
    catch (_) { return ''; }
  }

  function isKnownNonPlaceUrl(url) {
    const path = getPathFromUrl(url);
    const blocked = new Set([
      '', '/', '/blog', '/dodaj-atrakcje', '/wszystkie-atrakcje', '/kontakt', '/o-nas',
      '/polityka-prywatnosci', '/regulamin', '/reklama', '/wspolpraca'
    ]);
    if (blocked.has(path)) return true;
    try {
      const parsed = new URL(url, HOME_URL);
      if (parsed.searchParams.has('_na_powietrzu') || parsed.searchParams.has('_pod_dachem')) return true;
    } catch (_) {}
    return false;
  }

const SCROLL_STATE_PREFIX = 'gzd_navigation_scroll_v2:';
const LEGACY_SCROLL_STATE_PREFIX = 'gzd_navigation_scroll_v1:';
const SCROLL_RESTORE_MARKER = 'gzd_navigation_restore_v2';
const SCROLL_HISTORY_STATE_KEY = '__gzdNavigationScrollV2';
const RESTORE_MAX_DURATION = 30000;
let navigationRestoreController = null;
let navigationRestoreActive = false;

function documentScrollHeight() {
  try {
    return Math.max(
      document.documentElement ? document.documentElement.scrollHeight : 0,
      document.body ? document.body.scrollHeight : 0,
      document.documentElement ? document.documentElement.offsetHeight : 0,
      document.body ? document.body.offsetHeight : 0
    );
  } catch (_) { return 0; }
}

function currentScrollPosition() {
  return {
    x: Math.max(0, Number(window.scrollX || window.pageXOffset || (document.documentElement && document.documentElement.scrollLeft) || (document.body && document.body.scrollLeft) || 0)),
    y: Math.max(0, Number(window.scrollY || window.pageYOffset || (document.documentElement && document.documentElement.scrollTop) || (document.body && document.body.scrollTop) || 0))
  };
}

function normalizedNavigationUrl(rawUrl) {
  try {
    const url = new URL(rawUrl || location.href, HOME_URL);
    const mapNavigation = url.hash === '#brxe-qnovlp' || url.searchParams.get('gzd_app_map') === '1';
    url.protocol = 'https:';
    url.hostname = 'gdziezdzieckiem.eu';
    url.searchParams.delete('gzd_app_map');
    if (mapNavigation) url.hash = '#brxe-qnovlp';
    const pathname = url.pathname || '/';
    if (pathname !== '/' && !pathname.endsWith('/') && !/\/[^/]+\.[a-z0-9]{1,8}$/i.test(pathname)) {
      url.pathname = pathname + '/';
    }
    return url.href;
  } catch (_) {
    return String(rawUrl || location.href || '');
  }
}

function isMapNavigationUrl(rawUrl) {
  try {
    const url = new URL(rawUrl || location.href, HOME_URL);
    return url.hash === '#brxe-qnovlp' || url.searchParams.get('gzd_app_map') === '1';
  } catch (_) { return false; }
}

function normalizedAnchorUrl(rawUrl) {
  try {
    const url = new URL(normalizedNavigationUrl(rawUrl), HOME_URL);
    url.hash = '';
    return url.href.replace(/\/$/, '');
  } catch (_) {
    return String(rawUrl || '').replace(/#.*$/, '').replace(/\/$/, '');
  }
}

function navigationScrollKey(rawUrl) {
  return SCROLL_STATE_PREFIX + normalizedNavigationUrl(rawUrl);
}

function isRestorableDocument() {
  try {
    return !!document.body
      && !document.body.classList.contains('gzd-app-home-active')
      && !document.body.classList.contains('gzd-app-local-active');
  } catch (_) { return false; }
}

function isUsefulListAnchor(anchor) {
  try {
    if (!anchor || !anchor.href) return false;
    const url = new URL(anchor.href, HOME_URL);
    if (!/(^|\.)gdziezdzieckiem\.(eu|pl)$/i.test(url.hostname)) return false;
    if (!/^https?:$/i.test(url.protocol)) return false;
    const normalized = normalizedNavigationUrl(url.href);
    if (normalizedAnchorUrl(normalized) === normalizedAnchorUrl(location.href)) return false;
    if (isKnownNonPlaceUrl(normalized)) return false;
    if (/\/(wp-content|wp-admin|feed|tag|category|author)(\/|$)/i.test(url.pathname)) return false;
    const rect = anchor.getBoundingClientRect();
    if (!rect || rect.width < 8 || rect.height < 8) return false;
    const style = window.getComputedStyle ? window.getComputedStyle(anchor) : null;
    if (style && (style.display === 'none' || style.visibility === 'hidden')) return false;
    return true;
  } catch (_) { return false; }
}

function listAnchorCandidates() {
  const result = [];
  const seen = new Set();
  const selectors = [
    '.facetwp-template a[href]',
    '[class*="facetwp"] a[href]',
    '.brxe-posts a[href]',
    '[class*="listing"] a[href]',
    '[class*="loop"] a[href]',
    'main a[href]',
    '[role="main"] a[href]',
    'article a[href]'
  ];
  selectors.forEach(selector => {
    try {
      document.querySelectorAll(selector).forEach(anchor => {
        if (seen.has(anchor) || !isUsefulListAnchor(anchor)) return;
        seen.add(anchor);
        result.push(anchor);
      });
    } catch (_) {}
  });
  if (!result.length) {
    try {
      document.querySelectorAll('a[href]').forEach(anchor => {
        if (seen.has(anchor) || !isUsefulListAnchor(anchor)) return;
        seen.add(anchor);
        result.push(anchor);
      });
    } catch (_) {}
  }
  return result;
}

function findViewportListAnchor() {
  try {
    const safeLine = Math.min(Math.max(96, window.innerHeight * 0.18), 190);
    let best = null;
    let bestScore = Number.POSITIVE_INFINITY;
    const candidates = listAnchorCandidates();
    candidates.forEach(anchor => {
      const rect = anchor.getBoundingClientRect();
      if (rect.bottom < -20 || rect.top > window.innerHeight + 20) return;
      const inHeading = !!anchor.closest('h1,h2,h3,h4,h5,h6');
      const hasImage = !!anchor.querySelector('img');
      const textLength = cleanText(anchor.textContent || '').length;
      const qualityBonus = (inHeading ? 260 : 0) + (hasImage ? 90 : 0) + (textLength > 12 ? 35 : 0);
      const score = Math.abs(rect.top - safeLine) + (rect.top < -20 ? 500 : 0) - qualityBonus;
      if (score < bestScore) {
        bestScore = score;
        best = { anchor, rect };
      }
    });
    if (!best) return null;
    const bestUrl = normalizedAnchorUrl(best.anchor.href);
    const bestText = cleanText(best.anchor.textContent || '').slice(0, 160);
    let occurrence = 0;
    for (let i = 0; i < candidates.length; i += 1) {
      const candidate = candidates[i];
      if (candidate === best.anchor) break;
      if (normalizedAnchorUrl(candidate.href) === bestUrl && cleanText(candidate.textContent || '').slice(0, 160) === bestText) occurrence += 1;
    }
    return {
      url: bestUrl,
      top: Number(best.rect.top || 0),
      text: bestText,
      occurrence,
      index: candidates.indexOf(best.anchor)
    };
  } catch (_) { return null; }
}

function writeHistoryScrollState(state) {
  try {
    const existing = history.state;
    if (existing == null || typeof existing === 'object') {
      const next = Object.assign({}, existing || {});
      next[SCROLL_HISTORY_STATE_KEY] = state;
      history.replaceState(next, '', location.href);
    }
  } catch (_) {}
}

function captureNavigationScrollState(preferredAnchor) {
  try {
    if (navigationRestoreActive || window.__GZD_SCROLL_RESTORE_ACTIVE__ || !isRestorableDocument()) return false;
    const position = currentScrollPosition();
    const docHeight = documentScrollHeight();
    const viewportHeight = Math.max(1, Number(window.innerHeight || 1));
    const maxY = Math.max(0, docHeight - viewportHeight);
    const mapDocument = isMapNavigationUrl(location.href);
    let anchor = null;
    if (!mapDocument && preferredAnchor && isUsefulListAnchor(preferredAnchor)) {
      const candidates = listAnchorCandidates();
      const preferredUrl = normalizedAnchorUrl(preferredAnchor.href);
      const preferredText = cleanText(preferredAnchor.textContent || '').slice(0, 160);
      let occurrence = 0;
      for (let i = 0; i < candidates.length; i += 1) {
        const candidate = candidates[i];
        if (candidate === preferredAnchor) break;
        if (normalizedAnchorUrl(candidate.href) === preferredUrl && cleanText(candidate.textContent || '').slice(0, 160) === preferredText) occurrence += 1;
      }
      const rect = preferredAnchor.getBoundingClientRect();
      anchor = {
        url: preferredUrl,
        top: Number(rect.top || 0),
        text: preferredText,
        occurrence,
        index: candidates.indexOf(preferredAnchor)
      };
    }
    if (!mapDocument && !anchor) anchor = findViewportListAnchor();
    const state = {
      version: 2,
      routeMode: mapDocument ? 'map' : 'document',
      url: normalizedNavigationUrl(location.href),
      x: position.x,
      y: position.y,
      maxY,
      docHeight,
      viewportHeight,
      ratio: maxY > 0 ? position.y / maxY : 0,
      anchorUrl: anchor ? anchor.url : '',
      anchorTop: anchor ? anchor.top : null,
      anchorText: anchor ? anchor.text : '',
      anchorOccurrence: anchor ? anchor.occurrence : 0,
      anchorIndex: anchor && Number.isFinite(Number(anchor.index)) ? Number(anchor.index) : -1,
      loadedAnchorCount: listAnchorCandidates().length,
      savedAt: Date.now()
    };
    sessionStorage.setItem(navigationScrollKey(location.href), JSON.stringify(state));
    writeHistoryScrollState(state);
    return true;
  } catch (_) { return false; }
}

function markNavigationScrollRestore(rawUrl) {
  try {
    captureNavigationScrollState();
    const marker = {
      url: normalizedNavigationUrl(rawUrl),
      requestedAt: Date.now()
    };
    sessionStorage.setItem(SCROLL_RESTORE_MARKER, JSON.stringify(marker));
    return true;
  } catch (_) { return false; }
}

function readRestoreMarker() {
  try {
    const raw = sessionStorage.getItem(SCROLL_RESTORE_MARKER);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    } catch (_) {}
    return { url: String(raw), requestedAt: Date.now() };
  } catch (_) { return null; }
}

function hasPendingNavigationRestoreForCurrentUrl() {
  try {
    const current = normalizedNavigationUrl(location.href);
    if (window.__GZD_RESTORED_NAVIGATION_URL__ === current) return true;
    const marker = readRestoreMarker();
    return !!marker && normalizedNavigationUrl(marker.url) === current;
  } catch (_) { return false; }
}

function readNavigationScrollState(current) {
  try {
    const historyValue = history.state && typeof history.state === 'object'
      ? history.state[SCROLL_HISTORY_STATE_KEY]
      : null;
    if (historyValue && normalizedNavigationUrl(historyValue.url || current) === current) return historyValue;
  } catch (_) {}

  try {
    const raw = sessionStorage.getItem(navigationScrollKey(current));
    if (raw) return JSON.parse(raw);
  } catch (_) {}

  try {
    const legacy = sessionStorage.getItem(LEGACY_SCROLL_STATE_PREFIX + current);
    if (legacy) {
      const value = JSON.parse(legacy);
      return Object.assign({ version: 1, url: current }, value || {});
    }
  } catch (_) {}
  return null;
}

function findAnchorByUrl(rawUrl, expectedOccurrence, expectedText) {
  const expected = normalizedAnchorUrl(rawUrl);
  if (!expected) return null;
  const occurrence = Math.max(0, Number(expectedOccurrence || 0));
  const text = cleanText(expectedText || '').slice(0, 160);
  const candidates = listAnchorCandidates();
  let matchingIndex = 0;
  let firstUrlMatch = null;
  for (let i = 0; i < candidates.length; i += 1) {
    try {
      if (normalizedAnchorUrl(candidates[i].href) !== expected) continue;
      if (!firstUrlMatch) firstUrlMatch = candidates[i];
      const candidateText = cleanText(candidates[i].textContent || '').slice(0, 160);
      if (text && candidateText !== text) continue;
      if (matchingIndex === occurrence) return candidates[i];
      matchingIndex += 1;
    } catch (_) {}
  }
  return firstUrlMatch;
}

function findAnchorBySavedIndex(rawIndex) {
  try {
    const index = Number(rawIndex);
    if (!Number.isFinite(index) || index < 0) return null;
    const candidates = listAnchorCandidates();
    return index < candidates.length ? candidates[index] : null;
  } catch (_) { return null; }
}

function ensureRestoreCover() {
  try {
    let cover = document.getElementById('gzd-scroll-restore-cover');
    if (cover) return cover;
    cover = document.createElement('div');
    cover.id = 'gzd-scroll-restore-cover';
    cover.setAttribute('aria-live', 'polite');
    cover.innerHTML = `<div class="gzd-scroll-restore-box"><div class="gzd-scroll-restore-spinner" aria-hidden="true"></div><img src="${LOGO_URL}" alt="Gdzie z dzieckiem"><div>Ładowanie...</div></div>`;
    const style = document.createElement('style');
    style.id = 'gzd-scroll-restore-style';
    style.textContent = '#gzd-scroll-restore-cover{position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;background:#fffdf4;pointer-events:auto}#gzd-scroll-restore-cover .gzd-scroll-restore-box{display:flex;flex-direction:column;align-items:center;gap:16px;color:#101426;font:800 18px/1.3 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-align:center;padding:24px}#gzd-scroll-restore-cover img{width:86px;height:86px;border-radius:50%;display:block}#gzd-scroll-restore-cover .gzd-scroll-restore-spinner{width:42px;height:42px;border:4px solid rgba(123,201,198,.24);border-top-color:#7bc9c6;border-radius:50%;animation:gzd-scroll-spin .85s linear infinite}#gzd-scroll-restore-cover .gzd-scroll-restore-box>div:last-child{font-weight:800;font-size:18px;line-height:1.3}@keyframes gzd-scroll-spin{to{transform:rotate(360deg)}}';
    (document.head || document.documentElement).appendChild(style);
    document.body.appendChild(cover);
    return cover;
  } catch (_) { return null; }
}

function removeRestoreCover() {
  try {
    const cover = document.getElementById('gzd-scroll-restore-cover');
    if (cover) cover.remove();
    const style = document.getElementById('gzd-scroll-restore-style');
    if (style) style.remove();
  } catch (_) {}
}

function visibleLoadMoreControl() {
  const selectors = [
    '.facetwp-load-more:not(.disabled)',
    'button.facetwp-load-more',
    '[data-load-more]',
    '.load-more button',
    'button.load-more',
    'a.load-more',
    '[class*="load-more"] button',
    '[class*="loadmore"] button',
    '[class*="pagination"] button'
  ];
  for (let i = 0; i < selectors.length; i += 1) {
    try {
      const items = document.querySelectorAll(selectors[i]);
      for (let j = 0; j < items.length; j += 1) {
        const item = items[j];
        const rect = item.getBoundingClientRect();
        const style = window.getComputedStyle ? window.getComputedStyle(item) : null;
        if (rect.width > 4 && rect.height > 4 && (!style || (style.display !== 'none' && style.visibility !== 'hidden')) && !item.disabled) return item;
      }
    } catch (_) {}
  }

  try {
    const controls = document.querySelectorAll('button, a[role="button"], a');
    for (let i = 0; i < controls.length; i += 1) {
      const item = controls[i];
      const text = cleanText(item.textContent || item.getAttribute('aria-label') || '');
      const exactLoadMore = /^(?:(?:pokaż|załaduj|wczytaj|zobacz)\s+(?:więcej|kolejne)|load\s+more)(?:\s*\(.*?\))?$/i.test(text);
      const descriptiveLoadMore = /(pokaż|załaduj|wczytaj|zobacz|więcej|more)/i.test(text)
        && /(atrakc|wynik|wpis|post|miejsce|więcej|more)/i.test(text);
      if (!exactLoadMore && !descriptiveLoadMore) continue;
      const rect = item.getBoundingClientRect();
      const style = window.getComputedStyle ? window.getComputedStyle(item) : null;
      if (rect.width > 4 && rect.height > 4 && rect.top > window.innerHeight * 0.35
          && (!style || (style.display !== 'none' && style.visibility !== 'hidden')) && !item.disabled) return item;
    }
  } catch (_) {}
  return null;
}

function triggerProgressiveListLoad() {
  try {
    const control = visibleLoadMoreControl();
    if (control) {
      control.click();
      return true;
    }
  } catch (_) {}

  try {
    const maxY = Math.max(0, documentScrollHeight() - Math.max(1, window.innerHeight || 1));
    window.scrollTo({ left: 0, top: maxY, behavior: 'auto' });
    window.dispatchEvent(new Event('scroll'));
    document.dispatchEvent(new Event('scroll', { bubbles: true }));
    return true;
  } catch (_) { return false; }
}

function stopNavigationScrollRestore(clearMarker) {
  if (navigationRestoreController) {
    try { navigationRestoreController.stop(clearMarker); } catch (_) {}
    navigationRestoreController = null;
  } else {
    navigationRestoreActive = false;
    if (clearMarker) {
      try { sessionStorage.removeItem(SCROLL_RESTORE_MARKER); } catch (_) {}
    }
    removeRestoreCover();
  }
}

function restoreNavigationScrollState() {
  try {
    const current = normalizedNavigationUrl(location.href);
    const marker = readRestoreMarker();
    if (!marker || normalizedNavigationUrl(marker.url) !== current) return false;

    const state = readNavigationScrollState(current);
    if (!state || !Number.isFinite(Number(state.y))) {
      sessionStorage.removeItem(SCROLL_RESTORE_MARKER);
      removeRestoreCover();
      return false;
    }

    // Zachowaj informację o odtworzeniu przez cały czas życia dokumentu,
    // aby późniejsze inicjalizacje nie uruchomiły ponownie hash-scrolla mapy.
    window.__GZD_RESTORED_NAVIGATION_URL__ = current;

    if (navigationRestoreController && navigationRestoreController.url === current) {
      navigationRestoreController.kick();
      return true;
    }
    stopNavigationScrollRestore(false);

    navigationRestoreActive = true;
    window.__GZD_SCROLL_RESTORE_ACTIVE__ = true;
    const targetX = Math.max(0, Number(state.x || 0));
    const targetY = Math.max(0, Number(state.y || 0));
    const absoluteOnly = state.routeMode === 'map';
    const targetAnchorTop = Number.isFinite(Number(state.anchorTop)) ? Number(state.anchorTop) : null;
    const startedAt = Date.now();
    let stablePasses = 0;
    let lastHeight = -1;
    let lastCount = -1;
    let lastProgressAt = 0;
    let stopped = false;
    let timer = null;
    let observer = null;

    if (targetY > 180 || state.anchorUrl) ensureRestoreCover();

    const cleanup = clearMarker => {
      if (stopped) return;
      stopped = true;
      if (timer) clearTimeout(timer);
      if (observer) observer.disconnect();
      navigationRestoreActive = false;
      window.__GZD_SCROLL_RESTORE_ACTIVE__ = false;
      if (clearMarker) sessionStorage.removeItem(SCROLL_RESTORE_MARKER);
      removeRestoreCover();
      if (navigationRestoreController && navigationRestoreController.url === current) navigationRestoreController = null;
      if (clearMarker) setTimeout(captureNavigationScrollState, 220);
    };

    const schedule = delay => {
      if (stopped) return;
      if (timer) clearTimeout(timer);
      timer = setTimeout(run, delay);
    };

    const alignToAnchor = anchor => {
      const rect = anchor.getBoundingClientRect();
      const desiredTop = targetAnchorTop == null ? Math.min(Math.max(96, window.innerHeight * 0.18), 190) : targetAnchorTop;
      const delta = Number(rect.top || 0) - desiredTop;
      if (Math.abs(delta) > 1) window.scrollBy({ left: 0, top: delta, behavior: 'auto' });
      return Math.abs(delta);
    };

    const run = () => {
      if (stopped) return;
      const elapsed = Date.now() - startedAt;
      const height = documentScrollHeight();
      const count = absoluteOnly ? 0 : listAnchorCandidates().length;
      const maxY = Math.max(0, height - Math.max(1, window.innerHeight || 1));
      const anchorByUrl = !absoluteOnly && state.anchorUrl ? findAnchorByUrl(state.anchorUrl, state.anchorOccurrence, state.anchorText) : null;
      const anchor = absoluteOnly ? null : (anchorByUrl || findAnchorBySavedIndex(state.anchorIndex));

      if (anchor) {
        const delta = alignToAnchor(anchor);
        const nextHeight = documentScrollHeight();
        const nextCount = listAnchorCandidates().length;
        if (delta <= 3 && Math.abs(nextHeight - lastHeight) <= 2 && nextCount === lastCount) stablePasses += 1;
        else stablePasses = 0;
        lastHeight = nextHeight;
        lastCount = nextCount;
        if (stablePasses >= 4 && elapsed >= 500) {
          alignToAnchor(anchor);
          cleanup(true);
          return;
        }
      } else {
        const attainable = Math.min(targetY, maxY);
        window.scrollTo({ left: targetX, top: attainable, behavior: 'auto' });
        const currentY = currentScrollPosition().y;
        const reachedAbsoluteTarget = Math.abs(currentY - targetY) <= 3;
        const savedIndex = Number(state.anchorIndex);
        const enoughForAnchorIndex = absoluteOnly || !Number.isFinite(savedIndex) || savedIndex < 0 || count > savedIndex;
        const enoughAnchors = absoluteOnly || (enoughForAnchorIndex && (!Number.isFinite(Number(state.loadedAnchorCount)) || count >= Number(state.loadedAnchorCount || 0)));
        const unchanged = Math.abs(height - lastHeight) <= 2 && count === lastCount;
        stablePasses = reachedAbsoluteTarget && enoughAnchors && unchanged ? stablePasses + 1 : 0;
        lastHeight = height;
        lastCount = count;

        if (stablePasses >= 5 && elapsed >= 900) {
          window.scrollTo({ left: targetX, top: targetY, behavior: 'auto' });
          cleanup(true);
          return;
        }

        if (absoluteOnly && elapsed - lastProgressAt >= 420) {
          lastProgressAt = elapsed;
          try { if (typeof window.__GZD_FIX_MAPS__ === 'function') window.__GZD_FIX_MAPS__(); } catch (_) {}
        } else if (!absoluteOnly && elapsed - lastProgressAt >= 420 && (targetY > maxY + 3 || !enoughAnchors || !!state.anchorUrl)) {
          lastProgressAt = elapsed;
          triggerProgressiveListLoad();
        }
      }

      if (elapsed >= RESTORE_MAX_DURATION) {
        if (anchor) alignToAnchor(anchor);
        else window.scrollTo({ left: targetX, top: Math.min(targetY, Math.max(0, documentScrollHeight() - window.innerHeight)), behavior: 'auto' });
        cleanup(true);
        return;
      }
      schedule(anchor ? 170 : 240);
    };

    try {
      observer = new MutationObserver(() => schedule(40));
      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'src'] });
    } catch (_) {}

    navigationRestoreController = {
      url: current,
      kick: () => schedule(0),
      stop: clearMarker => cleanup(!!clearMarker)
    };

    window.scrollTo({ left: targetX, top: Math.min(targetY, Math.max(0, documentScrollHeight() - window.innerHeight)), behavior: 'auto' });
    schedule(0);
    return true;
  } catch (_) {
    navigationRestoreActive = false;
    window.__GZD_SCROLL_RESTORE_ACTIVE__ = false;
    removeRestoreCover();
    return false;
  }
}

function captureBeforeInternalNavigation(event) {
  try {
    if (navigationRestoreActive || window.__GZD_SCROLL_RESTORE_ACTIVE__ || !event || !event.target || !event.target.closest) return;
    const anchor = event.target.closest('a[href]');
    if (!anchor || !anchor.href) return;
    const target = new URL(anchor.href, location.href);
    if (!/(^|\.)gdziezdzieckiem\.(eu|pl)$/i.test(target.hostname)) return;
    const current = new URL(location.href);
    const sameDocument = normalizedAnchorUrl(target.href) === normalizedAnchorUrl(current.href);
    if (sameDocument && target.hash) return;
    captureNavigationScrollState(anchor);
  } catch (_) {}
}

function installNavigationStatePersistence() {
  // Dynamiczne listy są odtwarzane przez mechanizm kotwicy. Wyłączamy
  // równoległą automatyczną próbę WebView, która potrafi zatrzymać się
  // na maksymalnym scrollu zbyt krótkiego, jeszcze niedoładowanego dokumentu.
  try { if ('scrollRestoration' in history) history.scrollRestoration = 'manual'; } catch (_) {}

  window.__GZD_CAPTURE_SCROLL_STATE__ = captureNavigationScrollState;
  window.__GZD_MARK_SCROLL_RESTORE__ = markNavigationScrollRestore;
  window.__GZD_RESTORE_SCROLL_STATE__ = restoreNavigationScrollState;
  window.__GZD_STOP_SCROLL_RESTORE__ = stopNavigationScrollRestore;
  window.__GZD_HAS_PENDING_SCROLL_RESTORE__ = hasPendingNavigationRestoreForCurrentUrl;

  if (window.__GZD_NAVIGATION_STATE_INSTALLED_V3__) {
    setTimeout(restoreNavigationScrollState, 0);
    return;
  }
  window.__GZD_NAVIGATION_STATE_INSTALLED_V3__ = true;

  let scrollTimer = null;
  window.addEventListener('scroll', () => {
    if (navigationRestoreActive || window.__GZD_SCROLL_RESTORE_ACTIVE__ || scrollTimer) return;
    scrollTimer = setTimeout(() => {
      scrollTimer = null;
      captureNavigationScrollState();
    }, 140);
  }, { passive: true });
  document.addEventListener('pointerdown', captureBeforeInternalNavigation, true);
  document.addEventListener('touchstart', captureBeforeInternalNavigation, { capture: true, passive: true });
  document.addEventListener('click', captureBeforeInternalNavigation, true);
  window.addEventListener('pagehide', captureNavigationScrollState);
  window.addEventListener('beforeunload', captureNavigationScrollState);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') captureNavigationScrollState();
  });
  window.addEventListener('pageshow', () => setTimeout(restoreNavigationScrollState, 0));
  setTimeout(restoreNavigationScrollState, 0);
}


  installNavigationStatePersistence();
})();
