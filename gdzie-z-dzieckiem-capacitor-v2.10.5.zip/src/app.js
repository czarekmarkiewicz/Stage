const TARGET_URL = 'https://gdziezdzieckiem.eu/';

const loading = document.getElementById('loading');
const offline = document.getElementById('offline');
const retry = document.getElementById('retry');
let redirectStarted = false;

function getPlugin(name) {
  return window.Capacitor && window.Capacitor.Plugins
    ? window.Capacitor.Plugins[name]
    : undefined;
}

async function hideNativeSplash() {
  try {
    const SplashScreen = getPlugin('SplashScreen');
    if (SplashScreen && typeof SplashScreen.hide === 'function') {
      await SplashScreen.hide();
    }
  } catch (_) {}
}

function showOffline() {
  if (loading) loading.hidden = true;
  if (offline) offline.hidden = false;
}

function showLoading() {
  if (offline) offline.hidden = true;
  if (loading) loading.hidden = false;
}

function goToSite() {
  if (redirectStarted) return;
  redirectStarted = true;
  window.location.href = TARGET_URL;
}

async function openSite() {
  showLoading();
  await hideNativeSplash();

  // Nie polegamy już na @capacitor/network przy starcie iOS, bo potrafi zwrócić
  // stan z opóźnieniem i zostawić aplikację na lokalnym ekranie startowym.
  // Jeśli system jasno mówi, że jest offline, pokazujemy ekran offline.
  if (navigator.onLine === false) {
    showOffline();
    return;
  }

  // Dajemy splashowi minimum ok. 1 s, a potem bezwarunkowo przechodzimy do strony.
  window.setTimeout(goToSite, 1000);
}

if (retry) {
  retry.addEventListener('click', async () => {
    redirectStarted = false;
    await openSite();
  });
}

window.addEventListener('online', async () => {
  if (offline && offline.hidden === false) {
    redirectStarted = false;
    await openSite();
  }
});

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', openSite, { once: true });
} else {
  openSite();
}

// Bezpieczniki: nawet jeśli event DOMContentLoaded albo plugin splash zawiedzie,
// aplikacja nie zostanie na żółtym ekranie.
window.setTimeout(hideNativeSplash, 500);
window.setTimeout(goToSite, 1800);
