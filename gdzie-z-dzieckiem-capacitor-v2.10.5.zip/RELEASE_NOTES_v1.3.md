# Gdzie z dzieckiem v1.3.0

Poprawki względem v1.2.1:

- naprawiono kliknięcie „Wyszukaj na mapie” z ekranu startowego aplikacji,
- poprawiono przechodzenie do: Na powietrzu, Pod dachem, Superblog i Dodaj miejsce, żeby aplikacja nie zostawała na pustym/białym ekranie,
- usunięto trzy kropki pod żółtym banerem,
- odświeżono grafikę na żółtym banerze: dzieci, balony, plac zabaw i zamek w delikatnym stylu jak w zaakceptowanym mockupie,
- zmieniono dolną nawigację na: Start, Mapa, Ulubione, Dodaj,
- „Ostatnio oglądane” zapisuje tylko realne miejsca/atrakcje z `gzd-place-data` o `type: "place"`,
- historia automatycznie usuwa błędne wpisy typu Główna, Blog, Wyszukiwarka i Dodaj atrakcję.
