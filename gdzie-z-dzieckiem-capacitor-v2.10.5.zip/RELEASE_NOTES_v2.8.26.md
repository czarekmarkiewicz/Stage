# Gdzie z dzieckiem v2.8.26

Naprawione:
- Android: pływający guzik Wstecz pokazuje się tylko przy nawigacji gestami (`navigation_mode == 2`), czyli gdy nie ma widocznego systemowego przycisku Wstecz;
- Android: przy klasycznej dolnej belce z systemowym Wstecz pływający guzik jest ukrywany;
- Android: wejście na Mapę ładuje WebView bez fragmentu `#brxe-qnovlp`, żeby przeglądarka nie wykonywała automatycznego scrolla po pokazaniu strony;
- Android: aplikacja sama ustawia mapę kilka razy, gdy WebView jest nadal niewidoczny;
- Android: po ustawieniu pozycji dopiero wykonywane jest `history.replaceState(...#brxe-qnovlp)`, bez automatycznego scrolla;
- Android: fallback pokazujący WebView jest wydłużony dla mapy, aby ekran ładowania nie odsłaniał strony za wcześnie.
