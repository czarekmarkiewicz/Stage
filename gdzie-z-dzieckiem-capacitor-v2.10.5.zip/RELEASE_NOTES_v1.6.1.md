# Gdzie z dzieckiem v1.6.1

Poprawka techniczna Androida:
- naprawiono kompilację `WebView.VisualStateCallback`;
- zastąpiono zapis lambdą klasyczną anonimową klasą Javy;
- funkcjonalnie wersja odpowiada v1.6.0.
