# Gdzie z dzieckiem v2.8.6

Poprawka iOS/App Preview:
- naprawiono błąd kompilacji Swift `invalid escape sequence in literal`;
- usunięto problematyczne regexy z osadzonych skryptów JS w `AppDelegate.swift`;
- zachowano blokowanie mignięcia strony po splashu;
- zachowano splash minimum 1s / maksimum 5s;
- zachowano górny pasek pod notchem, banery, grafiki, ikony i przycisk wstecz.

Codemagic:
- YAML App Preview używa ZIP v2.8.6;
- artefakty App Preview wskazują `.app` z DerivedData.
