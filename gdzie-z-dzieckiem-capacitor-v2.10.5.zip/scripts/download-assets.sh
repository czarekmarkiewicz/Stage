#!/usr/bin/env bash
set -euo pipefail
mkdir -p assets
curl -L --fail -o assets/app-icon.png 'https://gdziezdzieckiem.pl/p/ikona.png'
curl -L --fail -o assets/splash-logo.webp 'https://gdziezdzieckiem.eu/wp-content/webp-express/webp-images/uploads/2025/12/y-logo.png.webp'
echo 'Pobrano assets/app-icon.png i assets/splash-logo.webp'
