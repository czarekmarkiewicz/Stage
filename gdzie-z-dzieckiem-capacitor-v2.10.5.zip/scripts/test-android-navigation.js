const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const android = fs.readFileSync(path.join(root, 'scripts', 'patch-android.js'), 'utf8');

function includes(fragment, label) {
  assert(android.includes(fragment), `Brak wymaganej poprawki Android: ${label || fragment}`);
}

function excludes(fragment, label) {
  assert(!android.includes(fragment), `Pozostał niedozwolony mechanizm Android: ${label || fragment}`);
}

includes('private int navigationCommandId = 0;', 'identyfikator komendy nawigacji');
includes('private boolean backNavigationInProgress = false;', 'blokada równoległego cofania');
includes('private void requestBackNavigation()', 'wspólna ścieżka wszystkich przycisków Wstecz');
includes('if (now - lastBackActionAt < 350) return;', 'ochrona przed podwójnym zdarzeniem Androida');
includes('if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled())', 'obsługa ACTION_UP');
includes('return true;\n        }\n        return super.dispatchKeyEvent(event);', 'zużycie obu faz klawisza Wstecz');
includes('navigateToUrlNow(previous, false, true, commandId);', 'deterministyczny powrót do poprzedniego URL');
includes('markWebScrollRestore(webLoadUrlFor(previous)', 'marker cofania zgodny z URL ładowanym przez WebView');
includes('if (commandId != navigationCommandId) return;', 'odrzucanie starych callbacków');
includes('webView.loadUrl("about:blank")', 'odłączenie starego dokumentu na ekranie startowym');
includes('if (!("web".equals(mode) || "loading".equals(mode))) return;', 'blokada starego mostka JavaScript');
includes('if (!("web".equals(mode) || "loading".equals(mode))) return true;', 'blokada przekierowań ukrytego WebView');
includes('boolean serverRedirect = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && request.isRedirect();', 'bezpieczne sprawdzenie redirect od Android 7');
includes('if (serverRedirect || isActiveLoadContinuation(url)) return false;', 'zezwolenie tylko na przekierowanie aktywnego ładowania');
includes('if ("about:blank".equals(url) || !isCurrentWebViewCallback(view, url)) return;', 'odrzucanie spóźnionych callbacków WebView');
includes('if (backNavigationInProgress || (appInitiatedLoad && "loading".equals(mode))) return;', 'blokada starego mostka podczas aktywnej nawigacji');
includes('try { view.clearHistory(); }', 'czyszczenie natywnej historii po ładowaniu');
includes('android-native-v2.10.5', 'wersja natywnej powłoki');

excludes('webView.goBack()', 'WebView.goBack');
excludes('webView.canGoBack()', 'WebView.canGoBack');
excludes('restoreOnNextLoad', 'stara flaga awaryjnego natywnego cofania');

// Model regresji: pojedynczy gest może wygenerować kilka callbacków Androida,
// ale ma wykonać dokładnie jeden krok list <- atrakcja.
class NavigationModel {
  constructor() {
    this.stack = [];
    this.commandId = 0;
    this.backInProgress = false;
    this.lastBackAt = -Infinity;
    this.mode = 'home';
    this.loads = [];
  }
  open(url, reset = false) {
    this.commandId += 1;
    this.backInProgress = false;
    if (reset) this.stack = [];
    if (this.stack[this.stack.length - 1] !== url) this.stack.push(url);
    this.mode = 'web';
    this.loads.push(url);
  }
  requestBack(now) {
    if (now - this.lastBackAt < 350) return;
    this.lastBackAt = now;
    if (this.backInProgress) return;
    if (this.stack.length <= 1) {
      this.showHome();
      return;
    }
    this.commandId += 1;
    this.backInProgress = true;
    this.stack.pop();
    this.loads.push(this.stack[this.stack.length - 1]);
  }
  finishLoad() {
    this.backInProgress = false;
  }
  showHome() {
    this.commandId += 1;
    this.stack = [];
    this.backInProgress = false;
    this.mode = 'home';
    this.loads.push('about:blank');
  }
  runDelayed(commandId, url) {
    if (commandId === this.commandId && this.mode !== 'home') this.open(url);
  }
}

const model = new NavigationModel();
model.open('/wszystkie-atrakcje/');
model.open('/atrakcja/testowa/');
model.requestBack(1000);       // OnBackInvoked
model.requestBack(1010);       // onBackPressed dla tego samego gestu
model.requestBack(1020);       // ACTION_UP dla tego samego gestu
assert.deepStrictEqual(model.stack, ['/wszystkie-atrakcje/']);
assert.strictEqual(model.loads.filter(x => x === '/wszystkie-atrakcje/').length, 2,
  'Lista powinna zostać otwarta raz pierwotnie i raz po cofnięciu');

model.requestBack(1500);       // użytkownik naciska ponownie podczas odtwarzania
assert.deepStrictEqual(model.stack, ['/wszystkie-atrakcje/'],
  'Cofnięcie w trakcie odtwarzania nie może pominąć listy');
model.finishLoad();

const staleCommand = model.commandId;
model.showHome();
model.runDelayed(staleCommand, '/atrakcja/testowa/');
assert.strictEqual(model.mode, 'home', 'Spóźniony callback nie może ponownie otworzyć atrakcji');
assert.deepStrictEqual(model.stack, [], 'Ekran startowy nie może odziedziczyć starego stosu');

console.log('OK: Android v2.10.5 używa jednego stosu nawigacji, jednego kroku Wstecz i odrzuca stare callbacki.');
