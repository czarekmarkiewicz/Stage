#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
ICON_SRC="$ROOT_DIR/assets/icon.png"
APP_ICON_SRC="$ROOT_DIR/assets/app-icon.png"
SPLASH_SRC="$ROOT_DIR/assets/splash.png"

if [ ! -f "$ICON_SRC" ]; then
  ICON_SRC="$APP_ICON_SRC"
fi

if [ ! -f "$ICON_SRC" ]; then
  echo "Brak assets/icon.png albo assets/app-icon.png"
  exit 0
fi

resize_png() {
  local src="$1"
  local size="$2"
  local out="$3"
  mkdir -p "$(dirname "$out")"
  sips -s format png -z "$size" "$size" "$src" --out "$out" >/dev/null
}

# Android launcher icons
if [ -d "$ROOT_DIR/android/app/src/main/res" ]; then
  resize_png "$ICON_SRC" 48  "$ROOT_DIR/android/app/src/main/res/mipmap-mdpi/ic_launcher.png"
  resize_png "$ICON_SRC" 72  "$ROOT_DIR/android/app/src/main/res/mipmap-hdpi/ic_launcher.png"
  resize_png "$ICON_SRC" 96  "$ROOT_DIR/android/app/src/main/res/mipmap-xhdpi/ic_launcher.png"
  resize_png "$ICON_SRC" 144 "$ROOT_DIR/android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png"
  resize_png "$ICON_SRC" 192 "$ROOT_DIR/android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png"
  resize_png "$ICON_SRC" 48  "$ROOT_DIR/android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png"
  resize_png "$ICON_SRC" 72  "$ROOT_DIR/android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png"
  resize_png "$ICON_SRC" 96  "$ROOT_DIR/android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png"
  resize_png "$ICON_SRC" 144 "$ROOT_DIR/android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png"
  resize_png "$ICON_SRC" 192 "$ROOT_DIR/android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png"
fi

# iOS AppIcon asset catalog
IOS_ICONSET="$ROOT_DIR/ios/App/App/Assets.xcassets/AppIcon.appiconset"
if [ -d "$ROOT_DIR/ios/App/App/Assets.xcassets" ]; then
  rm -rf "$IOS_ICONSET"
  mkdir -p "$IOS_ICONSET"
  resize_png "$ICON_SRC" 40   "$IOS_ICONSET/AppIcon-20x20@2x.png"
  resize_png "$ICON_SRC" 60   "$IOS_ICONSET/AppIcon-20x20@3x.png"
  resize_png "$ICON_SRC" 58   "$IOS_ICONSET/AppIcon-29x29@2x.png"
  resize_png "$ICON_SRC" 87   "$IOS_ICONSET/AppIcon-29x29@3x.png"
  resize_png "$ICON_SRC" 80   "$IOS_ICONSET/AppIcon-40x40@2x.png"
  resize_png "$ICON_SRC" 120  "$IOS_ICONSET/AppIcon-40x40@3x.png"
  resize_png "$ICON_SRC" 120  "$IOS_ICONSET/AppIcon-60x60@2x.png"
  resize_png "$ICON_SRC" 180  "$IOS_ICONSET/AppIcon-60x60@3x.png"
  resize_png "$ICON_SRC" 20   "$IOS_ICONSET/AppIcon-20x20@1x~ipad.png"
  resize_png "$ICON_SRC" 40   "$IOS_ICONSET/AppIcon-20x20@2x~ipad.png"
  resize_png "$ICON_SRC" 29   "$IOS_ICONSET/AppIcon-29x29@1x~ipad.png"
  resize_png "$ICON_SRC" 58   "$IOS_ICONSET/AppIcon-29x29@2x~ipad.png"
  resize_png "$ICON_SRC" 40   "$IOS_ICONSET/AppIcon-40x40@1x~ipad.png"
  resize_png "$ICON_SRC" 80   "$IOS_ICONSET/AppIcon-40x40@2x~ipad.png"
  resize_png "$ICON_SRC" 76   "$IOS_ICONSET/AppIcon-76x76@1x~ipad.png"
  resize_png "$ICON_SRC" 152  "$IOS_ICONSET/AppIcon-76x76@2x~ipad.png"
  resize_png "$ICON_SRC" 167  "$IOS_ICONSET/AppIcon-83.5x83.5@2x~ipad.png"
  resize_png "$ICON_SRC" 1024 "$IOS_ICONSET/AppIcon-1024x1024@1x.png"
  cat > "$IOS_ICONSET/Contents.json" <<'JSON'
{
  "images": [
    { "idiom": "iphone", "size": "20x20", "scale": "2x", "filename": "AppIcon-20x20@2x.png" },
    { "idiom": "iphone", "size": "20x20", "scale": "3x", "filename": "AppIcon-20x20@3x.png" },
    { "idiom": "iphone", "size": "29x29", "scale": "2x", "filename": "AppIcon-29x29@2x.png" },
    { "idiom": "iphone", "size": "29x29", "scale": "3x", "filename": "AppIcon-29x29@3x.png" },
    { "idiom": "iphone", "size": "40x40", "scale": "2x", "filename": "AppIcon-40x40@2x.png" },
    { "idiom": "iphone", "size": "40x40", "scale": "3x", "filename": "AppIcon-40x40@3x.png" },
    { "idiom": "iphone", "size": "60x60", "scale": "2x", "filename": "AppIcon-60x60@2x.png" },
    { "idiom": "iphone", "size": "60x60", "scale": "3x", "filename": "AppIcon-60x60@3x.png" },
    { "idiom": "ipad", "size": "20x20", "scale": "1x", "filename": "AppIcon-20x20@1x~ipad.png" },
    { "idiom": "ipad", "size": "20x20", "scale": "2x", "filename": "AppIcon-20x20@2x~ipad.png" },
    { "idiom": "ipad", "size": "29x29", "scale": "1x", "filename": "AppIcon-29x29@1x~ipad.png" },
    { "idiom": "ipad", "size": "29x29", "scale": "2x", "filename": "AppIcon-29x29@2x~ipad.png" },
    { "idiom": "ipad", "size": "40x40", "scale": "1x", "filename": "AppIcon-40x40@1x~ipad.png" },
    { "idiom": "ipad", "size": "40x40", "scale": "2x", "filename": "AppIcon-40x40@2x~ipad.png" },
    { "idiom": "ipad", "size": "76x76", "scale": "1x", "filename": "AppIcon-76x76@1x~ipad.png" },
    { "idiom": "ipad", "size": "76x76", "scale": "2x", "filename": "AppIcon-76x76@2x~ipad.png" },
    { "idiom": "ipad", "size": "83.5x83.5", "scale": "2x", "filename": "AppIcon-83.5x83.5@2x~ipad.png" },
    { "idiom": "ios-marketing", "size": "1024x1024", "scale": "1x", "filename": "AppIcon-1024x1024@1x.png" }
  ],
  "info": { "version": 1, "author": "xcode" }
}
JSON
fi

echo "Native icons generated with sips."
