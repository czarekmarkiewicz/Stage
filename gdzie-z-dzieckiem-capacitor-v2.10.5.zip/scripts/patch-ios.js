const fs = require('fs');
const path = require('path');

const projectRoot = path.join(__dirname, '..');
const iosRoot = path.join(projectRoot, 'ios', 'App', 'App');
const plistPath = path.join(iosRoot, 'Info.plist');
const storyboardPath = path.join(iosRoot, 'Base.lproj', 'Main.storyboard');
const launchStoryboardPath = path.join(iosRoot, 'Base.lproj', 'LaunchScreen.storyboard');
const splashLogoImagesetDir = path.join(iosRoot, 'Assets.xcassets', 'SplashLogo.imageset');
const appDelegatePath = path.join(iosRoot, 'AppDelegate.swift');
const unusedControllerPath = path.join(iosRoot, 'GZDViewController.swift');

if (!fs.existsSync(plistPath)) {
  console.log('Info.plist nie istnieje jeszcze. Uruchom najpierw: npx cap add ios');
  process.exit(0);
}

let plist = fs.readFileSync(plistPath, 'utf8');

function ensurePlistKeyFalse(key) {
  if (plist.includes(`<key>${key}</key>`)) {
    plist = plist.replace(new RegExp(`<key>${key}</key>\\s*<(true|false)\\s*/>`, 'm'), `<key>${key}</key>\n\t<false/>`);
  } else {
    plist = plist.replace('</dict>', `\t<key>${key}</key>\n\t<false/>\n</dict>`);
  }
}


function ensurePlistString(key, value) {
  const keyRe = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`<key>${keyRe}</key>\\s*<string>[^<]*<\\/string>`, 'm');
  if (re.test(plist)) {
    plist = plist.replace(re, `<key>${key}</key>\n\t<string>${value}</string>`);
  } else {
    plist = plist.replace('</dict>', `\t<key>${key}</key>\n\t<string>${value}</string>\n</dict>`);
  }
}

ensurePlistKeyFalse('ITSAppUsesNonExemptEncryption');
ensurePlistString('UILaunchStoryboardName', 'LaunchScreen');
ensurePlistString(
  'NSLocationWhenInUseUsageDescription',
  'Aplikacja używa Twojej lokalizacji po wybraniu „Zlokalizuj mnie”, aby pokazać atrakcje w wybranym promieniu.'
);
fs.writeFileSync(plistPath, plist);
console.log('iOS: ustawiono szyfrowanie i opis dostępu do lokalizacji podczas używania aplikacji.');


function findSplashLogoSource() {
  const candidates = [
    path.join(projectRoot, 'assets', 'app-icon.png'),
    path.join(projectRoot, 'assets', 'icon.png'),
    path.join(projectRoot, 'public', 'app-icon.png'),
    path.join(projectRoot, 'dist', 'app-icon.png'),
    path.join(projectRoot, 'dist', 'public', 'app-icon.png')
  ];
  return candidates.find(file => fs.existsSync(file));
}

function ensureIOSSplashLogoAsset() {
  const source = findSplashLogoSource();
  if (!source) {
    console.log('iOS: nie znaleziono app-icon.png dla SplashLogo.imageset.');
    return;
  }

  fs.mkdirSync(splashLogoImagesetDir, { recursive: true });

  const one = path.join(splashLogoImagesetDir, 'splash_logo_1x.png');
  const two = path.join(splashLogoImagesetDir, 'splash_logo_2x.png');
  const three = path.join(splashLogoImagesetDir, 'splash_logo_3x.png');

  fs.copyFileSync(source, one);
  fs.copyFileSync(source, two);
  fs.copyFileSync(source, three);

  const contents = {
    images: [
      { idiom: 'universal', filename: 'splash_logo_1x.png', scale: '1x' },
      { idiom: 'universal', filename: 'splash_logo_2x.png', scale: '2x' },
      { idiom: 'universal', filename: 'splash_logo_3x.png', scale: '3x' }
    ],
    info: { author: 'xcode', version: 1 }
  };

  fs.writeFileSync(path.join(splashLogoImagesetDir, 'Contents.json'), JSON.stringify(contents, null, 2) + '\n');
}

function ensureIOSLaunchScreenStoryboard() {
  fs.mkdirSync(path.dirname(launchStoryboardPath), { recursive: true });

  const storyboard = `<?xml version="1.0" encoding="UTF-8"?>
<document type="com.apple.InterfaceBuilder3.CocoaTouch.Storyboard.XIB" version="3.0" toolsVersion="23504" targetRuntime="iOS.CocoaTouch" propertyAccessControl="none" useAutolayout="YES" launchScreen="YES" useTraitCollections="YES" useSafeAreas="YES" colorMatched="YES" initialViewController="GZD-splash-vc">
    <device id="retina6_12" orientation="portrait" appearance="light"/>
    <dependencies>
        <deployment identifier="iOS"/>
        <plugIn identifier="com.apple.InterfaceBuilder.IBCocoaTouchPlugin" version="23506"/>
        <capability name="Safe area layout guides" minToolsVersion="9.0"/>
        <capability name="documents saved in the Xcode 8 format" minToolsVersion="8.0"/>
    </dependencies>
    <scenes>
        <scene sceneID="GZD-splash-scene">
            <objects>
                <viewController id="GZD-splash-vc" sceneMemberID="viewController">
                    <view key="view" contentMode="scaleToFill" id="GZD-splash-view">
                        <rect key="frame" x="0.0" y="0.0" width="393" height="852"/>
                        <autoresizingMask key="autoresizingMask" widthSizable="YES" heightSizable="YES"/>
                        <subviews>
                            <imageView clipsSubviews="YES" userInteractionEnabled="NO" contentMode="scaleAspectFit" horizontalHuggingPriority="251" verticalHuggingPriority="251" image="SplashLogo" translatesAutoresizingMaskIntoConstraints="NO" id="GZD-splash-logo">
                                <rect key="frame" x="132.5" y="362" width="128" height="128"/>
                                <constraints>
                                    <constraint firstAttribute="width" constant="128" id="GZD-logo-width"/>
                                    <constraint firstAttribute="height" constant="128" id="GZD-logo-height"/>
                                </constraints>
                            </imageView>
                        </subviews>
                        <viewLayoutGuide key="safeArea" id="GZD-splash-safe"/>
                        <color key="backgroundColor" red="0.9725490196" green="0.7686274510" blue="0.0039215686" alpha="1" colorSpace="custom" customColorSpace="sRGB"/>
                        <constraints>
                            <constraint firstItem="GZD-splash-logo" firstAttribute="centerX" secondItem="GZD-splash-view" secondAttribute="centerX" id="GZD-logo-center-x"/>
                            <constraint firstItem="GZD-splash-logo" firstAttribute="centerY" secondItem="GZD-splash-view" secondAttribute="centerY" id="GZD-logo-center-y"/>
                        </constraints>
                    </view>
                </viewController>
                <placeholder placeholderIdentifier="IBFirstResponder" id="GZD-splash-first-responder" userLabel="First Responder" sceneMemberID="firstResponder"/>
            </objects>
            <point key="canvasLocation" x="53" y="375"/>
        </scene>
    </scenes>
    <resources>
        <image name="SplashLogo" width="128" height="128"/>
    </resources>
</document>
`;

  fs.writeFileSync(launchStoryboardPath, storyboard);
}

ensureIOSSplashLogoAsset();
ensureIOSLaunchScreenStoryboard();
console.log('iOS: dodano LaunchScreen.storyboard z żółtym tłem #f8c401 i logo aplikacji.');


if (fs.existsSync(unusedControllerPath)) {
  fs.unlinkSync(unusedControllerPath);
}

if (fs.existsSync(appDelegatePath)) {
  let appDelegate = fs.readFileSync(appDelegatePath, 'utf8');

  if (!appDelegate.includes('import WebKit')) {
    appDelegate = appDelegate.replace(/import Capacitor\s*/, match => `${match}import WebKit\n`);
  }

  const start = '// GZD_APP_VIEW_CONTROLLER_START';
  const end = '// GZD_APP_VIEW_CONTROLLER_END';
  const block = `${start}

class GZDViewController: CAPBridgeViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private var gzdScriptSource: String?
    private var gzdStartupSplashView: UIView?
    private var gzdStartupSplashStartedAt = Date()
    private var gzdStartupSplashReady = false
    private var gzdStartupSplashHidden = false
    private var gzdNavigationStack: [URL] = []
    private var gzdLocalScreen: String?
    private var gzdShowingLocalScreen = false
    private var gzdNavigationLoadingView: UIView?
    private var gzdRestoringBackNavigation = false


    override func viewDidLoad() {
        super.viewDidLoad()
        configureGZDAppLayer()
        showStartupSplashOverlay()
    }

    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        updateGZDLandscapeSafeAreaVariables()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateGZDLandscapeSafeAreaVariables()
    }

    private func updateGZDLandscapeSafeAreaVariables() {
        guard let webView = self.webView else { return }
        let landscape = view.bounds.width > view.bounds.height
        let insets = landscape ? view.safeAreaInsets : .zero
        let js = """
        (function(){
          try {
            document.documentElement.style.setProperty('--gzd-native-safe-left', '\\(insets.left)px');
            document.documentElement.style.setProperty('--gzd-native-safe-right', '\\(insets.right)px');
            document.documentElement.style.setProperty('--gzd-native-safe-top', '\\(insets.top)px');
            document.documentElement.style.setProperty('--gzd-native-safe-bottom', '\\(insets.bottom)px');
          } catch(e) {}
        })();
        """
        webView.evaluateJavaScript(js, completionHandler: nil)
    }

    private func showStartupSplashOverlay() {
        guard gzdStartupSplashView == nil else { return }

        gzdStartupSplashStartedAt = Date()
        gzdStartupSplashReady = false
        gzdStartupSplashHidden = false

        let splash = UIView(frame: view.bounds)
        splash.translatesAutoresizingMaskIntoConstraints = false
        splash.backgroundColor = UIColor(red: 248.0/255.0, green: 196.0/255.0, blue: 1.0/255.0, alpha: 1.0)
        splash.isUserInteractionEnabled = true

        let logoView = UIImageView(image: UIImage(named: "SplashLogo") ?? UIImage(named: "AppIcon"))
        logoView.translatesAutoresizingMaskIntoConstraints = false
        logoView.contentMode = .scaleAspectFit
        splash.addSubview(logoView)

        view.addSubview(splash)
        NSLayoutConstraint.activate([
            splash.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            splash.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            splash.topAnchor.constraint(equalTo: view.topAnchor),
            splash.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            logoView.centerXAnchor.constraint(equalTo: splash.centerXAnchor),
            logoView.centerYAnchor.constraint(equalTo: splash.centerYAnchor),
            logoView.widthAnchor.constraint(equalToConstant: 128),
            logoView.heightAnchor.constraint(equalToConstant: 128)
        ])

        gzdStartupSplashView = splash
        view.bringSubviewToFront(splash)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.gzdStartupSplashReady = true
            self?.hideStartupSplashWhenAllowed()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) { [weak self] in
            self?.forceHideStartupSplash()
        }
    }

    private func markStartupSplashReady() {
        gzdStartupSplashReady = true
        hideStartupSplashWhenAllowed()
    }

    private func hideStartupSplashWhenAllowed() {
        guard !gzdStartupSplashHidden, gzdStartupSplashView != nil, gzdStartupSplashReady else { return }

        let elapsed = Date().timeIntervalSince(gzdStartupSplashStartedAt)
        let remaining = max(0.0, 1.0 - elapsed)

        DispatchQueue.main.asyncAfter(deadline: .now() + remaining) { [weak self] in
            self?.forceHideStartupSplash()
        }
    }

    private func forceHideStartupSplash() {
        guard !gzdStartupSplashHidden else { return }
        gzdStartupSplashHidden = true

        guard let splash = gzdStartupSplashView else { return }
        gzdStartupSplashView = nil

        UIView.animate(withDuration: 0.18, animations: {
            splash.alpha = 0
        }, completion: { _ in
            splash.removeFromSuperview()
        })
    }

    private func showNavigationLoadingOverlay() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            if let existing = self.gzdNavigationLoadingView {
                self.view.bringSubviewToFront(existing)
                return
            }

            let overlay = UIView(frame: self.view.bounds)
            overlay.translatesAutoresizingMaskIntoConstraints = false
            overlay.backgroundColor = UIColor(red: 1.0, green: 253.0/255.0, blue: 244.0/255.0, alpha: 0.98)
            overlay.isUserInteractionEnabled = true

            let box = UIStackView()
            box.translatesAutoresizingMaskIntoConstraints = false
            box.axis = .vertical
            box.alignment = .center
            box.spacing = 14

            let spinner = UIActivityIndicatorView(style: .large)
            spinner.translatesAutoresizingMaskIntoConstraints = false
            spinner.color = UIColor(red: 248.0/255.0, green: 196.0/255.0, blue: 1.0/255.0, alpha: 1.0)
            spinner.startAnimating()

            let label = UILabel()
            label.translatesAutoresizingMaskIntoConstraints = false
            label.text = "Ładowanie..."
            label.textColor = UIColor(red: 16.0/255.0, green: 20.0/255.0, blue: 38.0/255.0, alpha: 1.0)
            label.font = UIFont.systemFont(ofSize: 18, weight: .bold)

            box.addArrangedSubview(spinner)
            box.addArrangedSubview(label)
            overlay.addSubview(box)
            self.view.addSubview(overlay)

            NSLayoutConstraint.activate([
                overlay.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
                overlay.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
                overlay.topAnchor.constraint(equalTo: self.view.topAnchor),
                overlay.bottomAnchor.constraint(equalTo: self.view.bottomAnchor),
                box.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
                box.centerYAnchor.constraint(equalTo: overlay.centerYAnchor)
            ])

            self.gzdNavigationLoadingView = overlay
            self.view.bringSubviewToFront(overlay)
        }
    }

    private func hideNavigationLoadingOverlay(after delay: Double = 0.0) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self = self, let overlay = self.gzdNavigationLoadingView else { return }
            self.gzdNavigationLoadingView = nil
            UIView.animate(withDuration: 0.16, animations: {
                overlay.alpha = 0
            }, completion: { _ in
                overlay.removeFromSuperview()
            })
        }
    }

    private func configureGZDAppLayer() {
        guard let webView = self.webView else { return }

        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = true
        webView.scrollView.alwaysBounceVertical = true
        updateGZDLandscapeSafeAreaVariables()

        let userContentController = webView.configuration.userContentController
        userContentController.add(self, name: "gzdShare")
        userContentController.add(self, name: "gzdOpenUrl")
        userContentController.add(self, name: "gzdGoBack")
        userContentController.add(self, name: "gzdResetNavigation")
        userContentController.add(self, name: "gzdSetLocalScreen")

        let nativeBridgeSource = """
        (function(){
          try {
            window.GZDNative = window.GZDNative || {};
            window.GZDNative.openUrl = function(url) {
              try { window.webkit.messageHandlers.gzdOpenUrl.postMessage(String(url || '')); } catch(e) {}
            };
            window.GZDNative.goBack = function() {
              try { window.webkit.messageHandlers.gzdGoBack.postMessage('back'); } catch(e) {}
            };
            window.GZDNative.resetNavigation = function() {
              try { window.webkit.messageHandlers.gzdResetNavigation.postMessage('reset'); } catch(e) {}
            };
            window.GZDNative.setLocalScreen = function(screen) {
              try { window.webkit.messageHandlers.gzdSetLocalScreen.postMessage(String(screen || '')); } catch(e) {}
            };
            window.GZDNative.share = function(title, url) {
              try {
                window.webkit.messageHandlers.gzdShare.postMessage({
                  title: String(title || 'Gdzie z dzieckiem'),
                  url: String(url || location.href),
                  text: 'Zobacz to miejsce w Gdzie z dzieckiem'
                });
              } catch(e) {}
            };
          } catch(e) {}
        })();
        """
        userContentController.addUserScript(WKUserScript(source: nativeBridgeSource, injectionTime: .atDocumentStart, forMainFrameOnly: false))

        let prehideHomeSource = """
        (function(){
          try {
            var host = String(location.hostname || '');
            var path = String(location.pathname || '/');
            if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
            var hostOk = host === 'gdziezdzieckiem.eu' || host === 'www.gdziezdzieckiem.eu' || host.endsWith('.gdziezdzieckiem.eu');
            var isHome = hostOk && (path === '' || path === '/') && !location.search && !location.hash;
            if (!isHome) return;
            var s = document.getElementById('gzd-prehide-style');
            if (!s) {
              s = document.createElement('style');
              s.id = 'gzd-prehide-style';
              s.textContent = 'html,body{background:#fffdf4!important;} body:not(.gzd-app-home-active){opacity:0!important;}';
              (document.head || document.documentElement).appendChild(s);
            }
          } catch(e) {}
        })();
        """
        userContentController.addUserScript(WKUserScript(source: prehideHomeSource, injectionTime: .atDocumentStart, forMainFrameOnly: true))

        if let source = loadGZDScript() {
            let script = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
            userContentController.addUserScript(script)

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
                self?.webView?.evaluateJavaScript(source, completionHandler: nil)
                self?.scheduleMapFix()
            }
        }
    }

    private func loadGZDScript() -> String? {
        if let cached = gzdScriptSource { return cached }

        let possibleUrls = [
            Bundle.main.url(forResource: "gzd-app-ui", withExtension: "js", subdirectory: "public"),
            Bundle.main.url(forResource: "gzd-app-ui", withExtension: "js")
        ]

        for url in possibleUrls {
            guard let url = url else { continue }
            if let source = try? String(contentsOf: url, encoding: .utf8), !source.isEmpty {
                gzdScriptSource = source
                return source
            }
        }

        return nil
    }

    private func isGZDInternalUrl(_ url: URL?) -> Bool {
        guard let url = url else { return false }
        let scheme = (url.scheme ?? "").lowercased()
        let host = (url.host ?? "").lowercased()
        guard scheme == "http" || scheme == "https" else { return false }

        return host == "gdziezdzieckiem.eu"
            || host == "www.gdziezdzieckiem.eu"
            || host.hasSuffix(".gdziezdzieckiem.eu")
            || host == "gdziezdzieckiem.pl"
            || host == "www.gdziezdzieckiem.pl"
            || host.hasSuffix(".gdziezdzieckiem.pl")
    }

    private func normalizedGZDUrl(_ url: URL) -> URL {
        var text = url.absoluteString

        text = text.replacingOccurrences(of: "https://www.gdziezdzieckiem.pl", with: "https://gdziezdzieckiem.eu")
        text = text.replacingOccurrences(of: "http://www.gdziezdzieckiem.pl", with: "https://gdziezdzieckiem.eu")
        text = text.replacingOccurrences(of: "https://gdziezdzieckiem.pl", with: "https://gdziezdzieckiem.eu")
        text = text.replacingOccurrences(of: "http://gdziezdzieckiem.pl", with: "https://gdziezdzieckiem.eu")
        text = text.replacingOccurrences(of: "https://www.gdziezdzieckiem.eu", with: "https://gdziezdzieckiem.eu")
        text = text.replacingOccurrences(of: "http://www.gdziezdzieckiem.eu", with: "https://gdziezdzieckiem.eu")
        text = text.replacingOccurrences(of: "http://gdziezdzieckiem.eu", with: "https://gdziezdzieckiem.eu")

        if text == "https://gdziezdzieckiem.eu" {
            text = "https://gdziezdzieckiem.eu/"
        }

        return URL(string: text) ?? url
    }

    private func isGZDHomeUrl(_ url: URL) -> Bool {
        let path = url.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        return isGZDInternalUrl(url) && path.isEmpty && (url.query == nil || url.query?.isEmpty == true) && (url.fragment == nil || url.fragment?.isEmpty == true)
    }

    private func rememberGZDNavigation(_ url: URL) {
        let normalized = normalizedGZDUrl(url)

        if isGZDHomeUrl(normalized) {
            gzdNavigationStack.removeAll()
            return
        }

        if gzdNavigationStack.last?.absoluteString != normalized.absoluteString {
            gzdNavigationStack.append(normalized)
        }

        if gzdNavigationStack.count > 40 {
            gzdNavigationStack.removeFirst(gzdNavigationStack.count - 40)
        }
    }

    private func renderAppHomeFromNative() {
        gzdNavigationStack.removeAll()
        gzdLocalScreen = nil
        gzdShowingLocalScreen = false
        showNavigationLoadingOverlay()
        webView?.scrollView.setContentOffset(.zero, animated: false)

        let js = """
        (function(){
          try {
            window.scrollTo(0, 0);
            document.documentElement.scrollTop = 0;
            document.body.scrollTop = 0;

            if (window.__GZD_RENDER_HOME__) {
              window.__GZD_RENDER_HOME__();
              history.replaceState(null, '', 'https://gdziezdzieckiem.eu/');

              window.scrollTo(0, 0);
              document.documentElement.scrollTop = 0;
              document.body.scrollTop = 0;

              setTimeout(function(){
                try {
                  window.scrollTo(0, 0);
                  document.documentElement.scrollTop = 0;
                  document.body.scrollTop = 0;
                  var root = document.getElementById('gzd-app-root');
                  var home = root && root.shadowRoot ? root.shadowRoot.querySelector('.gzd-home') : null;
                  if (home) home.scrollTop = 0;
                } catch(e) {}
              }, 60);

              return true;
            }
          } catch(e) {}
          return false;
        })();
        """

        webView?.evaluateJavaScript(js) { [weak self] _, _ in
            self?.webView?.scrollView.setContentOffset(.zero, animated: false)
            self?.hideNavigationLoadingOverlay(after: 0.55)
        }
    }

    private func openMapSectionInApp() {
        let js = """
        (function(){
          try {
            if (history && history.replaceState) history.replaceState(null, '', 'https://gdziezdzieckiem.eu/#brxe-qnovlp');
            if (window.__GZD_APP_UI_REINIT__) window.__GZD_APP_UI_REINIT__();
            if (window.__GZD_SCROLL_TO_HASH__) window.__GZD_SCROLL_TO_HASH__('#brxe-qnovlp');
            if (window.__GZD_FIX_MAPS__) window.__GZD_FIX_MAPS__();
          } catch(e) {}
        })();
        """
        webView?.evaluateJavaScript(js, completionHandler: nil)
        scheduleMapFix()
    }

    private func openUrlInsideApp(_ raw: String) {
        var value = raw
        var resetStack = false

        if value.hasPrefix("gzd-reset:") {
            resetStack = true
            value = String(value.dropFirst("gzd-reset:".count))
        }

        guard let url = URL(string: value), isGZDInternalUrl(url) else { return }
        let normalized = normalizedGZDUrl(url)

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            if resetStack {
                self.gzdNavigationStack.removeAll()
                self.gzdLocalScreen = nil
                self.gzdShowingLocalScreen = false
                self.gzdNavigationStack.append(normalized)
            } else {
                self.gzdShowingLocalScreen = false
                self.rememberGZDNavigation(normalized)
            }

            self.gzdRestoringBackNavigation = false
            self.showNavigationLoadingOverlay()

            let performLoad = { [weak self] in
                guard let self = self else { return }
                if normalized.fragment == "brxe-qnovlp" {
                    let forced = URL(string: "https://gdziezdzieckiem.eu/?gzd_app_map=1#brxe-qnovlp") ?? normalized
                    self.webView?.load(URLRequest(url: forced))
                    return
                }
                self.webView?.load(URLRequest(url: normalized))
            }

            // v2.10.2: zapis scrolla musi zakończyć się przed rozpoczęciem
            // kolejnej nawigacji. W przeciwnym razie WKWebView może zniszczyć
            // dokument listy zanim evaluateJavaScript zapisze jego stan.
            if let webView = self.webView {
                webView.evaluateJavaScript("try{window.__GZD_CAPTURE_SCROLL_STATE__&&window.__GZD_CAPTURE_SCROLL_STATE__()}catch(e){}") { _, _ in
                    performLoad()
                }
            } else {
                performLoad()
            }
        }
    }

    private func goBackInApp() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self, let webView = self.webView else { return }

            if self.gzdShowingLocalScreen {
                self.gzdShowingLocalScreen = false
                self.gzdLocalScreen = nil
                self.gzdRestoringBackNavigation = false
                self.renderAppHomeFromNative()
                return
            }

            if self.gzdNavigationStack.count > 1 {
                self.gzdNavigationStack.removeLast()
                if let previous = self.gzdNavigationStack.last {
                    let escaped = previous.absoluteString
                        .replacingOccurrences(of: "\\\\", with: "\\\\\\\\")
                        .replacingOccurrences(of: "'", with: "\\\\'")
                    let js = "try{window.__GZD_CAPTURE_SCROLL_STATE__&&window.__GZD_CAPTURE_SCROLL_STATE__();window.__GZD_MARK_SCROLL_RESTORE__&&window.__GZD_MARK_SCROLL_RESTORE__('\\(escaped)')}catch(e){}"
                    self.gzdRestoringBackNavigation = true
                    webView.evaluateJavaScript(js) { [weak self, weak webView] _, _ in
                        guard let self = self, let webView = webView else { return }
                        if webView.canGoBack {
                            webView.goBack()
                        } else {
                            // Brak wpisu w natywnej historii: ładujemy URL awaryjnie,
                            // ale nadal pozostawiamy tryb odtwarzania aktywny, aby
                            // progresywny mechanizm JS doładował listę i odnalazł kotwicę.
                            self.gzdRestoringBackNavigation = true
                            self.showNavigationLoadingOverlay()
                            webView.load(URLRequest(url: previous))
                        }
                    }
                    return
                }
            }

            if let localScreen = self.gzdLocalScreen,
               localScreen == "favorites" || localScreen == "recent" {
                self.gzdNavigationStack.removeAll()
                self.gzdShowingLocalScreen = true
                self.gzdRestoringBackNavigation = false
                self.showNavigationLoadingOverlay()
                let escapedScreen = localScreen.replacingOccurrences(of: "'", with: "\\'")
                let js = "try{window.__GZD_RENDER_LOCAL_SCREEN__&&window.__GZD_RENDER_LOCAL_SCREEN__('\\(escapedScreen)')}catch(e){}"
                webView.evaluateJavaScript(js) { [weak self] _, _ in
                    self?.hideNavigationLoadingOverlay(after: 0.2)
                }
                return
            }

            self.gzdRestoringBackNavigation = false
            self.renderAppHomeFromNative()
        }
    }

    private func scheduleMapFix() {
        let delays: [Double] = [0.15, 0.45, 1.0, 2.2, 3.5]
        for delay in delays {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                self?.fixMapRendering()
            }
        }
    }

    private func fixMapRendering() {
        let js = """
        (function(){
          try {
            window.dispatchEvent(new Event('resize'));
            if (window.__GZD_FIX_MAPS__) window.__GZD_FIX_MAPS__();
            if (window.__GZD_LEAFLET_MAPS__) {
              window.__GZD_LEAFLET_MAPS__.forEach(function(m){
                try { if (m && m.invalidateSize) m.invalidateSize(true); } catch(e) {}
              });
            }
            document.querySelectorAll('.leaflet-container').forEach(function(el){
              try {
                el.style.transform = 'translateZ(0)';
                el.style.webkitTransform = 'translateZ(0)';
              } catch(e) {}
            });
          } catch(e) {}
        })();
        """
        webView?.evaluateJavaScript(js, completionHandler: nil)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let source = loadGZDScript() {
            webView.evaluateJavaScript(source, completionHandler: nil)
        }

        let finishSource = """
        (function(){
          try {
            if (window.__GZD_APP_UI_REINIT__) window.__GZD_APP_UI_REINIT__();
            var path = String(location.pathname || '/');
            if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
            var isHome = (path === '' || path === '/') && !location.search && !location.hash;
            if (isHome && window.__GZD_RENDER_HOME__) window.__GZD_RENDER_HOME__();
            window.__GZD_APP_READY__ = true;
          } catch(e) {}
        })();
        """

        if let currentUrl = webView.url, isGZDInternalUrl(currentUrl), !isGZDHomeUrl(currentUrl), gzdNavigationStack.isEmpty {
            rememberGZDNavigation(currentUrl)
        }

        updateGZDLandscapeSafeAreaVariables()
        let wasRestoringBackNavigation = gzdRestoringBackNavigation
        if wasRestoringBackNavigation {
            webView.evaluateJavaScript("try{window.__GZD_RESTORE_SCROLL_STATE__&&window.__GZD_RESTORE_SCROLL_STATE__()}catch(e){}", completionHandler: nil)
            gzdRestoringBackNavigation = false
        }

        webView.evaluateJavaScript(finishSource) { [weak self] _, _ in
            if let current = webView.url, current.fragment == "brxe-qnovlp" {
                if wasRestoringBackNavigation {
                    self?.scheduleMapFix()
                } else {
                    self?.openMapSectionInApp()
                }
                self?.hideNavigationLoadingOverlay(after: wasRestoringBackNavigation ? 0.35 : 1.25)
            } else {
                self?.scheduleMapFix()
                self?.hideNavigationLoadingOverlay(after: 0.25)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                self?.markStartupSplashReady()
            }
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        hideNavigationLoadingOverlay(after: 0.1)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        hideNavigationLoadingOverlay(after: 0.1)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let url = navigationAction.request.url else {
            return nil
        }

        if isGZDInternalUrl(url) {
            webView.load(URLRequest(url: normalizedGZDUrl(url)))
            return nil
        }

        // v2.10.2: Safari otwieramy tylko po świadomym kliknięciu użytkownika.
        // Automatyczne popupy/iframe/przekierowania po starcie są ignorowane,
        // żeby aplikacja nie wyskakiwała do przeglądarki z białym ekranem.
        let scheme = (url.scheme ?? "").lowercased()
        if (scheme == "http" || scheme == "https") && navigationAction.navigationType == .linkActivated {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }

        return nil
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }

        let scheme = (url.scheme ?? "").lowercased()
        let isMainFrame = navigationAction.targetFrame?.isMainFrame ?? true

        if isGZDInternalUrl(url) {
            let normalized = normalizedGZDUrl(url)
            if navigationAction.navigationType == .backForward,
               isGZDHomeUrl(normalized),
               gzdLocalScreen == "favorites" || gzdLocalScreen == "recent" {
                decisionHandler(.cancel)
                DispatchQueue.main.async { [weak self] in
                    self?.goBackInApp()
                }
                return
            }
            if navigationAction.targetFrame?.isMainFrame ?? true {
                if navigationAction.navigationType == .backForward,
                   let index = gzdNavigationStack.lastIndex(where: { $0.absoluteString == normalized.absoluteString }) {
                    gzdNavigationStack = Array(gzdNavigationStack.prefix(index + 1))
                } else {
                    rememberGZDNavigation(normalized)
                }
            }

            if normalized.absoluteString != url.absoluteString || navigationAction.targetFrame == nil {
                webView.load(URLRequest(url: normalized))
                decisionHandler(.cancel)
                return
            }

            decisionHandler(.allow)
            return
        }

        if scheme == "http" || scheme == "https" {
            // v2.10.2:
            // Safari otwiera się tylko po kliknięciu użytkownika w zewnętrzny link.
            // Automatyczne zewnętrzne przekierowania głównej ramki blokujemy,
            // a subramki/iframe pozwalamy załadować w WebView.
            if navigationAction.navigationType == .linkActivated {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                decisionHandler(.cancel)
                return
            }

            if isMainFrame {
                decisionHandler(.cancel)
                return
            }

            decisionHandler(.allow)
            return
        }

        decisionHandler(.allow)
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "gzdOpenUrl" {
            if let urlString = message.body as? String {
                openUrlInsideApp(urlString)
            }
            return
        }

        if message.name == "gzdGoBack" {
            goBackInApp()
            return
        }

        if message.name == "gzdResetNavigation" {
            gzdNavigationStack.removeAll()
            gzdLocalScreen = nil
            gzdShowingLocalScreen = false
            return
        }

        if message.name == "gzdSetLocalScreen" {
            let screen = (message.body as? String) ?? ""
            if screen == "favorites" || screen == "recent" {
                gzdLocalScreen = screen
                gzdShowingLocalScreen = true
            } else {
                gzdLocalScreen = nil
                gzdShowingLocalScreen = false
            }
            return
        }

        guard message.name == "gzdShare" else { return }

        var title = "Gdzie z dzieckiem"
        var urlString = ""
        var text = "Zobacz to miejsce w Gdzie z dzieckiem"

        if let payload = message.body as? [String: Any] {
            if let value = payload["title"] as? String, !value.isEmpty { title = value }
            if let value = payload["url"] as? String, !value.isEmpty { urlString = value }
            if let value = payload["text"] as? String, !value.isEmpty { text = value }
        }

        var items: [Any] = [text + "\\n" + title]
        if let url = URL(string: urlString) {
            items.append(url)
        } else if !urlString.isEmpty {
            items.append(urlString)
        }

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let activity = UIActivityViewController(activityItems: items, applicationActivities: nil)
            if let popover = activity.popoverPresentationController {
                popover.sourceView = self.view
                popover.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.maxY - 120, width: 1, height: 1)
                popover.permittedArrowDirections = []
            }
            self.present(activity, animated: true, completion: nil)
        }
    }
}

${end}`;

  const re = new RegExp(`${start}[\\s\\S]*?${end}`, 'm');
  if (re.test(appDelegate)) {
    appDelegate = appDelegate.replace(re, block);
  } else {
    appDelegate = appDelegate.trimEnd() + '\n\n' + block + '\n';
  }

  fs.writeFileSync(appDelegatePath, appDelegate);
  console.log('iOS: dodano GZDViewController do AppDelegate.swift, więc klasa jest w targetcie Xcode.');
} else {
  console.log('iOS: AppDelegate.swift nie istnieje jeszcze. Patch wykona się po npx cap add ios.');
}

if (fs.existsSync(storyboardPath)) {
  let storyboard = fs.readFileSync(storyboardPath, 'utf8');
  storyboard = storyboard.replace(/customClass="CAPBridgeViewController"/g, 'customClass="GZDViewController"');
  storyboard = storyboard.replace(/customModule="Capacitor"/g, 'customModule="App"');

  if (storyboard.includes('customClass="GZDViewController"') && !storyboard.includes('customModule="App"')) {
    storyboard = storyboard.replace(/customClass="GZDViewController"/g, 'customClass="GZDViewController" customModule="App" customModuleProvider="target"');
  }

  fs.writeFileSync(storyboardPath, storyboard);
  console.log('iOS: Main.storyboard używa GZDViewController.');
} else {
  console.log('iOS: Main.storyboard nie istnieje jeszcze. Patch wykona się po npx cap add ios.');
}
