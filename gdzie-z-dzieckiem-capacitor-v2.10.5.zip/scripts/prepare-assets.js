const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const assetsDir = path.join(root, 'assets');
const sourceIcon = path.join(assetsDir, 'app-icon.png');
const sourceSplashLogo = path.join(assetsDir, 'splash-logo.png');
const bg = '#f8c401';

function fail(msg) {
  console.error(msg);
  process.exit(1);
}

if (!fs.existsSync(sourceIcon)) fail('Brak assets/app-icon.png');
if (!fs.existsSync(sourceSplashLogo)) fail('Brak assets/splash-logo.png');

let sharp;
try {
  sharp = require('sharp');
} catch (e) {
  fail('Brak biblioteki sharp. Uruchom najpierw: npm install');
}

async function makeIcon() {
  // Klasyczna ikona: pełny żółty kwadrat 1024x1024 z grafiką na środku.
  const foreground = await sharp(sourceIcon)
    .resize({ width: 720, height: 720, fit: 'inside', withoutEnlargement: false })
    .png()
    .toBuffer();

  await sharp({
    create: {
      width: 1024,
      height: 1024,
      channels: 4,
      background: bg,
    },
  })
    .composite([{ input: foreground, gravity: 'center' }])
    .png()
    .toFile(path.join(assetsDir, 'icon.png'));

  // Adaptive icon foreground: przezroczyste tło i znak bezpiecznie w środku.
  const adaptiveForeground = await sharp(sourceIcon)
    .resize({ width: 620, height: 620, fit: 'inside', withoutEnlargement: false })
    .png()
    .toBuffer();

  await sharp({
    create: {
      width: 1024,
      height: 1024,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    },
  })
    .composite([{ input: adaptiveForeground, gravity: 'center' }])
    .png()
    .toFile(path.join(assetsDir, 'icon-foreground.png'));

  await sharp({
    create: {
      width: 1024,
      height: 1024,
      channels: 4,
      background: bg,
    },
  })
    .png()
    .toFile(path.join(assetsDir, 'icon-background.png'));
}

async function makeSplash() {
  const logo = await sharp(sourceSplashLogo)
    .resize({ width: 900, height: 900, fit: 'inside', withoutEnlargement: false })
    .png()
    .toBuffer();

  await sharp({
    create: {
      width: 2732,
      height: 2732,
      channels: 4,
      background: bg,
    },
  })
    .composite([{ input: logo, gravity: 'center' }])
    .png()
    .toFile(path.join(assetsDir, 'splash.png'));
}

(async () => {
  await makeIcon();
  await makeSplash();
  console.log('Wygenerowano assets/icon.png, icon-foreground.png, icon-background.png i splash.png z nowym logo splash');
})();
