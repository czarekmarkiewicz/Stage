const fs = require('fs');
const path = require('path');

const src = path.join(__dirname, '..', 'src');
const dist = path.join(__dirname, '..', 'dist');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
for (const file of fs.readdirSync(src)) {
  fs.copyFileSync(path.join(src, file), path.join(dist, file));
}

const assets = path.join(__dirname, '..', 'assets');
for (const [from, to] of [['app-icon.png', 'app-icon.png'], ['splash-logo.png', 'splash-logo.png'], ['splash-logo.webp', 'splash-logo.webp']]) {
  const source = path.join(assets, from);
  if (fs.existsSync(source)) fs.copyFileSync(source, path.join(dist, to));
  else console.warn(`Brak assets/${from}. Dodaj plik przed finalnym buildem.`);
}

const heroFromPublic = path.join(__dirname, '..', 'public', 'hero-banner.png');
const heroFromAssets = path.join(__dirname, '..', 'assets', 'hero-banner.png');
const heroSource = fs.existsSync(heroFromPublic) ? heroFromPublic : heroFromAssets;

if (fs.existsSync(heroSource)) {
  fs.copyFileSync(heroSource, path.join(dist, 'hero-banner.png'));
  const publicDist = path.join(dist, 'public');
  fs.mkdirSync(publicDist, { recursive: true });
  fs.copyFileSync(heroSource, path.join(publicDist, 'hero-banner.png'));
} else {
  console.warn('Brak hero-banner.png. Baner startowy będzie miał tylko żółte tło.');
}

function copyOptionalPublicAsset(fileName) {
  const fromPublic = path.join(__dirname, '..', 'public', fileName);
  const fromAssets = path.join(__dirname, '..', 'assets', fileName);
  const source = fs.existsSync(fromPublic) ? fromPublic : fromAssets;

  if (fs.existsSync(source)) {
    fs.copyFileSync(source, path.join(dist, fileName));
    const publicDist = path.join(dist, 'public');
    fs.mkdirSync(publicDist, { recursive: true });
    fs.copyFileSync(source, path.join(publicDist, fileName));
  } else {
    console.warn(`Brak ${fileName}.`);
  }
}

copyOptionalPublicAsset('hero-banner.png');
copyOptionalPublicAsset('hero-art.png');


copyOptionalPublicAsset('hero-list-bg.png');
