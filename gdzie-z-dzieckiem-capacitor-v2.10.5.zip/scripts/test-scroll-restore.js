const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const web = read('src/gzd-app-ui.js');
const restoreModule = read('src/gzd-scroll-restore.js');
const android = read('scripts/patch-android.js');
const ios = read('scripts/patch-ios.js');
const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));

function includes(source, fragment, label) {
  assert(source.includes(fragment), `Brak wymaganej poprawki: ${label || fragment}`);
}

assert.strictEqual(pkg.version, '2.10.5', 'Nieprawidłowa wersja package.json');
assert.strictEqual(lock.version, '2.10.5', 'Nieprawidłowa wersja package-lock.json');
assert.strictEqual(lock.packages[''].version, '2.10.5', 'Nieprawidłowa wersja pakietu głównego w lockfile');

// Lekki moduł jest wstrzykiwany także do zdalnych dokumentów Android WebView.
includes(restoreModule, '__GZD_SCROLL_RESTORE_MODULE_V6__', 'identyfikator osobnego modułu scroll restore');
includes(restoreModule, 'installNavigationStatePersistence();', 'automatyczna instalacja modułu scroll restore');
includes(restoreModule, 'gzd_navigation_scroll_v2:', 'wspólny magazyn stanu modułu');
includes(restoreModule, 'exactLoadMore', 'obsługa tekstu Załaduj więcej także na zwykłym odnośniku');

// Regresja v2.10.5: powrót z pinezki odtwarza dokładną pozycję użytkownika.
[
  ['isMapNavigationUrl', 'rozpoznawanie trasy mapy'],
  ["routeMode: mapDocument ? 'map' : 'document'", 'oznaczenie stanu mapy'],
  ["const absoluteOnly = state.routeMode === 'map'", 'odtwarzanie mapy wyłącznie po współrzędnej'],
  ['absoluteOnly ? 0 : listAnchorCandidates().length', 'brak zastępczej kotwicy listy na mapie'],
  ['hasPendingNavigationRestoreForCurrentUrl', 'wykrywanie trwającego powrotu'],
  ['__GZD_HAS_PENDING_SCROLL_RESTORE__', 'udostępnienie stanu powrotu warstwie UI'],
  ['__GZD_RESTORED_NAVIGATION_URL__', 'trwała blokada późniejszego hash-scrolla po odtworzeniu'],
].forEach(([fragment, label]) => {
  includes(web, fragment, label);
  includes(restoreModule, fragment, `${label} w lekkim module`);
});
assert(!web.includes('restoreMapNavigationViewport'), 'Nie wolno wymuszać sekcji mapy podczas cofania');
assert(!restoreModule.includes('restoreMapNavigationViewport'), 'Lekki moduł nie może wymuszać sekcji mapy');
includes(web, "if (!hasPendingNavigationRestoreForCurrentUrl()) scheduleHashScroll", 'brak konfliktu hash-scroll z odtwarzaniem');
includes(web, 'cancelledForRestore', 'trwałe anulowanie opóźnionych skoków mapy po cofnięciu');

// Regresja Android v2.10.5: WebView otwiera mapę przez gzd_app_map=1,
// natomiast stos aplikacji przechowuje publiczny URL z hashem. Obie postacie
// muszą wskazywać ten sam klucz stanu przewinięcia.
[
  ['const mapNavigation =', 'wykrycie mapy przed usunięciem parametru technicznego'],
  ["if (mapNavigation) url.hash = '#brxe-qnovlp';", 'kanoniczny hash mapy'],
  ['__GZD_NAVIGATION_STATE_INSTALLED_V3__', 'instalacja poprawionego mechanizmu mimo starszej wersji w dokumencie'],
].forEach(([fragment, label]) => {
  includes(web, fragment, label);
  includes(restoreModule, fragment, `${label} w lekkim module`);
});
includes(android, 'markWebScrollRestore(webLoadUrlFor(previous)', 'marker zgodny z rzeczywistym URL ładowanym przez Android WebView');

function normalizeNavigationUrlForRegression(rawUrl) {
  const url = new URL(rawUrl, 'https://gdziezdzieckiem.eu/');
  const mapNavigation = url.hash === '#brxe-qnovlp' || url.searchParams.get('gzd_app_map') === '1';
  url.protocol = 'https:';
  url.hostname = 'gdziezdzieckiem.eu';
  url.searchParams.delete('gzd_app_map');
  if (mapNavigation) url.hash = '#brxe-qnovlp';
  const pathname = url.pathname || '/';
  if (pathname !== '/' && !pathname.endsWith('/') && !/\/[^/]+\.[a-z0-9]{1,8}$/i.test(pathname)) {
    url.pathname = pathname + '/';
  }
  return url.href;
}
const publicMapUrl = normalizeNavigationUrlForRegression('https://gdziezdzieckiem.eu/#brxe-qnovlp');
const androidMapUrl = normalizeNavigationUrlForRegression('https://gdziezdzieckiem.eu/?gzd_app_map=1');
assert.strictEqual(androidMapUrl, publicMapUrl, 'Android i publiczny URL mapy muszą używać jednego klucza scrolla');
assert.notStrictEqual(publicMapUrl, normalizeNavigationUrlForRegression('https://gdziezdzieckiem.eu/'), 'Mapa nie może współdzielić klucza ze zwykłą stroną główną');

// Stan listy jest identyfikowany semantycznie, a nie wyłącznie współrzędną Y.
[
  ['gzd_navigation_scroll_v2:', 'magazyn stanu v2'],
  ['anchorUrl:', 'URL klikniętej/widocznej atrakcji'],
  ['anchorOccurrence:', 'obsługa powtarzających się odnośników'],
  ['anchorIndex:', 'awaryjny indeks kotwicy'],
  ['loadedAnchorCount:', 'liczba elementów już doładowanych'],
  ['findAnchorBySavedIndex', 'awaryjne odtwarzanie po indeksie'],
  ['triggerProgressiveListLoad', 'progresywne doładowywanie listy'],
  ['MutationObserver', 'reakcja na asynchroniczne zmiany DOM'],
  ['RESTORE_MAX_DURATION = 30000', 'długi limit dla list nieskończonych'],
  ["history.scrollRestoration = 'manual'", 'wyłączenie konfliktującego auto-scrolla WebView'],
  ['__GZD_SCROLL_RESTORE_ACTIVE__', 'blokada zapisu w trakcie odtwarzania'],
  ['Ładowanie...', 'osłona podczas odtwarzania'],
  ['captureNavigationScrollState(anchor)', 'zapis przed przejściem do atrakcji'],
].forEach(([fragment, label]) => includes(web, fragment, label));

assert(!web.includes('__GZD_APP_UI_V40__'), 'Pozostał stary identyfikator skryptu V40');
assert(!web.includes('__GZD_APP_UI_V42__'), 'Pozostał stary identyfikator skryptu V42');
assert(!web.includes('__GZD_APP_UI_V43__'), 'Pozostał stary identyfikator skryptu V43');
assert(!web.includes('__GZD_APP_UI_V44__'), 'Pozostał stary identyfikator skryptu V44');
assert(!web.includes('__GZD_APP_UI_V45__'), 'Pozostał stary identyfikator skryptu V45');
includes(web, '__GZD_APP_UI_V46__', 'nowy identyfikator skryptu V46');
includes(web, 'v2.10.5</div>', 'widoczna wersja 2.10.5');

// Regresja v2.10.5: surowe komentarze konfiguracyjne strony nie mogą być widoczne nad ekranem startowym iOS.
includes(web, 'WEBSITE_CODE_ARTIFACT_MARKERS', 'lista znanych artefaktów tekstowych strony');
includes(web, "'skrypt do pop-up'", 'marker komentarza pobrania aplikacji');
includes(web, "'skrypty dla geolokalizacji'", 'marker komentarza geolokalizacji');
includes(web, 'document.createTreeWalker(document.body, 4)', 'bezpieczne wyszukiwanie tekstowych artefaktów DOM');
includes(web, "parent.closest('script,style,noscript,template,textarea')", 'ochrona prawidłowych skryptów i stylów');
assert((web.match(/removeWebsiteCodeArtifacts\(\);/g) || []).length >= 3, 'Czyszczenie artefaktów musi działać przy inicjalizacji, renderze Start i zmianach DOM');

const websiteArtifactSample = '/*Skrypt do pop-up "ściągnij aplikację" */ /* Skrypt do pop up oceń aplikację */ /* Skrypty dla geolokalizacji*/';
const normalizedArtifactSample = websiteArtifactSample.toLocaleLowerCase('pl-PL').replace(/[„”]/g, '"').replace(/\s+/g, ' ');
assert(['skrypt do pop-up', 'skrypt do pop up', 'skrypty dla geolokalizacji'].some(marker => normalizedArtifactSample.includes(marker)), 'Próbka artefaktu strony nie została rozpoznana');

// Regresja v2.10.5: pełne listy Ulubione/Ostatnio oglądane są osobnym krokiem historii.
includes(web, 'setNativeLocalScreen(APP_SCREEN);', 'rejestracja lokalnego ekranu przed otwarciem atrakcji');
includes(web, '__GZD_RENDER_LOCAL_SCREEN__', 'odtworzenie lokalnego ekranu przez warstwę natywną');
includes(ios, 'gzdLocalScreen', 'stan lokalnego ekranu iOS');
includes(ios, 'gzdShowingLocalScreen', 'rozróżnienie listy lokalnej od atrakcji iOS');
includes(ios, 'gzdSetLocalScreen', 'most lokalnego ekranu iOS');
includes(ios, 'window.__GZD_RENDER_LOCAL_SCREEN__', 'powrót iOS do listy lokalnej');
includes(ios, "__GZD_RENDER_LOCAL_SCREEN__('\\\\(escapedScreen)')", 'interpolacja nazwy lokalnego ekranu w wygenerowanym Swift');
includes(ios, 'if self.gzdShowingLocalScreen', 'kolejne cofnięcie iOS z listy lokalnej do Start');
includes(android, 'localReturnScreen', 'stan lokalnego ekranu Android');
includes(android, 'showListScreen(localReturnScreen);', 'powrót Android do listy lokalnej');

// Android: poprzedni URL jest ładowany z jawnego stosu aplikacji, a nie z natywnej historii WebView.
includes(android, 'navigateToUrlNow(previous, false, true, commandId);', 'deterministyczny powrót Android do poprzedniego URL');
includes(android, 'public/gzd-scroll-restore.js', 'wstrzyknięcie lekkiego modułu do Android WebView');
includes(android, 'injectNavigationStateScript', 'sekwencyjne wstrzyknięcie modułu Android');
includes(android, 'if (commandId != navigationCommandId) return;', 'odrzucanie spóźnionych callbacków Android');
includes(android, 'backNavigationInProgress', 'blokada równoległego cofania Android');
includes(android, 'preserveMapViewportForCurrentLoad', 'ochrona dokładnej pozycji mapy Android');
includes(android, 'revealWebPage(preserveMapViewport)', 'brak natywnego snapowania mapy przy powrocie');
includes(android, 'webView.loadUrl("about:blank")', 'odłączenie starego dokumentu Android');
includes(android, 'try { view.clearHistory(); }', 'czyszczenie natywnej historii Android');
assert(!android.includes('webView.goBack()'), 'Android nie może używać WebView.goBack()');
assert(!android.includes('webView.canGoBack()'), 'Android nie może używać WebView.canGoBack()');
assert(!android.includes('restoreOnNextLoad'), 'Pozostała stara flaga restoreOnNextLoad');
includes(android, 'android-native-v2.10.5', 'wersja natywnej powłoki Android');
includes(android, 'TextView version = tv("v2.10.5"', 'widoczna wersja Android');
includes(web, 'gzd-hero-banner-copy', 'osobny tekst banera w poziomie');
includes(web, 'display: none !important;', 'ukrycie rastrowego tekstu banera w poziomie');
includes(android, 'createLandscapeHomeHero()', 'dedykowany poziomy baner Android');
includes(android, 'setImageFromAsset(bg, "public/hero-art.png")', 'grafika tła poziomego banera Android');
includes(android, 'settings.setGeolocationEnabled(true);', 'włączenie geolokalizacji Android WebView');
includes(android, 'onGeolocationPermissionsShowPrompt', 'obsługa geolokalizacji Android WebView');
includes(ios, 'NSLocationWhenInUseUsageDescription', 'opis uprawnienia lokalizacji iOS');


// Regresja v2.10.5: patch JS musi wygenerować w Javie sekwencję \n, a nie fizyczny podział linii wewnątrz literału.
includes(android, 'tv("Co dziś robimy\\\\nz dzieckiem?"', 'poprawnie escapowany nagłówek poziomego banera Android');
includes(android, 'tv("Znajdź atrakcje, miejsca\\\\ni pomysły na wspólny czas."', 'poprawnie escapowany podtytuł poziomego banera Android');

// iOS: zapis stanu musi zakończyć się przed nową nawigacją, a fallback URL nadal odtwarza listę.
includes(ios, 'let performLoad =', 'sekwencyjny zapis i nawigacja iOS');
includes(ios, 'webView.evaluateJavaScript("try{window.__GZD_CAPTURE_SCROLL_STATE__', 'zapis scrolla iOS przed load');
includes(ios, 'if webView.canGoBack', 'natywna historia WKWebView');
includes(ios, 'self.gzdRestoringBackNavigation = true', 'tryb odtwarzania iOS');
includes(ios, 'window.__GZD_RESTORE_SCROLL_STATE__', 'wywołanie odtwarzania iOS');
includes(ios, 'wasRestoringBackNavigation', 'rozróżnienie pierwszego wejścia na mapę od cofania iOS');
includes(ios, 'navigationAction.navigationType == .backForward', 'obsługa gestu cofania iOS');
includes(ios, 'isGZDHomeUrl(normalized)', 'powrót gestem do lokalnego ekranu zamiast Start');

// Model krytycznego przypadku: kotwica istnieje dopiero po kilku porcjach listy.
const batches = [10, 20, 30, 40, 50];
const savedAnchorIndex = 34;
let loads = 0;
let count = batches[0];
while (count <= savedAnchorIndex && loads < batches.length - 1) {
  loads += 1;
  count = batches[loads];
}
assert(count > savedAnchorIndex, 'Model nie doładował porcji zawierającej zapisaną atrakcję');
assert.strictEqual(loads, 3, 'Model powinien doładować dokładnie trzy kolejne porcje');

console.log('OK: v2.10.5 zawiera progresywne odtwarzanie listy i deterministyczną historię Android.');
