'use strict';

const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const compileSdk = String(process.env.ANDROID_COMPILE_SDK || '37');
const targetSdk = String(process.env.ANDROID_TARGET_SDK || '37');
const agpVersion = String(process.env.ANDROID_GRADLE_PLUGIN_VERSION || '9.2.1');
const gradleVersion = String(process.env.ANDROID_GRADLE_VERSION || '9.5.1');
const googleServicesVersion = String(process.env.GOOGLE_SERVICES_PLUGIN_VERSION || '4.5.0');

function read(relativePath) {
  const filePath = path.join(projectRoot, relativePath);
  if (!fs.existsSync(filePath)) {
    throw new Error(`Nie znaleziono pliku wymaganego do konfiguracji API 37: ${relativePath}`);
  }
  return { filePath, text: fs.readFileSync(filePath, 'utf8') };
}

function write(relativePath, transform) {
  const { filePath, text } = read(relativePath);
  const updated = transform(text);
  if (updated === text) {
    console.log(`Bez zmian: ${relativePath}`);
  } else {
    fs.writeFileSync(filePath, updated);
    console.log(`Zaktualizowano: ${relativePath}`);
  }
}

function replaceRequired(text, pattern, replacement, description, relativePath) {
  if (!pattern.test(text)) {
    throw new Error(`Nie znaleziono wzorca „${description}” w ${relativePath}`);
  }
  pattern.lastIndex = 0;
  return text.replace(pattern, replacement);
}

function modernizeAndroidGradle(text) {
  return text
    .replace(/^(\s*)namespace\s+"([^"]+)"\s*$/gm, '$1namespace = "$2"')
    .replace(/^(\s*)compileSdk\s+(.+)$/gm, '$1compileSdk = $2')
    .replace(/^(\s*)url\s+"(https:\/\/plugins\.gradle\.org\/m2\/)"\s*$/gm, '$1url = "$2"')
    .replace(/^(\s*)abortOnError\s+(true|false)\s*$/gm, '$1abortOnError = $2')
    .replace(/^(\s*)warningsAsErrors\s+(true|false)\s*$/gm, '$1warningsAsErrors = $2')
    .replace(/^(\s*)lintConfig\s+file\((.+)\)\s*$/gm, '$1lintConfig = file($2)')
    .replace(/^(\s*)ignoreAssetsPattern\s+(.+)$/gm, '$1ignoreAssetsPattern = $2')
    .replace(/getDefaultProguardFile\(['"]proguard-android\.txt['"]\)/g, "getDefaultProguardFile('proguard-android-optimize.txt')");
}

const variablesPath = 'android/variables.gradle';
write(variablesPath, (text) => {
  let updated = replaceRequired(
    text,
    /compileSdkVersion\s*=\s*\d+/,
    `compileSdkVersion = ${compileSdk}`,
    'compileSdkVersion',
    variablesPath,
  );
  updated = replaceRequired(
    updated,
    /targetSdkVersion\s*=\s*\d+/,
    `targetSdkVersion = ${targetSdk}`,
    'targetSdkVersion',
    variablesPath,
  );
  return updated;
});

const rootBuildPath = 'android/build.gradle';
write(rootBuildPath, (text) => {
  let updated = replaceRequired(
    text,
    /com\.android\.tools\.build:gradle:[^'"\s]+/,
    `com.android.tools.build:gradle:${agpVersion}`,
    'wersja Android Gradle Plugin',
    rootBuildPath,
  );
  updated = updated.replace(
    /com\.google\.gms:google-services:[^'"\s]+/g,
    `com.google.gms:google-services:${googleServicesVersion}`,
  );
  return modernizeAndroidGradle(updated);
});

const wrapperPath = 'android/gradle/wrapper/gradle-wrapper.properties';
write(wrapperPath, (text) => replaceRequired(
  text,
  /distributionUrl=https\\:\/\/services\.gradle\.org\/distributions\/gradle-[^-\s]+-(?:all|bin)\.zip/,
  `distributionUrl=https\\://services.gradle.org/distributions/gradle-${gradleVersion}-all.zip`,
  'distributionUrl Gradle Wrapper',
  wrapperPath,
));

const gradleFiles = [
  'android/app/build.gradle',
  'android/capacitor-cordova-android-plugins/build.gradle',
  'node_modules/@capacitor/android/capacitor/build.gradle',
  'node_modules/@capacitor/app/android/build.gradle',
  'node_modules/@capacitor/network/android/build.gradle',
  'node_modules/@capacitor/splash-screen/android/build.gradle',
  'node_modules/@capacitor/share/android/build.gradle',
];

for (const relativePath of gradleFiles) {
  write(relativePath, (text) => {
    let updated = text.replace(
      /com\.android\.tools\.build:gradle:[^'"\s]+/g,
      `com.android.tools.build:gradle:${agpVersion}`,
    );
    updated = modernizeAndroidGradle(updated);
    return updated;
  });
}

console.log(
  `Android API skonfigurowane: compileSdk=${compileSdk}, targetSdk=${targetSdk}, ` +
  `AGP=${agpVersion}, Gradle=${gradleVersion}. minSdk pozostaje bez zmian.`,
);
