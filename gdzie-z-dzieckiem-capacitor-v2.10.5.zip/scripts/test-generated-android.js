const assert = require('assert');
const fs = require('fs');
const path = require('path');

const javaFile = path.join(
  __dirname,
  '..',
  'android',
  'app',
  'src',
  'main',
  'java',
  'eu',
  'gdziezdzieckiem',
  'app',
  'MainActivity.java'
);

assert(fs.existsSync(javaFile), `Brak wygenerowanego pliku: ${javaFile}`);
const source = fs.readFileSync(javaFile, 'utf8');

assert(source.includes('android-native-v2.10.5'), 'Wygenerowany Android ma nieprawidłową wersję.');
assert(source.includes('TextView h = tv("Co dziś robimy\\nz dzieckiem?"'),
  'Nagłówek banera nie zawiera poprawnie escapowanej sekwencji \\n.');
assert(source.includes('TextView s = tv("Znajdź atrakcje, miejsca\\ni pomysły na wspólny czas."'),
  'Podtytuł banera nie zawiera poprawnie escapowanej sekwencji \\n.');
assert(source.includes('private View createLandscapeHomeHero()'),
  'Brak dedykowanego poziomego banera Android.');

assert(source.includes('settings.setGeolocationEnabled(true);'),
  'Wygenerowany Android nie włącza geolokalizacji WebView.');
assert(source.includes('onGeolocationPermissionsShowPrompt'),
  'Wygenerowany Android nie obsługuje żądania geolokalizacji strony.');
assert(source.includes('Manifest.permission.ACCESS_FINE_LOCATION'),
  'Wygenerowany Android nie żąda dokładnej lokalizacji.');
assert(source.includes('Manifest.permission.ACCESS_COARSE_LOCATION'),
  'Wygenerowany Android nie obsługuje lokalizacji przybliżonej.');

const onDestroyCount = (source.match(/protected\s+void\s+onDestroy\s*\(/g) || []).length;
assert.strictEqual(
  onDestroyCount,
  1,
  `MainActivity.java musi zawierać dokładnie jedną metodę onDestroy(), znaleziono: ${onDestroyCount}.`
);

// Minimalny lexer sprawdzający, czy którykolwiek literał tekstowy Javy
// został przerwany fizycznym znakiem nowej linii. Taki błąd wcześniej
// przechodził test źródła patcha, ale zatrzymywał javac.
let state = 'code';
let escaped = false;
let line = 1;
for (let i = 0; i < source.length; i += 1) {
  const ch = source[i];
  const next = source[i + 1];

  if (state === 'line-comment') {
    if (ch === '\n') {
      state = 'code';
      line += 1;
    }
    continue;
  }
  if (state === 'block-comment') {
    if (ch === '*' && next === '/') {
      state = 'code';
      i += 1;
    } else if (ch === '\n') {
      line += 1;
    }
    continue;
  }
  if (state === 'string') {
    if (ch === '\n' || ch === '\r') {
      throw new Error(`Fizyczny podział linii wewnątrz literału String w MainActivity.java, okolice linii ${line}.`);
    }
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      escaped = true;
      continue;
    }
    if (ch === '"') state = 'code';
    continue;
  }
  if (state === 'char') {
    if (ch === '\n' || ch === '\r') {
      throw new Error(`Fizyczny podział linii wewnątrz literału char w MainActivity.java, okolice linii ${line}.`);
    }
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      escaped = true;
      continue;
    }
    if (ch === "'") state = 'code';
    continue;
  }

  if (ch === '/' && next === '/') {
    state = 'line-comment';
    i += 1;
  } else if (ch === '/' && next === '*') {
    state = 'block-comment';
    i += 1;
  } else if (ch === '"') {
    state = 'string';
    escaped = false;
  } else if (ch === "'") {
    state = 'char';
    escaped = false;
  } else if (ch === '\n') {
    line += 1;
  }
}

assert.strictEqual(state, 'code', `MainActivity.java kończy się w niedomkniętym stanie leksykalnym: ${state}`);
console.log('OK: wygenerowany MainActivity.java v2.10.5 ma poprawne literały tekstowe i poziomy baner.');
