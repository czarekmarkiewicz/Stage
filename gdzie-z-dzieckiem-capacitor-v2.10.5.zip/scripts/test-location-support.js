const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const androidPatch = read('scripts/patch-android.js');
const iosPatch = read('scripts/patch-ios.js');

function includes(source, fragment, label) {
  assert(source.includes(fragment), `Brak obsługi lokalizacji: ${label || fragment}`);
}

[
  ["android.permission.ACCESS_COARSE_LOCATION", 'uprawnienie przybliżonej lokalizacji Android'],
  ["android.permission.ACCESS_FINE_LOCATION", 'uprawnienie dokładnej lokalizacji Android'],
  ['settings.setGeolocationEnabled(true);', 'włączenie geolokalizacji WebView'],
  ['onGeolocationPermissionsShowPrompt', 'obsługa żądania geolokalizacji z WebView'],
  ['requestPermissions(', 'systemowy dialog uprawnień Android'],
  ['onRequestPermissionsResult', 'wynik systemowego dialogu Android'],
  ['isTrustedGeolocationOrigin', 'ograniczenie geolokalizacji do zaufanych domen'],
  ['LOCATION_PERMISSION_REQUEST_CODE = 2900', 'unikalny kod żądania lokalizacji']
].forEach(([fragment, label]) => includes(androidPatch, fragment, label));

includes(iosPatch, 'NSLocationWhenInUseUsageDescription', 'opis lokalizacji iOS');
includes(iosPatch, 'Zlokalizuj mnie', 'czytelne uzasadnienie uprawnienia iOS');

const patchOnDestroyCount = (androidPatch.match(/protected\s+void\s+onDestroy\s*\(/g) || []).length;
assert.strictEqual(
  patchOnDestroyCount,
  1,
  `Generator Androida musi deklarować dokładnie jedną metodę onDestroy(), znaleziono: ${patchOnDestroyCount}.`
);

const androidManifest = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
const androidMain = path.join(root, 'android', 'app', 'src', 'main', 'java', 'eu', 'gdziezdzieckiem', 'app', 'MainActivity.java');
const iosPlist = path.join(root, 'ios', 'App', 'App', 'Info.plist');

if (fs.existsSync(androidManifest)) {
  const manifest = fs.readFileSync(androidManifest, 'utf8');
  includes(manifest, 'android.permission.ACCESS_COARSE_LOCATION', 'wygenerowany manifest Android: coarse');
  includes(manifest, 'android.permission.ACCESS_FINE_LOCATION', 'wygenerowany manifest Android: fine');
}

if (fs.existsSync(androidMain)) {
  const main = fs.readFileSync(androidMain, 'utf8');
  includes(main, 'settings.setGeolocationEnabled(true);', 'wygenerowany MainActivity: geolokalizacja WebView');
  includes(main, 'onGeolocationPermissionsShowPrompt', 'wygenerowany MainActivity: callback WebView');
  includes(main, 'Manifest.permission.ACCESS_FINE_LOCATION', 'wygenerowany MainActivity: fine runtime permission');
  includes(main, 'Manifest.permission.ACCESS_COARSE_LOCATION', 'wygenerowany MainActivity: coarse runtime permission');
}

if (fs.existsSync(iosPlist)) {
  const plist = fs.readFileSync(iosPlist, 'utf8');
  includes(plist, '<key>NSLocationWhenInUseUsageDescription</key>', 'wygenerowany Info.plist iOS');
  includes(plist, 'Zlokalizuj mnie', 'wygenerowane uzasadnienie iOS');
}

console.log('OK: v2.10.5 zawiera obsługę lokalizacji Android WebView i iOS WKWebView.');
