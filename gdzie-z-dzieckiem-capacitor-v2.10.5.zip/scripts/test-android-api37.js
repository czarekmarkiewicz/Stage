'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), 'utf8');

const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
assert.strictEqual(pkg.version, '2.10.5', 'package.json musi mieć wersję 2.10.5');
assert.strictEqual(lock.version, '2.10.5', 'package-lock.json musi mieć wersję 2.10.5');
assert.strictEqual(lock.packages[''].version, '2.10.5', 'Główny pakiet lockfile musi mieć wersję 2.10.5');
assert(/^\^7\./.test(pkg.dependencies['@capacitor/android']), 'Capacitor Android ma pozostać w stabilnej linii 7.x');
assert(!JSON.stringify(pkg).includes('alpha'), 'Konfiguracja nie może używać wersji alpha');

const variables = read('android/variables.gradle');
assert(/minSdkVersion\s*=\s*23\b/.test(variables), 'minSdk musi pozostać na poziomie 23');
assert(/compileSdkVersion\s*=\s*37\b/.test(variables), 'compileSdk musi mieć wartość 37');
assert(/targetSdkVersion\s*=\s*37\b/.test(variables), 'targetSdk musi mieć wartość 37');

const rootBuild = read('android/build.gradle');
assert(rootBuild.includes("com.android.tools.build:gradle:9.2.1"), 'AGP musi mieć wersję 9.2.1');
assert(rootBuild.includes("com.google.gms:google-services:4.5.0"), 'Google Services Gradle Plugin musi mieć wersję 4.5.0');

const wrapper = read('android/gradle/wrapper/gradle-wrapper.properties');
assert(wrapper.includes('gradle-9.5.1-all.zip'), 'Gradle Wrapper musi mieć wersję 9.5.1');

const gradleFiles = [
  'android/build.gradle',
  'android/app/build.gradle',
  'android/capacitor-cordova-android-plugins/build.gradle',
  'node_modules/@capacitor/android/capacitor/build.gradle',
  'node_modules/@capacitor/app/android/build.gradle',
  'node_modules/@capacitor/network/android/build.gradle',
  'node_modules/@capacitor/splash-screen/android/build.gradle',
  'node_modules/@capacitor/share/android/build.gradle',
];

for (const relativePath of gradleFiles) {
  const text = read(relativePath);
  assert(!text.includes('com.android.tools.build:gradle:8.7.2'), `${relativePath} nadal używa AGP 8.7.2`);
  assert(!text.includes("getDefaultProguardFile('proguard-android.txt')"), `${relativePath} używa niedozwolonego pliku ProGuard`);
  assert(!/^\s*namespace\s+"/m.test(text), `${relativePath} używa starej składni namespace`);
  assert(!/^\s*compileSdk\s+(?!=)/m.test(text), `${relativePath} używa starej składni compileSdk`);
}

for (const relativePath of gradleFiles.slice(2)) {
  const text = read(relativePath);
  assert(text.includes('com.android.tools.build:gradle:9.2.1'), `${relativePath} musi używać AGP 9.2.1`);
}

const appBuild = read('android/app/build.gradle');
assert(appBuild.includes('targetSdkVersion rootProject.ext.targetSdkVersion'), 'Aplikacja musi pobierać targetSdk z variables.gradle');
assert(appBuild.includes("getDefaultProguardFile('proguard-android-optimize.txt')"), 'Aplikacja musi używać pliku ProGuard zgodnego z AGP 9');

console.log('OK: Android używa compileSdk/targetSdk 37, AGP 9.2.1 i Gradle 9.5.1 bez zmiany minSdk i bez wersji alpha.');
