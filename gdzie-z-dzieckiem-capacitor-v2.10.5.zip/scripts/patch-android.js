const fs = require('fs');
const path = require('path');

const projectRoot = path.join(__dirname, '..');
const androidRoot = path.join(projectRoot, 'android');
const manifestPath = path.join(androidRoot, 'app', 'src', 'main', 'AndroidManifest.xml');
const mainActivityDir = path.join(androidRoot, 'app', 'src', 'main', 'java', 'eu', 'gdziezdzieckiem', 'app');
const mainActivityPath = path.join(mainActivityDir, 'MainActivity.java');
const stylesPath = path.join(androidRoot, 'app', 'src', 'main', 'res', 'values', 'styles.xml');
const stylesV31Path = path.join(androidRoot, 'app', 'src', 'main', 'res', 'values-v31', 'styles.xml');
const splashDrawablePath = path.join(androidRoot, 'app', 'src', 'main', 'res', 'drawable', 'gzd_splash_background.xml');

function ensureNoActionBarStyle(filePath) {
  if (!fs.existsSync(filePath)) return;
  let styles = fs.readFileSync(filePath, 'utf8');

  const noActionBarStyle = `
    <style name="GZDNoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
        <item name="android:windowActionBar">false</item>
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowFullscreen">false</item>
        <item name="android:fontFamily">sans</item>
        <item name="android:colorAccent">#f8c401</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:statusBarColor">#f8c401</item>
        <item name="android:navigationBarColor">#fff7d2</item>
    </style>`;

  const isV31 = filePath.includes('values-v31');

  const splashStyle = isV31 ? `
    <style name="GZDSplashTheme" parent="Theme.SplashScreen">
        <item name="windowSplashScreenBackground">#f8c401</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/gzd_app_icon</item>
        <item name="windowSplashScreenIconBackgroundColor">#f8c401</item>
        <item name="postSplashScreenTheme">@style/GZDNoActionBar</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:statusBarColor">#f8c401</item>
        <item name="android:navigationBarColor">#fff7d2</item>
    </style>` : `
    <style name="GZDSplashTheme" parent="GZDNoActionBar">
        <item name="android:windowBackground">@drawable/gzd_splash_background</item>
        <item name="android:statusBarColor">#f8c401</item>
        <item name="android:navigationBarColor">#fff7d2</item>
        <item name="android:windowLightStatusBar">true</item>
    </style>`;

  function upsertStyle(xml, name, block) {
    const re = new RegExp(`<style name="${name}"[\\s\\S]*?<\\/style>`);
    if (re.test(xml)) return xml.replace(re, block.trim());
    return xml.replace(/<\/resources>/, `${block}\n</resources>`);
  }

  styles = upsertStyle(styles, 'GZDNoActionBar', noActionBarStyle);
  styles = upsertStyle(styles, 'GZDSplashTheme', splashStyle);

  fs.writeFileSync(filePath, styles);
}

function ensureSplashDrawable() {
  const drawableDir = path.dirname(splashDrawablePath);
  fs.mkdirSync(drawableDir, { recursive: true });
  const xml = `<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/gzd_splash_yellow" />
    <item
        android:gravity="center"
        android:width="128dp"
        android:height="128dp"
        android:drawable="@drawable/gzd_app_icon" />
</layer-list>
`;
  fs.writeFileSync(splashDrawablePath, xml);
}

function ensureSplashColor(filePath) {
  if (!fs.existsSync(filePath)) return;
  let styles = fs.readFileSync(filePath, 'utf8');
  if (!styles.includes('name="gzd_splash_yellow"')) {
    styles = styles.replace(/<\/resources>/, `    <color name="gzd_splash_yellow">#f8c401</color>\n</resources>`);
    fs.writeFileSync(filePath, styles);
  }
}

if (!fs.existsSync(manifestPath)) {
  console.log('AndroidManifest.xml nie istnieje jeszcze. Uruchom najpierw: npx cap add android');
  process.exit(0);
}

let manifest = fs.readFileSync(manifestPath, 'utf8');

function setApplicationAttribute(xml, attr, value) {
  const escapedAttr = attr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`android:${escapedAttr}="[^"]*"`);
  if (re.test(xml)) return xml.replace(re, `android:${attr}="${value}"`);
  return xml.replace(/<application\b/, `<application android:${attr}="${value}"`);
}

function setMainActivityAttribute(xml, attr, value) {
  const activityRe = /<activity\b(?=[^>]*(?:android:name="(?:\.MainActivity|eu\.gdziezdzieckiem\.app\.MainActivity)"|android:name="MainActivity"))[^>]*>/;
  const match = xml.match(activityRe);
  if (!match) return xml;
  let tag = match[0];
  const attrRe = new RegExp(`android:${attr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}="[^"]*"`);
  if (attrRe.test(tag)) tag = tag.replace(attrRe, `android:${attr}="${value}"`);
  else tag = tag.replace(/>$/, ` android:${attr}="${value}">`);
  return xml.replace(activityRe, tag);
}


function ensureMainActivityIntentFilter(xml) {
  if (xml.includes('gzd-internal-links')) return xml;

  const filter = `
            <!-- gzd-internal-links -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="gdziezdzieckiem.eu" />
                <data android:scheme="http" android:host="gdziezdzieckiem.eu" />
                <data android:scheme="https" android:host="www.gdziezdzieckiem.eu" />
                <data android:scheme="http" android:host="www.gdziezdzieckiem.eu" />
                <data android:scheme="https" android:host="gdziezdzieckiem.pl" />
                <data android:scheme="http" android:host="gdziezdzieckiem.pl" />
                <data android:scheme="https" android:host="www.gdziezdzieckiem.pl" />
                <data android:scheme="http" android:host="www.gdziezdzieckiem.pl" />
            </intent-filter>`;

  const activityBlockRe = /<activity\b(?=[^>]*(?:android:name="(?:\.MainActivity|eu\.gdziezdzieckiem\.app\.MainActivity)"|android:name="MainActivity"))[\s\S]*?<\/activity>/;
  if (activityBlockRe.test(xml)) {
    return xml.replace(activityBlockRe, block => block.replace(/<\/activity>/, `${filter}\n        </activity>`));
  }

  const activitySelfClosingRe = /<activity\b(?=[^>]*(?:android:name="(?:\.MainActivity|eu\.gdziezdzieckiem\.app\.MainActivity)"|android:name="MainActivity"))[^>]*\/>/;
  if (activitySelfClosingRe.test(xml)) {
    return xml.replace(activitySelfClosingRe, tag => tag.replace(/\/>$/, `>${filter}\n        </activity>`));
  }

  return xml;
}


function ensureUsesPermission(xml, permission) {
  if (xml.includes(`android:name="${permission}"`)) return xml;
  return xml.replace(/<application\b/, `<uses-permission android:name="${permission}" />\n\n    <application`);
}

manifest = ensureUsesPermission(manifest, 'android.permission.INTERNET');
manifest = ensureUsesPermission(manifest, 'android.permission.ACCESS_NETWORK_STATE');
manifest = ensureUsesPermission(manifest, 'android.permission.ACCESS_COARSE_LOCATION');
manifest = ensureUsesPermission(manifest, 'android.permission.ACCESS_FINE_LOCATION');
manifest = setApplicationAttribute(manifest, 'allowBackup', 'false');
manifest = setApplicationAttribute(manifest, 'icon', '@drawable/gzd_app_icon');
manifest = setApplicationAttribute(manifest, 'roundIcon', '@drawable/gzd_app_icon');
manifest = setApplicationAttribute(manifest, 'usesCleartextTraffic', 'false');
manifest = setApplicationAttribute(manifest, 'hardwareAccelerated', 'true');
manifest = setMainActivityAttribute(manifest, 'theme', '@style/GZDSplashTheme');
manifest = setMainActivityAttribute(manifest, 'exported', 'true');
manifest = setMainActivityAttribute(manifest, 'launchMode', 'singleTask');
manifest = ensureMainActivityIntentFilter(manifest);

ensureNoActionBarStyle(stylesPath);
ensureNoActionBarStyle(stylesV31Path);
ensureSplashColor(stylesPath);
ensureSplashColor(stylesV31Path);
ensureSplashDrawable();

function copyAppIconToDrawable() {
  const sourceCandidates = [
    path.join(projectRoot, 'assets', 'icon.png'),
    path.join(projectRoot, 'assets', 'app-icon.png'),
    path.join(projectRoot, 'dist', 'app-icon.png')
  ];
  const source = sourceCandidates.find(file => fs.existsSync(file));
  if (!source) return;
  const drawableDir = path.join(androidRoot, 'app', 'src', 'main', 'res', 'drawable-nodpi');
  fs.mkdirSync(drawableDir, { recursive: true });
  fs.copyFileSync(source, path.join(drawableDir, 'gzd_app_icon.png'));
}

copyAppIconToDrawable();
fs.writeFileSync(manifestPath, manifest);

fs.mkdirSync(mainActivityDir, { recursive: true });

const mainActivity = `package eu.gdziezdzieckiem.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final String APP_USER_AGENT_MARKER = "GdzieZDzieckiemMobileApp/1.0";
    private static final String HOME_URL = "https://gdziezdzieckiem.eu/";
    private static final String MAP_URL = "https://gdziezdzieckiem.eu/#brxe-qnovlp";
    private static final String OUTDOOR_URL = "https://gdziezdzieckiem.eu/wszystkie-atrakcje/?_na_powietrzu=na-powietrzu";
    private static final String INDOOR_URL = "https://gdziezdzieckiem.eu/wszystkie-atrakcje/?_pod_dachem=pod-dachem";
    private static final String BLOG_URL = "https://gdziezdzieckiem.eu/blog/";
    private static final String ADD_URL = "https://gdziezdzieckiem.eu/dodaj-atrakcje/";

    private static final String FAVORITES_KEY = "gzd_native_favorites_v2";
    private static final String RECENT_KEY = "gzd_native_recent_v2";
    private static final int BRAND_COLOR = Color.rgb(248, 196, 1);
    private static final int TEXT_COLOR = Color.rgb(15, 20, 53);
    private static final int MUTED_COLOR = Color.rgb(105, 110, 123);
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 2900;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout root;
    private WebView webView;
    private View homeView;
    private View localView;
    private View loadingView;
    private View offlineView;
    private LinearLayout bottomNav;
    private LinearLayout floatingActions;
    private View webBackButton;
    private View startupSplashView;
    private long startupSplashStartedAt = 0;
    private boolean startupSplashReady = false;
    private boolean startupSplashHidden = false;

    private boolean failed = false;
    private boolean pageFinished = false;
    private boolean isShowingWeb = false;
    private String mode = "home";
    private String activeNav = "start";
    private String pendingUrl = HOME_URL;
    private Place currentPlace = null;
    private int loadToken = 0;
    private int navigationCommandId = 0;
    private final ArrayList<String> webHistory = new ArrayList<>();
    private String localReturnScreen = "";
    private long lastBackPressAt = 0;
    private long lastBackActionAt = 0;
    private String currentWebUrl = "";
    private boolean restoringWebHistory = false;
    private boolean preserveMapViewportForCurrentLoad = false;
    private boolean appInitiatedLoad = false;
    private boolean backNavigationInProgress = false;
    private String navigationStateScriptSource = null;
    private GeolocationPermissions.Callback pendingGeolocationCallback = null;
    private String pendingGeolocationOrigin = null;
    private boolean locationPermissionRequestInFlight = false;

    private SharedPreferences prefs;

    private static class Place {
        String id;
        String title;
        String url;
        String image;
        String city;
        String updatedAt;

        JSONObject toJson() {
            JSONObject obj = new JSONObject();
            try {
                obj.put("id", id == null ? "" : id);
                obj.put("title", title == null ? "" : title);
                obj.put("url", url == null ? "" : url);
                obj.put("image", image == null ? "" : image);
                obj.put("city", city == null ? "" : city);
                obj.put("updatedAt", updatedAt == null ? "" : updatedAt);
            } catch (Exception ignored) {}
            return obj;
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.GZDNoActionBar);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("gzd_app_native_store", MODE_PRIVATE);

        Window window = getWindow();
        window.setTitle("");
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        window.setStatusBarColor(BRAND_COLOR);
        window.setNavigationBarColor(Color.rgb(255, 247, 210));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        applySystemBarInsets(root);
        setContentView(root);

        webView = new WebView(this);
        webView.setVisibility(View.GONE);
        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        root.addView(webView, fullFrame());

        loadingView = createLoadingView();
        offlineView = createOfflineView();
        root.addView(loadingView, fullFrame());
        root.addView(offlineView, fullFrame());
        loadingView.setVisibility(View.GONE);
        offlineView.setVisibility(View.GONE);

        configureWebView();
        showHome();

        // Nie wstępnie ładujemy strony do ukrytego WebView. Taki wpis pozostawał
        // w natywnej historii Androida i potrafił konkurować z historią aplikacji.
        showStartupSplashOverlay();
        markStartupSplashReady();

        registerModernBackHandler();
        handleIncomingIntent(getIntent(), false);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent, true);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            locationPermissionRequestInFlight = false;
            resolvePendingGeolocationPermission(hasLocationPermission());
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    private void handleIncomingIntent(Intent intent, boolean addToHistory) {
        try {
            if (intent == null) return;
            Uri data = intent.getData();
            if (data != null && isInternalGzdUrl(data.toString())) {
                navigateToUrl(data.toString(), addToHistory);
            }
        } catch (Exception ignored) {}
    }

    private void showStartupSplashOverlay() {
        try {
            startupSplashStartedAt = System.currentTimeMillis();
            startupSplashReady = false;
            startupSplashHidden = false;

            FrameLayout splash = new FrameLayout(this);
            splash.setBackgroundColor(BRAND_COLOR);
            splash.setClickable(true);
            splash.setFocusable(true);

            ImageView logo = new ImageView(this);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            setImageFromAsset(logo, "public/app-icon.png");

            FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(128), dp(128));
            logoLp.gravity = Gravity.CENTER;
            splash.addView(logo, logoLp);

            startupSplashView = splash;
            root.addView(startupSplashView, fullFrame());
            startupSplashView.bringToFront();

            handler.postDelayed(() -> {
                startupSplashReady = true;
                hideStartupSplashWhenAllowed();
            }, 1000);

            handler.postDelayed(() -> forceHideStartupSplash(), 5000);
        } catch (Exception ignored) {}
    }

    private void markStartupSplashReady() {
        startupSplashReady = true;
        hideStartupSplashWhenAllowed();
    }

    private void hideStartupSplashWhenAllowed() {
        try {
            if (startupSplashHidden || startupSplashView == null || !startupSplashReady) return;

            long elapsed = System.currentTimeMillis() - startupSplashStartedAt;
            long remaining = Math.max(0, 1000 - elapsed);

            handler.postDelayed(() -> forceHideStartupSplash(), remaining);
        } catch (Exception ignored) {}
    }

    private void forceHideStartupSplash() {
        try {
            if (startupSplashHidden) return;
            startupSplashHidden = true;
            if (startupSplashView != null) {
                final View view = startupSplashView;
                startupSplashView = null;
                view.animate()
                    .alpha(0f)
                    .setDuration(180)
                    .withEndAction(() -> {
                        try { root.removeView(view); } catch (Exception ignored) {}
                    })
                    .start();
            }
        } catch (Exception ignored) {}
    }

    private void appendAppUserAgent(WebView targetWebView) {
        try {
            if (targetWebView == null) return;
            WebSettings targetSettings = targetWebView.getSettings();
            String currentUserAgent = targetSettings.getUserAgentString();
            if (currentUserAgent == null) currentUserAgent = "";
            if (!currentUserAgent.contains(APP_USER_AGENT_MARKER)) {
                targetSettings.setUserAgentString((currentUserAgent + " " + APP_USER_AGENT_MARKER).trim());
            }
        } catch (Exception ignored) {}
    }


    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isTrustedGeolocationOrigin(String origin) {
        try {
            Uri uri = Uri.parse(origin == null ? "" : origin);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(scheme) || host == null) return false;
            String normalizedHost = host.toLowerCase();
            return normalizedHost.equals("gdziezdzieckiem.eu")
                    || normalizedHost.endsWith(".gdziezdzieckiem.eu")
                    || normalizedHost.equals("gdziezdzieckiem.pl")
                    || normalizedHost.endsWith(".gdziezdzieckiem.pl");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void resolvePendingGeolocationPermission(boolean allow) {
        GeolocationPermissions.Callback callback = pendingGeolocationCallback;
        String origin = pendingGeolocationOrigin;
        pendingGeolocationCallback = null;
        pendingGeolocationOrigin = null;
        if (callback == null || origin == null) return;
        try {
            callback.invoke(origin, allow, false);
        } catch (Exception ignored) {}
    }

    private void requestGeolocationPermission(String origin, GeolocationPermissions.Callback callback) {
        if (callback == null) return;
        if (!isTrustedGeolocationOrigin(origin)) {
            callback.invoke(origin, false, false);
            return;
        }
        if (hasLocationPermission()) {
            callback.invoke(origin, true, false);
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            callback.invoke(origin, true, false);
            return;
        }

        if (pendingGeolocationCallback != null && pendingGeolocationCallback != callback) {
            resolvePendingGeolocationPermission(false);
        }
        pendingGeolocationOrigin = origin;
        pendingGeolocationCallback = callback;

        if (locationPermissionRequestInFlight) return;
        locationPermissionRequestInFlight = true;
        requestPermissions(
                new String[] {
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                },
                LOCATION_PERMISSION_REQUEST_CODE
        );
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        appendAppUserAgent(webView);
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new GZDNativeBridge(), "GZDNative");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                runOnUiThread(() -> requestGeolocationPermission(origin, callback));
            }

            @Override
            public void onGeolocationPermissionsHidePrompt() {
                if (!locationPermissionRequestInFlight) {
                    resolvePendingGeolocationPermission(false);
                }
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                try {
                    WebView popupWebView = new WebView(MainActivity.this);
                    appendAppUserAgent(popupWebView);
                    popupWebView.setWebViewClient(new WebViewClient() {
                        @Override
                        public boolean shouldOverrideUrlLoading(WebView popupView, WebResourceRequest request) {
                            Uri uri = request == null ? null : request.getUrl();
                            return handlePopupUrl(uri);
                        }

                        @Override
                        public boolean shouldOverrideUrlLoading(WebView popupView, String url) {
                            return handlePopupUrl(url == null ? null : Uri.parse(url));
                        }
                    });

                    WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                    transport.setWebView(popupWebView);
                    resultMsg.sendToTarget();
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;

                if (!request.isForMainFrame()) return false;

                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    String url = uri.toString();
                    if (isInternalGzdUrl(url)) {
                        // Przekierowania należące do aktualnego loadUrl muszą pozostać
                        // w tej samej komendzie. Każdą inną nawigację obsługuje jawny
                        // stos aplikacji, nigdy natywne WebView.goBack().
                        if (appInitiatedLoad && ("loading".equals(mode) || restoringWebHistory)) {
                            // Zezwalamy wyłącznie na prawdziwe przekierowanie serwera
                            // albo kontynuację tego samego dokumentu. Opóźniona nawigacja
                            // starej atrakcji ma inny path i zostaje anulowana.
                            boolean serverRedirect = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && request.isRedirect();
                            if (serverRedirect || isActiveLoadContinuation(url)) return false;
                            return true;
                        }
                        // Ukryty dokument nie może po powrocie na ekran startowy sam
                        // uruchomić opóźnionej nawigacji.
                        if (!("web".equals(mode) || "loading".equals(mode))) return true;
                        String method = request.getMethod() == null ? "GET" : request.getMethod();
                        if ("GET".equalsIgnoreCase(method)) {
                            navigateToUrl(url, true);
                            return true;
                        }
                        return false;
                    }
                    openExternalIntent(uri);
                    return true;
                }
                openExternalIntent(uri);
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (isInternalGzdUrl(url)) {
                        if (appInitiatedLoad && ("loading".equals(mode) || restoringWebHistory)) {
                            return !isActiveLoadContinuation(url);
                        }
                        if (!("web".equals(mode) || "loading".equals(mode))) return true;
                        navigateToUrl(url, true);
                        return true;
                    }
                    openExternalIntent(uri);
                    return true;
                }
                openExternalIntent(uri);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if ("about:blank".equals(url)) return;
                failed = false;
                pageFinished = false;
                isShowingWeb = false;
                currentPlace = null;
                hideFloatingActions();

                if (restoringWebHistory && isInternalGzdUrl(url)) {
                    // Podczas odtwarzania nie pokazujemy niedokończonego dokumentu.
                    // Ekran ładowania pozostaje do onPageCommitVisible/onPageFinished,
                    // gdzie moduł kotwicy zacznie doładowywanie listy.
                    mode = "loading";
                    currentWebUrl = normalizeUrl(url);
                    webView.setVisibility(View.INVISIBLE);
                    webView.setAlpha(0f);
                    showBottomNav(navForUrl(pendingUrl));
                    showNativeLoadingOnly();
                    showWebBackButton();
                    return;
                }

                if ("web".equals(mode) && isInternalGzdUrl(url)) {
                    mode = "loading";
                    pendingUrl = normalizeUrl(url);
                    currentWebUrl = pendingUrl;
                    pushHistory(pendingUrl);
                    webView.setVisibility(View.INVISIBLE);
                    showBottomNav(navForUrl(pendingUrl));
                    showNativeLoadingOnly();
                } else if ("loading".equals(mode)) {
                    showNativeLoadingOnly();
                }
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                super.onPageCommitVisible(view, url);
                if ("about:blank".equals(url) || !isCurrentWebViewCallback(view, url)) return;
                final boolean shouldRestoreScroll = restoringWebHistory;
                injectNavigationStateScript(() -> {
                    injectPageHelpers();
                    if (shouldRestoreScroll) restoreMarkedWebScroll();
                });
                handler.postDelayed(() -> injectPageHelpers(), 800);
                handler.postDelayed(() -> injectPageHelpers(), 2200);
                scheduleWebReveal();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if ("about:blank".equals(url)) {
                    if ("home".equals(mode)) {
                        pageFinished = true;
                        try { view.clearHistory(); } catch (Exception ignored) {}
                    }
                    return;
                }
                if (!isCurrentWebViewCallback(view, url)) return;
                pageFinished = true;
                if (isInternalGzdUrl(url)) {
                    currentWebUrl = isMapUrl(pendingUrl) ? pendingUrl : normalizeUrl(url);
                }
                final boolean shouldRestoreScroll = restoringWebHistory;
                appInitiatedLoad = false;
                backNavigationInProgress = false;
                if (shouldRestoreScroll) {
                    mode = "web";
                    restoringWebHistory = false;
                    webView.setVisibility(View.VISIBLE);
                    webView.setAlpha(1f);
                    loadingView.setVisibility(View.GONE);
                    showBottomNav(navForUrl(currentWebUrl));
                    showWebBackButton();
                }
                injectNavigationStateScript(() -> {
                    injectPageHelpers();
                    if (shouldRestoreScroll) restoreMarkedWebScroll();
                });
                // Android ma tylko jeden autorytatywny stos: webHistory. Usunięcie
                // natywnej historii eliminuje powtarzanie tej samej atrakcji i białe
                // ekrany po serii goBack().
                try { view.clearHistory(); } catch (Exception ignored) {}
                scheduleWebReveal();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    failed = true;
                    appInitiatedLoad = false;
                    backNavigationInProgress = false;
                    restoringWebHistory = false;
                    showOffline();
                }
            }
        });
    }

    private boolean handlePopupUrl(Uri uri) {
        try {
            if (uri == null) return true;
            String url = uri.toString();
            if (!("web".equals(mode) || "loading".equals(mode))) return true;
            if (backNavigationInProgress || (appInitiatedLoad && "loading".equals(mode))) return true;
            if (isInternalGzdUrl(url)) {
                navigateToUrl(url, true);
            } else {
                openExternalIntent(uri);
            }
        } catch (Exception ignored) {}
        return true;
    }

    private class GZDNativeBridge {
        @JavascriptInterface
        public void openUrl(String url) {
            String target = url;
            boolean reset = false;
            if (target != null && target.startsWith("gzd-reset:")) {
                reset = true;
                target = target.substring("gzd-reset:".length());
            }
            final String finalTarget = target;
            final boolean finalReset = reset;
            runOnUiThread(() -> {
                // Ignoruj opóźnione wywołania ze starego, już ukrytego dokumentu.
                if (!("web".equals(mode) || "loading".equals(mode))) return;
                if (backNavigationInProgress || (appInitiatedLoad && "loading".equals(mode))) return;
                if (finalReset) webHistory.clear();
                navigateToUrl(finalTarget, true);
            });
        }

        @JavascriptInterface
        public void share(String title, String url) {
            runOnUiThread(() -> shareNative(title, url));
        }

        @JavascriptInterface
        public void resetNavigation() {
            runOnUiThread(() -> webHistory.clear());
        }

        @JavascriptInterface
        public void goBack() {
            runOnUiThread(() -> requestBackNavigation());
        }

        @JavascriptInterface
        public void placeData(String json) {
            runOnUiThread(() -> {
                Place place = parsePlace(json);
                if (place == null) {
                    currentPlace = null;
                    hideFloatingActions();
                    return;
                }
                currentPlace = place;
                if ("web".equals(mode) || "loading".equals(mode)) {
                    upsertPlace(RECENT_KEY, place, 10);
                }
                if ("web".equals(mode)) {
                    renderFloatingActions();
                }
            });
        }

        @JavascriptInterface
        public String getShellVersion() {
            return "android-native-v2.10.5";
        }
    }

    private void openWebUrl(String rawUrl, boolean fromUserAction) {
        navigateToUrl(rawUrl, true);
    }

    private void openWebUrlReset(String rawUrl) {
        webHistory.clear();
        localReturnScreen = "";
        navigateToUrl(rawUrl, true);
    }

    private String webLoadUrlFor(String url) {
        try {
            if (isMapUrl(url)) {
                Uri uri = Uri.parse(url);
                Uri.Builder b = uri.buildUpon();
                b.fragment(null);
                String withoutHash = b.build().toString();
                if (!withoutHash.contains("gzd_app_map=1")) {
                    if (withoutHash.contains("?")) withoutHash = withoutHash + "&gzd_app_map=1";
                    else withoutHash = withoutHash + "?gzd_app_map=1";
                }
                return withoutHash;
            }
        } catch (Exception ignored) {}
        return url;
    }

    private String documentPathKey(String rawUrl) {
        try {
            Uri uri = Uri.parse(normalizeUrl(rawUrl));
            String path = uri.getPath() == null || uri.getPath().length() == 0 ? "/" : uri.getPath();
            while (path.length() > 1 && path.endsWith("/")) path = path.substring(0, path.length() - 1);
            return path.toLowerCase();
        } catch (Exception ignored) {
            return normalizeUrl(rawUrl);
        }
    }

    private boolean isActiveLoadContinuation(String rawUrl) {
        try {
            String expected = webLoadUrlFor(pendingUrl);
            return documentPathKey(expected).equals(documentPathKey(rawUrl));
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isCurrentWebViewCallback(WebView view, String callbackUrl) {
        try {
            if (view == null || callbackUrl == null) return true;
            String actualUrl = view.getUrl();
            if (actualUrl == null || actualUrl.length() == 0) return true;
            if ("about:blank".equals(actualUrl)) return "about:blank".equals(callbackUrl);
            Uri actual = Uri.parse(normalizeUrl(actualUrl));
            Uri callback = Uri.parse(normalizeUrl(callbackUrl));
            String actualQuery = actual.getEncodedQuery() == null ? "" : actual.getEncodedQuery();
            String callbackQuery = callback.getEncodedQuery() == null ? "" : callback.getEncodedQuery();
            return documentPathKey(actualUrl).equals(documentPathKey(callbackUrl))
                    && actualQuery.equals(callbackQuery);
        } catch (Exception ignored) {
            return true;
        }
    }

    private void navigateToUrl(String rawUrl, boolean addToHistory) {
        if (rawUrl == null) return;
        final int commandId = ++navigationCommandId;
        backNavigationInProgress = false;
        final String targetUrl = rawUrl;
        final boolean shouldCapture = addToHistory && ("web".equals(mode) || "loading".equals(mode));
        if (shouldCapture) {
            injectNavigationStateScript(() -> {
                if (commandId != navigationCommandId) return;
                try {
                    webView.evaluateJavascript(
                        "try{window.__GZD_CAPTURE_SCROLL_STATE__&&window.__GZD_CAPTURE_SCROLL_STATE__()}catch(e){}",
                        value -> {
                            if (commandId == navigationCommandId) {
                                navigateToUrlNow(targetUrl, addToHistory, false, commandId);
                            }
                        }
                    );
                } catch (Exception ignored) {
                    if (commandId == navigationCommandId) {
                        navigateToUrlNow(targetUrl, addToHistory, false, commandId);
                    }
                }
            });
            return;
        }
        navigateToUrlNow(targetUrl, addToHistory, false, commandId);
    }

    private void navigateToUrlNow(String rawUrl, boolean addToHistory, boolean restoreScroll, int commandId) {
        if (rawUrl == null || commandId != navigationCommandId) return;
        String url = normalizeUrl(rawUrl);
        if (!isInternalGzdUrl(url)) return;

        if (!isOnline()) {
            backNavigationInProgress = false;
            showOffline();
            return;
        }

        restoringWebHistory = restoreScroll;
        preserveMapViewportForCurrentLoad = restoreScroll;
        appInitiatedLoad = true;
        backNavigationInProgress = restoreScroll;
        mode = "loading";
        activeNav = navForUrl(url);
        pendingUrl = url;
        currentWebUrl = url;
        currentPlace = null;
        pageFinished = false;
        failed = false;
        isShowingWeb = false;
        loadToken++;

        if (addToHistory) {
            pushHistory(url);
        }

        hideHomeAndLocal();
        hideFloatingActions();
        showBottomNav(activeNav);
        showNativeLoadingOnly();
        showWebBackButton();

        try {
            webView.stopLoading();
            // Natywna historia WebView nie bierze udziału w nawigacji aplikacji.
            webView.clearHistory();
        } catch (Exception ignored) {}

        webView.setVisibility(View.INVISIBLE);
        webView.setAlpha(0f);
        String webLoadUrl = webLoadUrlFor(url);
        webView.loadUrl(webLoadUrl);

        final int token = loadToken;
        final boolean preserveMapViewport = restoreScroll;
        handler.postDelayed(() -> {
            if (token == loadToken && commandId == navigationCommandId && "loading".equals(mode) && !failed) {
                injectPageHelpers();
                forceWebViewRedraw();
            }
        }, 1200);

        handler.postDelayed(() -> {
            if (token == loadToken && commandId == navigationCommandId && "loading".equals(mode) && !failed) {
                if (!preserveMapViewport && (isMapUrl(pendingUrl) || isMapUrl(currentWebUrl))) scrollMapInBackground();
                revealWebPage(preserveMapViewport);
            }
        }, isMapUrl(url) ? 7600 : 4500);

        // Nie blokuj przycisku Wstecz bez końca, gdy Android nie dostarczy
        // onPageFinished (np. po przerwaniu połączenia w trakcie ładowania).
        if (restoreScroll) {
            handler.postDelayed(() -> {
                if (token == loadToken && commandId == navigationCommandId) {
                    backNavigationInProgress = false;
                }
            }, 12000);
        }
    }

    private String historyKey(String rawUrl) {
        try {
            Uri uri = Uri.parse(normalizeUrl(rawUrl));
            String path = uri.getPath() == null || uri.getPath().length() == 0 ? "/" : uri.getPath();
            while (path.length() > 1 && path.endsWith("/")) path = path.substring(0, path.length() - 1);
            String query = uri.getEncodedQuery() == null ? "" : uri.getEncodedQuery();
            String fragment = isMapUrl(rawUrl) ? "#map" : "";
            return path + "?" + query + fragment;
        } catch (Exception ignored) {
            return normalizeUrl(rawUrl);
        }
    }

    private void pushHistory(String url) {
        if (url == null || url.length() == 0) return;
        String normalized = normalizeUrl(url);
        if (webHistory.isEmpty()) {
            webHistory.add(normalized);
            return;
        }
        String last = webHistory.get(webHistory.size() - 1);
        if (!historyKey(last).equals(historyKey(normalized))) {
            webHistory.add(normalized);
        } else {
            // Zachowaj najnowszy wariant kanoniczny URL bez dokładania duplikatu.
            webHistory.set(webHistory.size() - 1, normalized);
        }
        while (webHistory.size() > 40) {
            webHistory.remove(0);
        }
    }

    private void loadPreviousWebPage() {
        if (backNavigationInProgress) return;
        if (webHistory.size() <= 1) {
            if ("favorites".equals(localReturnScreen) || "recent".equals(localReturnScreen)) {
                webHistory.clear();
                showListScreen(localReturnScreen);
            } else {
                showHome();
            }
            return;
        }

        final int commandId = ++navigationCommandId;
        backNavigationInProgress = true;
        appInitiatedLoad = false;
        webHistory.remove(webHistory.size() - 1);
        final String previous = webHistory.get(webHistory.size() - 1);

        // Wersja 2.10.5 nie używa WebView.goBack(). Poprzedni URL jest ładowany
        // deterministycznie ze stosu aplikacji. Marker odtwarzania używa dokładnie
        // takiej reprezentacji URL, jaką załaduje WebView (hash mapy lub gzd_app_map).
        injectNavigationStateScript(() -> {
            if (commandId != navigationCommandId) return;
            markWebScrollRestore(webLoadUrlFor(previous), () -> {
                if (commandId == navigationCommandId) {
                    navigateToUrlNow(previous, false, true, commandId);
                }
            });
        });
    }

    private void captureCurrentWebScroll() {
        try {
            webView.evaluateJavascript("try{window.__GZD_CAPTURE_SCROLL_STATE__&&window.__GZD_CAPTURE_SCROLL_STATE__()}catch(e){}", null);
        } catch (Exception ignored) {}
    }

    private void markWebScrollRestore(String url, Runnable completion) {
        try {
            String quoted = JSONObject.quote(normalizeUrl(url));
            String source = "try{window.__GZD_MARK_SCROLL_RESTORE__&&window.__GZD_MARK_SCROLL_RESTORE__(" + quoted + ")}catch(e){}";
            webView.evaluateJavascript(source, value -> {
                if (completion != null) completion.run();
            });
        } catch (Exception ignored) {
            if (completion != null) completion.run();
        }
    }

    private void restoreMarkedWebScroll() {
        try {
            webView.evaluateJavascript("try{window.__GZD_RESTORE_SCROLL_STATE__&&window.__GZD_RESTORE_SCROLL_STATE__()}catch(e){}", null);
        } catch (Exception ignored) {}
    }

    private String normalizeUrl(String rawUrl) {
        if (rawUrl == null) return "";
        String url = rawUrl.trim();

        // Na stronie nadal występują linki ze starej domeny .pl.
        // W aplikacji traktujemy je jako wewnętrzne i zamieniamy na aktualną domenę .eu.
        url = url.replace("https://www.gdziezdzieckiem.pl", "https://gdziezdzieckiem.eu");
        url = url.replace("http://www.gdziezdzieckiem.pl", "https://gdziezdzieckiem.eu");
        url = url.replace("https://gdziezdzieckiem.pl", "https://gdziezdzieckiem.eu");
        url = url.replace("http://gdziezdzieckiem.pl", "https://gdziezdzieckiem.eu");
        url = url.replace("https://www.gdziezdzieckiem.eu", "https://gdziezdzieckiem.eu");
        url = url.replace("http://www.gdziezdzieckiem.eu", "https://gdziezdzieckiem.eu");

        if (url.equals("https://gdziezdzieckiem.eu")) return HOME_URL;
        if (url.startsWith("http://gdziezdzieckiem.eu")) {
            url = url.replace("http://gdziezdzieckiem.eu", "https://gdziezdzieckiem.eu");
        }
        return url;
    }

    private boolean isInternalGzdUrl(String rawUrl) {
        try {
            if (rawUrl == null) return false;

            Uri originalUri = Uri.parse(rawUrl.trim());
            String originalScheme = originalUri.getScheme();
            String originalHost = originalUri.getHost() == null ? "" : originalUri.getHost().toLowerCase();

            boolean oldOrCurrentDomain = ("https".equalsIgnoreCase(originalScheme) || "http".equalsIgnoreCase(originalScheme)) &&
                    (originalHost.equals("gdziezdzieckiem.eu") ||
                     originalHost.equals("www.gdziezdzieckiem.eu") ||
                     originalHost.endsWith(".gdziezdzieckiem.eu") ||
                     originalHost.equals("gdziezdzieckiem.pl") ||
                     originalHost.equals("www.gdziezdzieckiem.pl") ||
                     originalHost.endsWith(".gdziezdzieckiem.pl"));

            if (oldOrCurrentDomain) return true;

            String url = normalizeUrl(rawUrl);
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            return ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) &&
                    (host.equals("gdziezdzieckiem.eu") || host.endsWith(".gdziezdzieckiem.eu"));
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean shouldShowExtraBackButton() {
        try {
            int navMode = android.provider.Settings.Secure.getInt(getContentResolver(), "navigation_mode", 0);
            // Android: 0 = 3-button, 1 = 2-button, 2 = gesture navigation.
            // Pływający Wstecz pokazujemy tylko przy gestach, czyli gdy nie ma widocznego systemowego Wstecz.
            return navMode == 2;
        } catch (Exception ignored) {
            return false;
        }
    }

    private View centeredBackButton(View.OnClickListener listener, int sizeDp, int bgColor) {
        FrameLayout circle = new FrameLayout(this);
        circle.setBackground(round(bgColor, 999));
        circle.setElevation(dp(10));
        circle.setClickable(true);
        circle.setOnClickListener(listener);

        TextView arrow = tv("‹", 40, TEXT_COLOR, Typeface.BOLD);
        arrow.setGravity(Gravity.CENTER);
        arrow.setIncludeFontPadding(false);
        arrow.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        arrow.setTranslationY(dp(-1));
        arrow.setClickable(false);

        FrameLayout.LayoutParams arrowLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        circle.addView(arrow, arrowLp);
        return circle;
    }

    private void showLocalBackButton() {
        if (!"favorites".equals(mode) && !"recent".equals(mode)) return;
        if (!shouldShowExtraBackButton()) { hideWebBackButton(); return; }
        hideWebBackButton();

        webBackButton = centeredBackButton(v -> showHome(), 58, Color.WHITE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(58), dp(58));
        lp.gravity = Gravity.LEFT | Gravity.BOTTOM;
        lp.leftMargin = dp(18);
        lp.bottomMargin = dp(98);
        root.addView(webBackButton, lp);
        webBackButton.bringToFront();
    }

    private boolean isMapUrl(String url) {
        try {
            return url != null && normalizeUrl(url).contains("#brxe-qnovlp");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void scrollMapInBackground() {
        try {
            webView.evaluateJavascript("(function(){try{window.__GZD_ANDROID_MAP_SETTLING__=true;var title=null;var hs=document.querySelectorAll('h1,h2,h3,h4,.brxe-heading,[class*=heading],[class*=title]');for(var i=0;i<hs.length;i++){var tx=(hs[i].innerText||hs[i].textContent||'').replace(/\\\\s+/g,' ').trim().toLowerCase();if(tx.indexOf('wyszukaj na mapie')!==-1&&tx.length<80){title=hs[i];break;}}var t=title||document.getElementById('brxe-qnovlp')||document.querySelector('#brxe-qnovlp')||document.querySelector('[id*=qnovlp]')||document.querySelector('.leaflet-container')||document.querySelector('[class*=leaflet]');if(t){var off=title?72:8;var y=Math.max(0,t.getBoundingClientRect().top+window.pageYOffset-off);window.scrollTo(0,y);}if(window.__GZD_FIX_MAPS__)window.__GZD_FIX_MAPS__();setTimeout(function(){try{window.__GZD_ANDROID_MAP_SETTLING__=false;}catch(e){}},1400);}catch(e){}})();", null);
        } catch (Exception ignored) {}
    }

    private void showWebBackButton() {
        if (!"web".equals(mode) && !"loading".equals(mode)) return;
        if (!shouldShowExtraBackButton()) { hideWebBackButton(); return; }
        hideWebBackButton();

        webBackButton = centeredBackButton(v -> requestBackNavigation(), 58, Color.WHITE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(58), dp(58));
        lp.gravity = Gravity.LEFT | Gravity.BOTTOM;
        lp.leftMargin = dp(18);
        lp.bottomMargin = dp(98);
        root.addView(webBackButton, lp);
        webBackButton.bringToFront();
    }

    private void hideWebBackButton() {
        if (webBackButton != null) {
            root.removeView(webBackButton);
            webBackButton = null;
        }
    }

    private void scheduleWebReveal() {
        if (!"loading".equals(mode) || failed) return;
        final int token = loadToken;
        final boolean map = isMapUrl(pendingUrl) || isMapUrl(currentWebUrl);
        final boolean preserveMapViewport = preserveMapViewportForCurrentLoad || restoringWebHistory;

        handler.postDelayed(() -> {
            if (token != loadToken || failed || !"loading".equals(mode)) return;
            injectPageHelpers();
            forceWebViewRedraw();

            if (map && !preserveMapViewport) {
                webView.setVisibility(View.VISIBLE);
                webView.setAlpha(0f);
                loadingView.setVisibility(View.VISIBLE);
                loadingView.bringToFront();

                scrollMapInBackground();
                handler.postDelayed(() -> { if (token == loadToken && !failed && "loading".equals(mode)) scrollMapInBackground(); }, 500);
                handler.postDelayed(() -> { if (token == loadToken && !failed && "loading".equals(mode)) scrollMapInBackground(); }, 1050);
                handler.postDelayed(() -> { if (token == loadToken && !failed && "loading".equals(mode)) scrollMapInBackground(); }, 1700);
                handler.postDelayed(() -> { if (token == loadToken && !failed && "loading".equals(mode)) scrollMapInBackground(); }, 2450);

                handler.postDelayed(() -> {
                    if (token != loadToken || failed || !"loading".equals(mode)) return;
                    injectPageHelpers();
                    scrollMapInBackground();
                    forceWebViewRedraw();
                    handler.postDelayed(() -> {
                        if (token != loadToken || failed || !"loading".equals(mode)) return;
                        scrollMapInBackground();
                        revealWebPage(false);
                    }, 650);
                }, 3300);
                return;
            }

            revealWebPage(preserveMapViewport);
        }, 900);
    }

    private void revealWebPage(boolean preserveMapViewport) {
        if (failed) return;

        final boolean map = isMapUrl(pendingUrl) || isMapUrl(currentWebUrl);
        if (map && !preserveMapViewport) {
            mode = "web";
            isShowingWeb = true;
            hideHomeAndLocal();
            offlineView.setVisibility(View.GONE);
            hideFloatingActions();

            webView.setVisibility(View.VISIBLE);
            webView.setAlpha(0f);
            webView.bringToFront();
            loadingView.setVisibility(View.VISIBLE);
            loadingView.bringToFront();

            scrollMapInBackground();
            handler.postDelayed(this::scrollMapInBackground, 160);
            handler.postDelayed(this::scrollMapInBackground, 380);
            handler.postDelayed(this::scrollMapInBackground, 760);

            handler.postDelayed(() -> {
                if (!"web".equals(mode) || failed) return;
                scrollMapInBackground();
                loadingView.setVisibility(View.GONE);
                webView.setAlpha(1f);
                webView.bringToFront();
                showBottomNav(activeNav);
                showWebBackButton();
                if (currentPlace != null) renderFloatingActions();
                else hideFloatingActions();

                forceWebViewRedraw();
                injectPageHelpers();
            }, 1300);
            return;
        }

        mode = "web";
        isShowingWeb = true;
        hideHomeAndLocal();
        loadingView.setVisibility(View.GONE);
        offlineView.setVisibility(View.GONE);

        webView.setVisibility(View.VISIBLE);
        webView.setAlpha(1f);
        webView.bringToFront();
        showBottomNav(activeNav);
        showWebBackButton();
        if (currentPlace != null) renderFloatingActions();
        else hideFloatingActions();

        forceWebViewRedraw();
        injectPageHelpers();
        preserveMapViewportForCurrentLoad = false;

        handler.postDelayed(this::forceWebViewRedraw, 250);
        handler.postDelayed(this::injectPageHelpers, 650);
        handler.postDelayed(this::injectPageHelpers, 1500);
        handler.postDelayed(this::injectPageHelpers, 3000);
        handler.postDelayed(() -> {
            if ("web".equals(mode) && webView.getVisibility() != View.VISIBLE && !failed) {
                webView.setVisibility(View.VISIBLE);
            }
        }, 1800);
    }

    private void showNativeLoadingOnly() {
        loadingView.setVisibility(View.VISIBLE);
        loadingView.bringToFront();
        if (bottomNav != null) bottomNav.bringToFront();
        if (webBackButton != null) webBackButton.bringToFront();
    }

    private void hideHomeAndLocal() {
        if (homeView != null) homeView.setVisibility(View.GONE);
        if (localView != null) localView.setVisibility(View.GONE);
    }

    private void showHome() {
        // Unieważnij wszystkie opóźnione callbacki evaluateJavascript/loadUrl.
        navigationCommandId++;
        webHistory.clear();
        localReturnScreen = "";
        lastBackPressAt = 0;
        restoringWebHistory = false;
        appInitiatedLoad = false;
        backNavigationInProgress = false;
        mode = "home";
        activeNav = "start";
        pendingUrl = HOME_URL;
        currentPlace = null;
        failed = false;
        pageFinished = true;
        isShowingWeb = false;

        try {
            webView.stopLoading();
            webView.clearHistory();
            // Odłącz skrypty starej atrakcji. Dzięki temu opóźniony window.open,
            // redirect lub callback nie może ponownie przejąć ekranu startowego.
            webView.loadUrl("about:blank");
            webView.clearHistory();
        } catch (Exception ignored) {}
        webView.setVisibility(View.GONE);
        loadingView.setVisibility(View.GONE);
        offlineView.setVisibility(View.GONE);
        hideFloatingActions();
        hideWebBackButton();
        hideBottomNav();

        if (homeView != null) root.removeView(homeView);
        homeView = createHomeView();
        root.addView(homeView, fullFrame());
        homeView.bringToFront();
    }

    private View createHomeView() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setBackgroundColor(Color.rgb(255, 253, 244));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(30));
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setPadding(0, 0, 0, dp(18));
        ImageView logo = new ImageView(this);
        setImageFromAsset(logo, "public/app-icon.png");
        brand.addView(logo, new LinearLayout.LayoutParams(dp(70), dp(70)));
        TextView name = tv("Gdzie...\\nz Dzieckiem", 32, TEXT_COLOR, Typeface.BOLD);
        name.setLineSpacing(0, 0.92f);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        nameLp.leftMargin = dp(14);
        brand.addView(name, nameLp);
        page.addView(brand);

        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        View heroBanner = landscape ? createLandscapeHomeHero() : createPortraitHomeHero();
        int heroHeight = dp(154);
        if (landscape) {
            int availableWidth = Math.max(dp(320), getResources().getDisplayMetrics().widthPixels - dp(32));
            heroHeight = Math.min(dp(220), Math.max(dp(154), Math.round(availableWidth * 653f / 1536f)));
        }
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, heroHeight);
        page.addView(heroBanner, heroLp);

        TextView actionsTitle = tv("Szybkie akcje", 29, Color.rgb(62, 62, 68), Typeface.BOLD);
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sectionLp.topMargin = dp(26);
        sectionLp.bottomMargin = dp(12);
        page.addView(actionsTitle, sectionLp);

        page.addView(wideMapButton());

        LinearLayout row1 = row();
        row1.addView(actionCard("Na powietrzu", "Place zabaw, parki,\\nszlaki i więcej", "🌲", Color.rgb(222, 243, 216), OUTDOOR_URL), weightCardLp(true));
        row1.addView(actionCard("Pod dachem", "Muzea, centra zabaw,\\nwarsztaty i więcej", "🏠", Color.rgb(217, 236, 251), INDOOR_URL), weightCardLp(false));
        page.addView(row1);

        LinearLayout row2 = row();
        row2.addView(actionCard("Superblog", "Inspiracje, porady\\ni relacje z miejsc", "✏️", Color.rgb(233, 221, 255), BLOG_URL), weightCardLp(true));
        row2.addView(actionCard("Dodaj miejsce", "Podziel się swoim\\nulubionym miejscem", "+", Color.rgb(255, 240, 182), ADD_URL), weightCardLp(false));
        page.addView(row2);

        addPlaceSection(page, "Ulubione", "Zobacz wszystkie ›", FAVORITES_KEY, true);
        addPlaceSection(page, "Ostatnio oglądane", "Więcej ›", RECENT_KEY, false);

        TextView version = tv("v2.10.5", 12, Color.rgb(160, 160, 160), Typeface.NORMAL);
        version.setGravity(Gravity.CENTER);
        page.addView(version, topMarginLp(12));

        TextView copyright = tv("© 2026 Gdzie z dzieckiem. Wszystkie prawa zastrzeżone.", 11, Color.rgb(160, 160, 160), Typeface.NORMAL);
        copyright.setGravity(Gravity.CENTER);
        copyright.setPadding(dp(16), dp(2), dp(16), dp(16));
        page.addView(copyright);

        return scroll;
    }

    private View wideMapButton() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(16));
        box.setBackground(round(Color.rgb(7, 112, 222), 24));
        box.setClickable(true);
        box.setOnClickListener(v -> openWebUrlReset(MAP_URL));

        TextView icon = tv("🗺️", 44, Color.WHITE, Typeface.NORMAL);
        box.addView(icon, new LinearLayout.LayoutParams(dp(86), ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView title = tv("Wyszukaj atrakcje", 28, Color.WHITE, Typeface.BOLD);
        TextView sub = tv("Odkrywaj ciekawe miejsca\\nw okolicy", 18, Color.WHITE, Typeface.NORMAL);
        texts.addView(title);
        texts.addView(sub);
        box.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView arrow = tv("›", 42, Color.argb(185, 255, 255, 255), Typeface.NORMAL);
        box.addView(arrow);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(112));
        lp.bottomMargin = dp(14);
        box.setLayoutParams(lp);
        return box;
    }

    private LinearLayout actionCard(String title, String sub, String iconText, int iconBg, String url) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(30), dp(12));
        card.setBackground(round(Color.WHITE, 24));
        card.setClickable(true);
        card.setOnClickListener(v -> openWebUrl(url, true));

        TextView icon = tv(iconText, iconText.equals("+") ? 38 : 28, Color.rgb(30, 30, 30), Typeface.NORMAL);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(iconBg, 999));
        card.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));

        TextView t = tv(title, 20, TEXT_COLOR, Typeface.BOLD);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tLp.topMargin = dp(14);
        card.addView(t, tLp);

        TextView s = tv(sub, 15, MUTED_COLOR, Typeface.NORMAL);
        card.addView(s);

        TextView arrow = tv("›", 36, Color.rgb(126, 126, 135), Typeface.NORMAL);
        arrow.setGravity(Gravity.RIGHT);
        card.addView(arrow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return card;
    }

    private void addPlaceSection(LinearLayout page, String title, String link, String key, boolean favorites) {
        ArrayList<Place> items = getPlaces(key);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setOrientation(LinearLayout.HORIZONTAL);
        TextView h = tv(title, 28, Color.rgb(62, 62, 68), Typeface.BOLD);
        head.addView(h, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView l = tv(link, 18, Color.rgb(20, 118, 212), Typeface.BOLD);
        l.setGravity(Gravity.RIGHT);
        l.setOnClickListener(v -> showListScreen(favorites ? "favorites" : "recent"));
        head.addView(l);
        LinearLayout.LayoutParams headLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        headLp.topMargin = dp(28);
        headLp.bottomMargin = dp(12);
        page.addView(head, headLp);

        if (items.isEmpty()) {
            TextView empty = tv(favorites ? "Tu pojawią się Twoje ulubione miejsca." : "Tu pojawią się ostatnio oglądane miejsca.", 15, MUTED_COLOR, Typeface.NORMAL);
            empty.setPadding(dp(16), dp(14), dp(16), dp(14));
            empty.setBackground(round(Color.rgb(255, 249, 224), 18));
            page.addView(empty);
            return;
        }

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(row);
        int max = Math.min(3, items.size());
        for (int i = 0; i < max; i++) {
            Place p = items.get(i);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(162), dp(206));
            cp.rightMargin = dp(12);
            row.addView(placeCard(p, favorites), cp);
        }
        page.addView(hsv);
    }

    private View createPortraitHomeHero() {
        ImageView heroBanner = new ImageView(this);
        heroBanner.setScaleType(ImageView.ScaleType.FIT_XY);
        heroBanner.setAdjustViewBounds(false);
        heroBanner.setBackgroundColor(BRAND_COLOR);
        setImageFromAsset(heroBanner, "public/hero-banner.png");
        return heroBanner;
    }

    private View createLandscapeHomeHero() {
        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(round(BRAND_COLOR, 24));
        hero.setClipToOutline(true);

        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setAdjustViewBounds(false);
        setImageFromAsset(bg, "public/hero-art.png");
        hero.addView(bg, fullFrame());

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView h = tv("Co dziś robimy\\nz dzieckiem?", 28, Color.BLACK, Typeface.BOLD);
        h.setLineSpacing(0, 0.94f);
        h.setLetterSpacing(-0.02f);
        h.setMaxLines(2);
        h.setScaleX(0.97f);

        TextView s = tv("Znajdź atrakcje, miejsca\\ni pomysły na wspólny czas.", 16, Color.rgb(28, 28, 28), Typeface.NORMAL);
        s.setLineSpacing(0, 1.08f);
        s.setMaxLines(3);
        s.setScaleX(0.97f);

        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sLp.topMargin = dp(12);

        texts.addView(h);
        texts.addView(s, sLp);

        FrameLayout.LayoutParams textsLp = new FrameLayout.LayoutParams(dp(325), ViewGroup.LayoutParams.MATCH_PARENT);
        textsLp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
        textsLp.leftMargin = dp(26);
        hero.addView(texts, textsLp);

        return hero;
    }

    private View listHeroBanner(String title, String subtitle) {
        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(round(BRAND_COLOR, 24));
        hero.setClipToOutline(true);

        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setAdjustViewBounds(false);
        bg.setAlpha(1.0f);
        setImageFromAsset(bg, "public/hero-list-bg.png");
        hero.addView(bg, fullFrame());

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView h = tv(title, 27, Color.BLACK, Typeface.BOLD);
        h.setLineSpacing(0, 1.02f);
        h.setMaxLines(2);

        TextView s = tv(subtitle, 15, Color.BLACK, Typeface.NORMAL);
        s.setLineSpacing(0, 1.08f);
        s.setMaxLines(3);

        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sLp.topMargin = dp(10);

        texts.addView(h);
        texts.addView(s, sLp);

        FrameLayout.LayoutParams textsLp = new FrameLayout.LayoutParams(dp(315), ViewGroup.LayoutParams.MATCH_PARENT);
        textsLp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
        textsLp.leftMargin = dp(24);
        hero.addView(texts, textsLp);

        return hero;
    }

    private View placeCard(Place place, boolean showHeart) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(round(Color.WHITE, 20));
        card.setClickable(true);
        card.setOnClickListener(v -> openWebUrl(place.url, true));

        FrameLayout imageBox = new FrameLayout(this);
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundColor(Color.rgb(240, 240, 240));
        imageBox.addView(image, fullFrame());
        if (place.image != null && place.image.length() > 4) {
            setImageFromUrl(image, place.image);
        } else {
            TextView fallback = tv("🏰", 34, TEXT_COLOR, Typeface.NORMAL);
            fallback.setGravity(Gravity.CENTER);
            imageBox.addView(fallback, fullFrame());
        }
        if (showHeart) {
            TextView heart = tv("♥", 22, Color.rgb(255, 61, 79), Typeface.BOLD);
            heart.setGravity(Gravity.CENTER);
            heart.setBackground(round(Color.WHITE, 999));
            FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(dp(42), dp(42));
            hp.gravity = Gravity.RIGHT | Gravity.TOP;
            hp.setMargins(0, dp(8), dp(8), 0);
            imageBox.addView(heart, hp);
        }
        card.addView(imageBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(102)));

        TextView title = tv(place.title, 16, TEXT_COLOR, Typeface.BOLD);
        title.setMaxLines(2);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleLp.setMargins(dp(12), dp(12), dp(12), 0);
        card.addView(title, titleLp);

        TextView city = tv(place.city == null || place.city.length() == 0 ? "Otwórz miejsce" : place.city, 15, MUTED_COLOR, Typeface.NORMAL);
        city.setMaxLines(1);
        LinearLayout.LayoutParams cityLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cityLp.setMargins(dp(12), dp(8), dp(12), 0);
        card.addView(city, cityLp);

        return card;
    }

    private void showListScreen(String type) {
        mode = type;
        localReturnScreen = ("favorites".equals(type) || "recent".equals(type)) ? type : "";
        webView.setVisibility(View.GONE);
        loadingView.setVisibility(View.GONE);
        offlineView.setVisibility(View.GONE);
        if (homeView != null) homeView.setVisibility(View.GONE);
        hideFloatingActions();
        hideWebBackButton();

        if (localView != null) root.removeView(localView);
        boolean fav = "favorites".equals(type);
        ArrayList<Place> items = getPlaces(fav ? FAVORITES_KEY : RECENT_KEY);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(105));
        page.setBackgroundColor(Color.WHITE);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        View back = centeredBackButton(v -> showHome(), 48, Color.rgb(243, 244, 247));
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView title = tv(fav ? "Ulubione" : "Ostatnio oglądane", 28, TEXT_COLOR, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        titleLp.leftMargin = dp(12);
        top.addView(title, titleLp);
        page.addView(top);

        LinearLayout.LayoutParams listHeroLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(154));
        listHeroLp.topMargin = dp(16);
        page.addView(listHeroBanner(
                fav ? "Twoje ulubione\\nmiejsca" : "Ostatnio oglądane",
                fav ? "Wszystkie atrakcje, które\\nchcesz odwiedzić ponownie." : "Miejsca, które ostatnio\\nCię zainteresowały."
        ), listHeroLp);

        TextView clear = tv(fav ? "🗑  Wyczyść ulubione" : "🗑  Wyczyść ostatnio oglądane", 16, fav ? Color.rgb(239, 83, 80) : Color.rgb(240, 168, 0), Typeface.BOLD);
        clear.setGravity(Gravity.CENTER);
        clear.setPadding(dp(16), dp(13), dp(16), dp(13));
        clear.setBackground(roundStroke(Color.WHITE, fav ? Color.rgb(239, 83, 80) : BRAND_COLOR, 18, 1));
        clear.setClickable(true);
        clear.setOnClickListener(v -> {
            prefs.edit().putString(fav ? FAVORITES_KEY : RECENT_KEY, "[]").apply();
            showListScreen(type);
        });
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clearLp.topMargin = dp(16);
        clearLp.bottomMargin = dp(4);
        page.addView(clear, clearLp);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(18), 0, dp(18));
        scroll.addView(list);

        if (items.isEmpty()) {
            TextView empty = tv(fav ? "Nie masz jeszcze zapisanych miejsc." : "Nie masz jeszcze ostatnio oglądanych miejsc.", 16, MUTED_COLOR, Typeface.NORMAL);
            empty.setPadding(dp(16), dp(16), dp(16), dp(16));
            empty.setBackground(round(Color.rgb(255, 249, 224), 18));
            list.addView(empty);
        } else {
            for (Place p : items) {
                list.addView(listRow(p), bottomMarginLp(12));
            }
        }
        TextView listVersion = tv("v2.10.5", 12, Color.rgb(160, 160, 160), Typeface.NORMAL);
        listVersion.setGravity(Gravity.CENTER);
        list.addView(listVersion, topMarginLp(12));

        TextView listCopyright = tv("© 2026 Gdzie z dzieckiem. Wszystkie prawa zastrzeżone.", 11, Color.rgb(160, 160, 160), Typeface.NORMAL);
        listCopyright.setGravity(Gravity.CENTER);
        listCopyright.setPadding(dp(16), dp(2), dp(16), dp(16));
        list.addView(listCopyright);

        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        localView = page;
        root.addView(localView, fullFrame());
        showBottomNav(fav ? "favorites" : "");
        localView.bringToFront();
        if (bottomNav != null) bottomNav.bringToFront();
        showLocalBackButton();
    }

    private View listRow(Place p) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(10), dp(10), dp(10), dp(10));
        row.setBackground(round(Color.WHITE, 20));
        row.setClickable(true);
        row.setOnClickListener(v -> openWebUrl(p.url, true));

        ImageView img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(Color.rgb(240, 240, 240));
        if (p.image != null && p.image.length() > 4) setImageFromUrl(img, p.image);
        row.addView(img, new LinearLayout.LayoutParams(dp(80), dp(80)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView title = tv(p.title, 18, TEXT_COLOR, Typeface.BOLD);
        TextView city = tv(p.city == null ? "" : p.city, 15, MUTED_COLOR, Typeface.NORMAL);
        texts.addView(title);
        texts.addView(city);
        LinearLayout.LayoutParams textsLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        textsLp.leftMargin = dp(12);
        row.addView(texts, textsLp);
        return row;
    }

    private void showBottomNav(String active) {
        activeNav = active == null ? "" : active;
        if ("home".equals(mode)) {
            hideBottomNav();
            return;
        }
        if (bottomNav != null) root.removeView(bottomNav);

        bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setPadding(dp(4), dp(4), dp(4), dp(4));
        bottomNav.setBackground(round(Color.WHITE, 28));
        bottomNav.setElevation(dp(10));
        bottomNav.addView(navButton("start", "⌂", "Start"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        bottomNav.addView(navButton("map", "🗺️", "Wyszukaj"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        bottomNav.addView(navButton("favorites", "♡", "Ulubione"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        bottomNav.addView(navButton("add", "+", "Dodaj"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(74));
        lp.gravity = Gravity.BOTTOM;
        lp.leftMargin = dp(16);
        lp.rightMargin = dp(16);
        lp.bottomMargin = dp(10);
        root.addView(bottomNav, lp);
        bottomNav.bringToFront();
    }

    private View navButton(String key, String icon, String label) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);

        boolean isActive = key.equals(activeNav);
        box.setClickable(true);
        box.setEnabled(true);
        box.setFocusable(true);
        box.setAlpha(isActive ? 0.55f : 1.0f);

        int color = isActive ? BRAND_COLOR : Color.rgb(120, 124, 135);
        TextView i = tv(icon, 26, color, Typeface.BOLD);
        i.setGravity(Gravity.CENTER);
        i.setClickable(false);
        TextView l = tv(label, 12, color, Typeface.BOLD);
        l.setGravity(Gravity.CENTER);
        l.setClickable(false);
        box.addView(i);
        box.addView(l);

        if (isActive) {
            box.setOnClickListener(v -> {
                // consume only
            });
            box.setOnTouchListener((v, event) -> true);
        } else {
            box.setOnClickListener(v -> {
                if (key.equals(activeNav)) return;
                if ("start".equals(key)) showHome();
                else if ("map".equals(key)) openWebUrlReset(MAP_URL);
                else if ("favorites".equals(key)) { webHistory.clear(); showListScreen("favorites"); }
                else if ("add".equals(key)) openWebUrlReset(ADD_URL);
            });
        }

        return box;
    }

    private void hideBottomNav() {
        if (bottomNav != null) {
            root.removeView(bottomNav);
            bottomNav = null;
        }
    }

    private void renderFloatingActions() {
        hideFloatingActions();
        if (currentPlace == null || !"web".equals(mode)) return;

        floatingActions = new LinearLayout(this);
        floatingActions.setOrientation(LinearLayout.VERTICAL);
        floatingActions.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams heartLp = new LinearLayout.LayoutParams(dp(60), dp(60));
        heartLp.bottomMargin = dp(10);
        floatingActions.addView(favoriteFloatButton(), heartLp);
        floatingActions.addView(shareFloatButton(), new LinearLayout.LayoutParams(dp(60), dp(60)));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(66), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        lp.rightMargin = dp(18);
        lp.bottomMargin = dp(98);
        root.addView(floatingActions, lp);
        floatingActions.bringToFront();
    }

    private View favoriteFloatButton() {
        FrameLayout b = new FrameLayout(this);
        b.setBackground(roundStroke(Color.WHITE, Color.rgb(235, 235, 235), 999, 1));
        b.setElevation(0f);
        b.setClickable(true);
        b.setOnClickListener(v -> {
            if (currentPlace == null) return;
            toggleFavorite(currentPlace);
            renderFloatingActions();
        });

        boolean fav = isFavorite(currentPlace);
        TextView heart = tv(fav ? "♥" : "♡", 31, fav ? Color.rgb(255, 61, 79) : Color.BLACK, Typeface.BOLD);
        heart.setGravity(Gravity.CENTER);
        b.addView(heart, fullFrame());
        return b;
    }

    private View shareFloatButton() {
        FrameLayout b = new FrameLayout(this);
        b.setBackground(roundStroke(Color.WHITE, Color.rgb(235, 235, 235), 999, 1));
        b.setElevation(0f);
        b.setClickable(true);
        b.setOnClickListener(v -> {
            if (currentPlace != null) shareNative(currentPlace.title, currentPlace.url);
        });

        ShareIconView icon = new ShareIconView(this);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(37), dp(37));
        iconLp.gravity = Gravity.CENTER;
        b.addView(icon, iconLp);
        return b;
    }

    private class ShareIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ShareIconView(Context context) {
            super(context);
            setWillNotDraw(false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();

            float x1 = w * 0.30f;
            float y1 = h * 0.52f;
            float x2 = w * 0.70f;
            float y2 = h * 0.30f;
            float x3 = w * 0.70f;
            float y3 = h * 0.73f;
            float r = Math.max(dp(4), w * 0.115f);

            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(Math.max(dp(3), w * 0.09f));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawLine(x1, y1, x2, y2, paint);
            canvas.drawLine(x1, y1, x3, y3, paint);

            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x1, y1, r, paint);
            canvas.drawCircle(x2, y2, r, paint);
            canvas.drawCircle(x3, y3, r, paint);
        }
    }

    private View floatButton(String label, boolean heart) {
        TextView b = tv(label, 26, heart ? Color.rgb(255, 61, 79) : Color.rgb(20, 118, 212), Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(Color.WHITE, 999));
        b.setElevation(dp(8));
        b.setClickable(true);
        if (heart) {
            b.setOnClickListener(v -> {
                if (currentPlace == null) return;
                toggleFavorite(currentPlace);
                renderFloatingActions();
            });
        } else {
            b.setOnClickListener(v -> {
                if (currentPlace != null) shareNative(currentPlace.title, currentPlace.url);
            });
        }
        return b;
    }

    private void hideFloatingActions() {
        if (floatingActions != null) {
            root.removeView(floatingActions);
            floatingActions = null;
        }
    }

    private void showOffline() {
        mode = "offline";
        webView.setVisibility(View.GONE);
        if (homeView != null) homeView.setVisibility(View.GONE);
        if (localView != null) localView.setVisibility(View.GONE);
        loadingView.setVisibility(View.GONE);
        hideBottomNav();
        hideFloatingActions();
        hideWebBackButton();
        offlineView.setVisibility(View.VISIBLE);
        offlineView.bringToFront();
    }

    private View createLoadingView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.rgb(255, 253, 244));
        ProgressBar progress = new ProgressBar(this);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(44), dp(44));
        pp.bottomMargin = dp(22);
        layout.addView(progress, pp);
        ImageView icon = new ImageView(this);
        setImageFromAsset(icon, "public/app-icon.png");
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(84), dp(84));
        ip.bottomMargin = dp(16);
        layout.addView(icon, ip);
        TextView text = tv("Ładowanie...", 18, TEXT_COLOR, Typeface.BOLD);
        text.setGravity(Gravity.CENTER);
        layout.addView(text);
        return layout;
    }

    private View createOfflineView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(BRAND_COLOR);
        layout.setPadding(dp(24), dp(24), dp(24), dp(24));
        ImageView icon = new ImageView(this);
        setImageFromAsset(icon, "public/app-icon.png");
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(96), dp(96));
        ip.bottomMargin = dp(20);
        layout.addView(icon, ip);
        TextView msg = tv("Aplikacja do działania wymaga połączenia z Internetem.", 18, Color.rgb(31, 31, 31), Typeface.BOLD);
        msg.setGravity(Gravity.CENTER);
        layout.addView(msg);
        TextView retry = tv("Spróbuj ponownie", 16, TEXT_COLOR, Typeface.BOLD);
        retry.setGravity(Gravity.CENTER);
        retry.setPadding(dp(18), dp(12), dp(18), dp(12));
        retry.setBackground(round(Color.WHITE, 999));
        retry.setOnClickListener(v -> {
            if (isOnline()) showHome();
            else showOffline();
        });
        layout.addView(retry, topMarginLp(20));
        return layout;
    }

    private String loadNavigationStateScriptSource() {
        if (navigationStateScriptSource != null) return navigationStateScriptSource;
        try (InputStream input = getAssets().open("public/gzd-scroll-restore.js");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            navigationStateScriptSource = output.toString(StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
            navigationStateScriptSource = "";
        }
        return navigationStateScriptSource;
    }

    private void injectNavigationStateScript(Runnable completion) {
        if (webView == null) {
            if (completion != null) completion.run();
            return;
        }
        String source = loadNavigationStateScriptSource();
        if (source == null || source.length() == 0) {
            if (completion != null) completion.run();
            return;
        }
        try {
            webView.evaluateJavascript(source, value -> {
                if (completion != null) completion.run();
            });
        } catch (Exception ignored) {
            if (completion != null) completion.run();
        }
    }

    private void injectPageHelpers() {
        if (webView == null) return;

        String js =
            "(function(){try{" +
            "function abs(u){try{return new URL(u,location.href).href;}catch(e){return '';}}" +
            "function internal(u){try{var x=new URL(u,location.href);return (x.protocol==='http:'||x.protocol==='https:')&&(x.hostname==='gdziezdzieckiem.eu'||x.hostname==='www.gdziezdzieckiem.eu'||x.hostname.endsWith('.gdziezdzieckiem.eu')||x.hostname==='gdziezdzieckiem.pl'||x.hostname==='www.gdziezdzieckiem.pl'||x.hostname.endsWith('.gdziezdzieckiem.pl'));}catch(e){return false;}}" +
            "function openInApp(u){try{var x=abs(u);if(x){x=x.replace('https://www.gdziezdzieckiem.pl','https://gdziezdzieckiem.eu').replace('http://www.gdziezdzieckiem.pl','https://gdziezdzieckiem.eu').replace('https://gdziezdzieckiem.pl','https://gdziezdzieckiem.eu').replace('http://gdziezdzieckiem.pl','https://gdziezdzieckiem.eu').replace('https://www.gdziezdzieckiem.eu','https://gdziezdzieckiem.eu').replace('http://www.gdziezdzieckiem.eu','https://gdziezdzieckiem.eu');}if(x&&window.GZDNative&&window.GZDNative.openUrl){window.GZDNative.openUrl(x);return true;}}catch(e){}return false;}" +

            "if(!window.__gzdNativeWindowOpenV260){" +
            "window.__gzdNativeWindowOpenV260=true;" +
            "var oldOpen=window.open;" +
            "window.open=function(u,n,f){if(u&&internal(u)){openInApp(u);return null;}return oldOpen?oldOpen.apply(window,arguments):null;};" +
            "}" +

            "if(!window.__gzdNativeClickPatchV260){" +
            "window.__gzdNativeClickPatchV260=true;" +

            "document.addEventListener('click',function(ev){try{" +
            "var a=ev.target&&ev.target.closest?ev.target.closest('a[href]'):null;" +
            "if(!a)return;" +
            "var href=a.getAttribute('href')||'';" +
            "if(!href||href.charAt(0)==='#'||href.indexOf('javascript:')===0||href.indexOf('mailto:')===0||href.indexOf('tel:')===0)return;" +
            "var u=abs(href);" +
            "if(internal(u)&&!ev.defaultPrevented){" +
            "ev.preventDefault();" +
            "setTimeout(function(){openInApp(u);},0);" +
            "}" +
            "}catch(e){}},false);" +

            "document.addEventListener('submit',function(ev){try{" +
            "var f=ev.target;if(!f||!f.tagName||String(f.tagName).toLowerCase()!=='form')return;" +
            "if(ev.defaultPrevented)return;" +
            "var method=(f.getAttribute('method')||'GET').toUpperCase();" +
            "var action=abs(f.getAttribute('action')||location.href);" +
            "if(method==='GET'&&internal(action)){" +
            "ev.preventDefault();" +
            "var url=new URL(action);var fd=new FormData(f);" +
            "fd.forEach(function(v,k){if(v!==undefined&&v!==null&&String(v).length>0)url.searchParams.set(k,String(v));});" +
            "setTimeout(function(){openInApp(url.href);},0);" +
            "}" +
            "}catch(e){}},false);" +
            "}" +

            "document.querySelectorAll('a[href]').forEach(function(a){try{if(internal(a.href)){a.removeAttribute('target');a.setAttribute('data-gzd-internal','1');}}catch(e){}});" +
            "document.querySelectorAll('form').forEach(function(f){try{var action=abs(f.getAttribute('action')||location.href);if(internal(action)){f.removeAttribute('target');}}catch(e){}});" +

            "var el=document.getElementById('gzd-place-data');" +
            "if(el&&window.GZDNative&&window.GZDNative.placeData){window.GZDNative.placeData(el.textContent||'');}" +
            "var q='a[href*=\\\"play.google.com\\\"],a[href*=\\\"google.com/store/apps\\\"],img[src*=\\\"google-play\\\"],img[src*=\\\"googleplay\\\"],img[alt*=\\\"Google Play\\\" i],img[title*=\\\"Google Play\\\" i]';" +
            "document.querySelectorAll(q).forEach(function(e){var b=e.closest('a,button,div,section')||e;b.style.setProperty('display','none','important');});" +
            "if(location.hash&&location.hash!=='#brxe-qnovlp'){var id=decodeURIComponent(location.hash.slice(1));var t=document.getElementById(id)||document.querySelector(location.hash);if(t&&t.scrollIntoView){setTimeout(function(){t.scrollIntoView({block:'start'});},250);}}" +
            "}catch(e){}})();";

        webView.evaluateJavascript(js, null);
    }

    private void forceWebViewRedraw() {
        try {
            webView.requestLayout();
            webView.invalidate();
            root.invalidate();
            webView.setAlpha(0.995f);
            webView.postDelayed(() -> {
                try {
                    webView.setAlpha(1f);
                    webView.invalidate();
                } catch (Exception ignored) {}
            }, 90);
            webView.evaluateJavascript("try{document.body&&document.body.offsetHeight}catch(e){0}", null);
        } catch (Exception ignored) {}
    }

    private String navForUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            String path = uri.getPath() == null ? "" : uri.getPath();
            if (url.contains("#brxe-qnovlp")) return "map";
            if (path.equals("/dodaj-atrakcje/") || path.equals("/dodaj-atrakcje")) return "add";
            return "";
        } catch (Exception ignored) {
            return "";
        }
    }

    private Place parsePlace(String raw) {
        try {
            if (raw == null || raw.trim().length() == 0) return null;
            JSONObject obj = new JSONObject(raw);
            String type = clean(obj.optString("type", ""));
            if (!"place".equalsIgnoreCase(type)) return null;
            Place p = new Place();
            p.id = clean(obj.optString("id", ""));
            p.title = clean(obj.optString("title", ""));
            p.url = clean(obj.optString("url", ""));
            p.image = clean(obj.optString("image", ""));
            p.city = clean(obj.optString("city", ""));
            p.updatedAt = String.valueOf(System.currentTimeMillis());
            if (p.id.length() == 0 || p.title.length() == 0 || p.url.length() == 0) return null;
            if (isNonPlaceUrl(p.url)) return null;
            return p;
        } catch (Exception ignored) {
            return null;
        }
    }

    private boolean isNonPlaceUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            String path = uri.getPath() == null ? "" : uri.getPath().replaceAll("/$", "");
            if (path.equals("") || path.equals("/") || path.equals("/blog") || path.equals("/dodaj-atrakcje") || path.equals("/wszystkie-atrakcje")) return true;
            if (url.contains("_na_powietrzu") || url.contains("_pod_dachem")) return true;
        } catch (Exception ignored) {}
        return false;
    }

    private ArrayList<Place> getPlaces(String key) {
        ArrayList<Place> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                Place p = new Place();
                p.id = clean(obj.optString("id", ""));
                p.title = clean(obj.optString("title", ""));
                p.url = clean(obj.optString("url", ""));
                p.image = clean(obj.optString("image", ""));
                p.city = clean(obj.optString("city", ""));
                p.updatedAt = clean(obj.optString("updatedAt", ""));
                if (p.id.length() > 0 && p.title.length() > 0 && p.url.length() > 0 && !isNonPlaceUrl(p.url)) list.add(p);
            }
        } catch (Exception ignored) {}
        return list;
    }

    private void savePlaces(String key, ArrayList<Place> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Place p : list) arr.put(p.toJson());
            prefs.edit().putString(key, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void upsertPlace(String key, Place place, int max) {
        if (place == null) return;
        ArrayList<Place> list = getPlaces(key);
        ArrayList<Place> next = new ArrayList<>();
        next.add(place);
        for (Place p : list) {
            if (p.id.equals(place.id) || p.url.equals(place.url)) continue;
            next.add(p);
            if (next.size() >= max) break;
        }
        savePlaces(key, next);
    }

    private boolean isFavorite(Place place) {
        if (place == null) return false;
        for (Place p : getPlaces(FAVORITES_KEY)) {
            if (p.id.equals(place.id) || p.url.equals(place.url)) return true;
        }
        return false;
    }

    private void toggleFavorite(Place place) {
        if (place == null) return;
        ArrayList<Place> list = getPlaces(FAVORITES_KEY);
        ArrayList<Place> next = new ArrayList<>();
        boolean exists = false;
        for (Place p : list) {
            if (p.id.equals(place.id) || p.url.equals(place.url)) {
                exists = true;
                continue;
            }
            next.add(p);
        }
        if (!exists) next.add(0, place);
        while (next.size() > 100) next.remove(next.size() - 1);
        savePlaces(FAVORITES_KEY, next);
    }

    private void shareNative(String title, String url) {
        try {
            String safeTitle = title == null || title.length() == 0 ? "Gdzie z dzieckiem" : title;
            String safeUrl = url == null ? "" : url;
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, safeTitle);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Zobacz to miejsce w Gdzie z dzieckiem:\\n" + safeTitle + "\\n" + safeUrl);
            startActivity(Intent.createChooser(sendIntent, "Udostępnij miejsce"));
        } catch (Exception ignored) {}
    }

    private void handleSystemBack() {
        if ("home".equals(mode)) {
            long now = System.currentTimeMillis();
            if (now - lastBackPressAt < 2200) {
                finish();
            } else {
                lastBackPressAt = now;
                Toast.makeText(this, "Aby wyjść z aplikacji, naciśnij wstecz jeszcze raz", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if ("web".equals(mode) || "loading".equals(mode)) {
            loadPreviousWebPage();
            return;
        }

        if ("favorites".equals(mode) || "recent".equals(mode) || "offline".equals(mode)) {
            showHome();
            return;
        }

        showHome();
    }

    private void requestBackNavigation() {
        long now = System.currentTimeMillis();
        // Jeden gest Androida potrafi przejść jednocześnie przez KeyEvent oraz
        // onBackPressed/OnBackInvoked. Debounce gwarantuje dokładnie jeden krok.
        if (now - lastBackActionAt < 350) return;
        lastBackActionAt = now;
        handleSystemBack();
    }

    private void goHomeFromBack() {
        requestBackNavigation();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event != null && event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            // Zużyj również ACTION_DOWN, aby framework nie wywołał dodatkowo
            // onBackPressed dla tego samego fizycznego naciśnięcia.
            if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled()) {
                requestBackNavigation();
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        requestBackNavigation();
    }

    private void registerModernBackHandler() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(100000, () -> requestBackNavigation());
            } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (webView != null) {
                webView.onResume();
                webView.resumeTimers();
                if ("web".equals(mode) && isShowingWeb) {
                    forceWebViewRedraw();
                    injectPageHelpers();
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onPause() {
        try {
            if (webView != null) webView.onPause();
        } catch (Exception ignored) {}
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        locationPermissionRequestInFlight = false;
        resolvePendingGeolocationPermission(false);
        if (webView != null) {
            try { webView.destroy(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBaselineAligned(false);
        return row;
    }

    private LinearLayout.LayoutParams weightCardLp(boolean left) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(170), 1);
        lp.bottomMargin = dp(12);
        if (left) lp.rightMargin = dp(6);
        else lp.leftMargin = dp(6);
        return lp;
    }

    private LinearLayout.LayoutParams topMarginLp(int marginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(marginDp);
        return lp;
    }

    private LinearLayout.LayoutParams bottomMarginLp(int marginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(marginDp);
        return lp;
    }

    private TextView tv(String text, int sp, int color, int style) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(true);
        t.setTypeface(Typeface.DEFAULT, style);
        return t;
    }

    private GradientDrawable roundStroke(int fillColor, int strokeColor, int radiusDp, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fillColor);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private FrameLayout.LayoutParams fullFrame() {
        return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private String clean(String value) {
        return value == null ? "" : value.replaceAll("\\\\s+", " ").trim();
    }

    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
            return capabilities != null && (
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            );
        } catch (Exception ignored) {
            return true;
        }
    }

    private void applySystemBarInsets(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            view.setOnApplyWindowInsetsListener((v, insets) -> {
                int left = 0;
                int top;
                int right = 0;
                int bottom;
                boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                    top = bars.top;
                    bottom = bars.bottom;
                    if (landscape) {
                        android.graphics.Insets cutout = insets.getInsets(WindowInsets.Type.displayCutout());
                        android.graphics.Insets gestures = insets.getInsets(WindowInsets.Type.mandatorySystemGestures());
                        left = Math.max(bars.left, Math.max(cutout.left, gestures.left));
                        right = Math.max(bars.right, Math.max(cutout.right, gestures.right));
                    }
                } else {
                    top = insets.getSystemWindowInsetTop();
                    bottom = insets.getSystemWindowInsetBottom();
                    if (landscape) {
                        left = insets.getSystemWindowInsetLeft();
                        right = insets.getSystemWindowInsetRight();
                    }
                }
                v.setPadding(left, top, right, bottom);
                return insets;
            });
            view.requestApplyInsets();
        }
    }

    private void setImageFromAsset(ImageView imageView, String assetPath) {
        InputStream input = null;
        try {
            try {
                input = getAssets().open(assetPath);
            } catch (Exception first) {
                String fallback = assetPath == null ? "" : assetPath.replace("public/", "");
                input = getAssets().open(fallback);
            }
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            imageView.setImageBitmap(bitmap);
        } catch (Exception ignored) {
            imageView.setBackgroundColor(BRAND_COLOR);
        } finally {
            try {
                if (input != null) input.close();
            } catch (Exception ignored) {}
        }
    }

    private void setImageFromUrl(ImageView imageView, String imageUrl) {
        new Thread(() -> {
            try {
                HttpURLConnection connection = (HttpURLConnection) new URL(imageUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setInstanceFollowRedirects(true);
                Bitmap bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                if (bitmap != null) {
                    runOnUiThread(() -> imageView.setImageBitmap(bitmap));
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void openExternalIntent(Uri uri) {
        try {
            if (uri != null && isInternalGzdUrl(uri.toString())) {
                navigateToUrl(uri.toString(), true);
                return;
            }
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {}
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
`;

fs.writeFileSync(mainActivityPath, mainActivity);

// Safety cleanup: never allow the old broken emoji decoration block to reach Java compilation.
let generatedMainActivity = fs.readFileSync(mainActivityPath, 'utf8');
generatedMainActivity = generatedMainActivity.replace(/TextView decoration = tv\("[\s\S]*?hero\.addView\(decoration, decoLp\);\n/g, '');
generatedMainActivity = generatedMainActivity.replace(/TextView decoration = tv\("[\s\S]*?👧[\s\S]*?hero\.addView\(decoration, decoLp\);\n/g, '');
generatedMainActivity = generatedMainActivity.replace(/TextView decoration = tv\("[\s\S]*?[\s\S]*?hero\.addView\(decoration, decoLp\);\n/g, '');
fs.writeFileSync(mainActivityPath, generatedMainActivity);

console.log('Android: v2.10.5 - deterministyczny stos URL, pojedynczy Wstecz i trwałe odtwarzanie listy.');
