# Gdzie z dzieckiem v2.5.0

Poprawka otwierania linków w aplikacji:
- dodano obsługę Android App Links dla `gdziezdzieckiem.eu`;
- linki otwierane z popupów, breadcrumbów i formularzy nie powinny już wychodzić do zewnętrznej przeglądarki;
- przechwytywane są `target="_blank"` i `window.open`;
- usunięto zbyt agresywne przechwytywanie kliknięć JS, żeby popupy strony mogły normalnie się pokazywać.
