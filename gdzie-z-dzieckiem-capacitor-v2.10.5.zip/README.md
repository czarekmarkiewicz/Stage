# Gdzie z dzieckiem — aplikacja mobilna

Wersja: 2.10.5

## Co jest w tej wersji

- Nowy aplikacyjny ekran startowy.
- Dolna nawigacja: Start, Mapa, Blog, Ulubione, Więcej.
- Lokalnie zapisywane Ulubione.
- Lokalnie zapisywane Ostatnio oglądane.
- Serduszko widoczne tylko na stronie konkretnej atrakcji.
- Natywne udostępnianie atrakcji.
- Ukrywanie odniesień do Google Play w aplikacji.
- Dopracowany ekran offline.
- Android i iOS korzystają z tej samej warstwy `gzd-app-ui.js`.

## Ważne przed buildem

Na stronie atrakcji musi działać blok danych:

```html
<script type="application/json" id="gzd-place-data">...</script>
```

Aplikacja korzysta z niego do Ulubionych i Ostatnio oglądanych.

## Pierwsze przygotowanie projektu

```bash
npm install
npx cap add android
npx cap add ios
npm run sync
```

Jeśli foldery `android` i `ios` już istnieją:

```bash
npm install
npm run sync
```

## Android debug APK

```bash
npm run apk:debug
```

Plik będzie tutaj:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Android release AAB

```bash
npm run aab:release
```

Plik będzie tutaj:

```text
android/app/build/outputs/bundle/release/app-release.aab
```

Wersja release wymaga wcześniej poprawnie skonfigurowanego podpisu w `android/keystore.properties`.

## iOS

Lokalnie na Macu:

```bash
npm run ios
```

W Codemagic:

```bash
npm install
npm run build
npx cap sync ios
node scripts/patch-ios.js
```

Potem build IPA standardowym workflow Codemagic.

## Co robią skrypty

### `src/gzd-app-ui.js`

To główna warstwa aplikacyjna:

- ekran startowy,
- dolna nawigacja,
- Ulubione,
- Ostatnio oglądane,
- serduszko,
- udostępnianie,
- ukrywanie Google Play.

### `scripts/patch-android.js`

Po `npx cap sync` zastępuje Android `MainActivity.java` natywną pseudo-przeglądarką WebView i wstrzykuje `gzd-app-ui.js` do strony.

### `scripts/patch-ios.js`

Po `npx cap sync ios` dopisuje `GZDViewController` do `AppDelegate.swift`, przełącza storyboard na ten kontroler, wstrzykuje `gzd-app-ui.js` do WKWebView, obsługuje natywne udostępnianie i ustawia `ITSAppUsesNonExemptEncryption=false`.

## Test po instalacji

1. Uruchom aplikację z internetem.
2. Powinien pojawić się nowy ekran startowy aplikacji.
3. Kliknij „Wyszukaj na mapie”, „Na powietrzu”, „Pod dachem”, „Superblog” i „Dodaj miejsce”.
4. Wejdź w konkretną atrakcję.
5. Powinny pojawić się pływające przyciski: serduszko i udostępnianie.
6. Kliknij serduszko — atrakcja powinna trafić do Ulubionych.
7. Wróć na Start — sekcja Ulubione powinna pokazać zapisane miejsce.
8. Wejdź w kilka atrakcji — sekcja Ostatnio oglądane powinna pokazać ostatnie miejsca.
9. Wyłącz internet i uruchom aplikację — powinien pojawić się ekran offline.
