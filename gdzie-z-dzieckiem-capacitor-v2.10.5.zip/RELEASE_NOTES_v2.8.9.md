# Gdzie z dzieckiem v2.8.9

Poprawki iPhone/iPad:
- UI aplikacji nie jest już wstrzykiwane do iframe, więc na „Dodaj atrakcję” nie powinien pojawiać się drugi pasek nawigacji w edytorze opisu;
- dodano dodatkowy guard JS `window.top !== window.self`, żeby iframe nie dostały Start/Nav/Favorites;
- zwiększono górny odstęp ekranu Start i ekranów lokalnych pod Dynamic Island / notch;
- poprawiono serduszko na symetryczną ikonę i wymuszono centrowanie w białym kółku;
- poprawiono kafelki Ulubione na ekranie Start, żeby obraz był nad tekstem jak w Ostatnio oglądane;
- dodano osobną obsługę mapy: hash `#brxe-qnovlp` jest ustawiany jako `location.hash`, scroll jest powtarzany, a iOS ma natywną obsługę mapowego URL;
- panel udostępniania ma blokadę przed podwójnym uruchomieniem i preferuje jeden natywny mostek.

Android:
- zachowano poprawki splash, wstecz i dotychczasowy układ.
