# Gdzie z dzieckiem v2.8.10

Naprawione:
- kliknięcie „Wyszukaj na mapie” oraz ikony Mapa ładuje dokładny URL `https://gdziezdzieckiem.eu/#brxe-qnovlp`;
- iOS nie używa już skrótu JS, który zostawiał stronę główną na górze;
- po załadowaniu URL z mapą iOS ponawia scroll do mapy oraz odświeża Leaflet;
- z ekranów „Ulubione” i „Ostatnio oglądane” usunięto niepotrzebne szare kółko / przycisk wstecz;
- kafelki Ulubione na ekranie Start mają inline wymuszony układ: obraz na górze, tekst pod spodem;
- serduszko jest wymienione na symetryczny SVG i dodatkowo centrowane w białym kółku;
- UI aplikacji jest nadal blokowane w iframe (`window.top !== window.self`) i iOS używa `forMainFrameOnly: true`;
- panel udostępniania ma blokadę przed podwójnym otwarciem.
