# Gdzie z dzieckiem v2.8.22

Naprawione:
- iPhone: powrót z mapy na ekran Start jest maskowany krótką osłoną, aby nie było widać renderowania na dole i przewijania do góry;
- iPhone: przed renderem Startu po mapie zerowany jest `WKWebView.scrollView.contentOffset`;
- iPhone: po renderze Startu zerowany jest także `window.scrollTo`, `documentElement.scrollTop`, `body.scrollTop` i `.gzd-home.scrollTop`;
- iPhone: osłona znika dopiero po ustawieniu Startu na górze;
- zachowano wszystkie wcześniejsze poprawki: ograniczony dół Startu, pasek notch, map offset 70 px, loading mapy, reset ścieżki Wstecz.
