# Gdzie z dzieckiem v2.8.3

Splash screen:
- dodano kontrolowany overlay splash po starcie aplikacji;
- splash trwa minimum 1 sekundę;
- splash jest automatycznie zdejmowany najpóźniej po 5 sekundach;
- działa na Androidzie;
- działa na iPhone/iPad;
- zachowano natywne mechanizmy splash: Android Theme.SplashScreen oraz iOS LaunchScreen.storyboard.
