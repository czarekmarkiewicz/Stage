# Gdzie z dzieckiem v2.6.0

Poprawka linków wewnętrznych:
- linki do `gdziezdzieckiem.eu` są przechwytywane po skryptach strony;
- popupy strony powinny nadal normalnie się pokazywać;
- breadcrumbs i linki wewnętrzne powinny zostać w aplikacji;
- formularze GET, np. przycisk „Szukaj” pod mapą, powinny zostać w aplikacji;
- helper JS jest wstrzykiwany kilka razy po załadowaniu strony, żeby objąć elementy dodane dynamicznie.
