# Gdzie z dzieckiem v2.8.35

## Android: stabilne cofanie z atrakcji do listy

- Android nie używa już `WebView.goBack()` ani natywnego stosu historii WebView. Jedynym źródłem prawdy jest jawny stos URL aplikacji (`webHistory`);
- powrót ładuje poprzedni URL deterministycznie i uruchamia istniejący mechanizm kotwicy, który doładowuje listę tylko do chwili znalezienia zapisanej atrakcji;
- natywna historia WebView jest czyszczona po każdym zakończonym ładowaniu, więc nie pozostają w niej wielokrotne wpisy tej samej atrakcji;
- systemowy Wstecz, pływający przycisk Wstecz i wywołanie z JavaScript przechodzą przez jeden, wspólny mechanizm z blokadą wielokrotnego wykonania;
- Android zużywa zarówno `ACTION_DOWN`, jak i `ACTION_UP`, dzięki czemu pojedyncze naciśnięcie nie wykonuje jednocześnie `dispatchKeyEvent` i `onBackPressed`;
- kolejne cofnięcie jest blokowane do zakończenia ładowania poprzedniej strony, co zapobiega pomijaniu listy i przechodzeniu od razu na ekran startowy;
- każda komenda nawigacji ma identyfikator. Spóźnione callbacki `evaluateJavascript` z wcześniejszej atrakcji są ignorowane;
- po przejściu na ekran startowy stary dokument WebView jest zatrzymywany i zastępowany `about:blank`; opóźnione przekierowania, `window.open` i wywołania mostka ze starej atrakcji nie mogą ponownie otworzyć jej nad ekranem startowym;
- ukryty WebView nie może inicjować nawigacji, dlatego przyciski ekranu startowego zachowują przypisane im akcje.

## Przywracanie miejsca na liście

- zachowany został mechanizm z wersji 2.8.34: zapis konkretnej atrakcji jako kotwicy, progresywne doładowywanie porcji listy i ustawienie kotwicy w zapamiętanym miejscu ekranu;
- lista nie jest ładowana w całości — doładowywanie kończy się po znalezieniu kotwicy albo po osiągnięciu limitu bezpieczeństwa;
- iOS zachowuje działający mechanizm cofania z wersji 2.8.34.

## Pozostałe informacje

- wersja aplikacji: **2.8.35**;
- poprawki poziomego układu i bezpiecznych obszarów pozostają bez zmian;
- nie wprowadzono zmian w układzie widoków pionowych.
