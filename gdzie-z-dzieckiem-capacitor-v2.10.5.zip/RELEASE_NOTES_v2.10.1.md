# Gdzie z dzieckiem v2.10.1

## Android API 37

- ustawiono `compileSdkVersion` i `targetSdkVersion` na **37**,
- zaktualizowano Android Gradle Plugin do **9.2.1** oraz Gradle Wrapper do **9.5.1**,
- zachowano stabilną linię Capacitor **7.x** i dotychczasowy `minSdkVersion` **23**,
- dodano automatyczną konfigurację i test wygenerowanego projektu Android w Codemagic,
- nie wprowadzono zmian funkcjonalnych w aplikacji ani w obsłudze iOS.

Wersja aplikacji: **2.10.1**.
