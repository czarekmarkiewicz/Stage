# Gdzie z dzieckiem v2.9.0

## Lokalizacja użytkownika

- Android WebView obsługuje żądania `navigator.geolocation` po kliknięciu funkcji „Zlokalizuj mnie”;
- dodano uprawnienia `ACCESS_COARSE_LOCATION` i `ACCESS_FINE_LOCATION` oraz systemowy dialog runtime;
- dostęp jest przyznawany wyłącznie zaufanym domenom `gdziezdzieckiem.eu` i `gdziezdzieckiem.pl` przez HTTPS;
- aplikacja akceptuje zarówno lokalizację dokładną, jak i przybliżoną;
- iOS otrzymał `NSLocationWhenInUseUsageDescription`, dzięki czemu WKWebView może poprosić o lokalizację podczas używania aplikacji;
- aplikacja nie prosi o lokalizację w tle i nie żąda jej automatycznie przy starcie;
- dodano testy regresyjne sprawdzające konfigurację lokalizacji w patchach oraz wygenerowanych projektach natywnych.
- poprawiono generator Androida: scalono zdublowane metody `onDestroy()`, które zatrzymywały kompilację `compileReleaseJavaWithJavac`;
- dodano test regresyjny wymagający dokładnie jednej metody `onDestroy()` w wygenerowanym `MainActivity.java`.

Wersja aplikacji: **2.9.0**.
