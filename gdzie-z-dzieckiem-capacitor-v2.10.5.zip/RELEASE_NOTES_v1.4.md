# Gdzie z dzieckiem v1.4.0

Poprawki po testach Android:

- poprawione kliknięcia kafelków i dolnej nawigacji,
- przycisk Start z dolnego paska wraca do natywnego ekranu startowego aplikacji,
- dodany natywny mostek Android do stabilnego otwierania adresów w WebView,
- poprawione ponowne inicjalizowanie warstwy aplikacyjnej po przejściu między stronami,
- poprawiony układ kafelków szybkich akcji na wąskich ekranach,
- zmieniona grafika na żółtym banerze na delikatniejszą ilustrację w stylu makiety,
- historia „Ostatnio oglądane” dalej zapisuje tylko miejsca z gzd-place-data type=place.
