# Gdzie z dzieckiem v2.8.31

Poprawione:
- Android i iPhone/Web UI: na ekranie Ostatnio oglądane przycisk Start z dolnej nawigacji nie jest już aktywny/wyłączony i powinien wracać do Startu;
- Android i iPhone/Web UI: na niebieskim banerze Start zmieniono „Wyszukaj na mapie” na „Wyszukaj atrakcje”;
- Android i iPhone/Web UI: w dolnej nawigacji zmieniono „Mapa” na „Wyszukaj”;
- URL mapy i logika przewijania do mapy pozostają bez zmian.
