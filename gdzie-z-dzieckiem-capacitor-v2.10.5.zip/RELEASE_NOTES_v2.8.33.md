# Gdzie z dzieckiem v2.8.33

- podniesiono wersję aplikacji z 2.8.32 do 2.8.33;
- Android: w orientacji poziomej baner startowy zachowuje proporcje, więc tekst i grafika nie są rozciągane;
- Android: uwzględniane są lewe i prawe wcięcia systemowe, wycięcie ekranu oraz obszar nawigacji gestami;
- iOS/WebView: dodano poziome bezpieczne marginesy zależne od natywnych safe area;
- Android i iOS: Wstecz korzysta z natywnej historii WebView/WKWebView zamiast ponownie ładować poprzedni adres;
- dodano zapamiętywanie pozycji przewijania w sessionStorage oraz przywracanie jej jako zabezpieczenie, gdy system musi odtworzyć stronę;
- poprawki orientacji są ograniczone do widoku poziomego — układ pionowy pozostaje bez zmian.
