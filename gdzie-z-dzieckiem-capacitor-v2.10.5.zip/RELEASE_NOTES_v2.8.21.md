# Gdzie z dzieckiem v2.8.21

Naprawione:
- iPhone: przywrócono pasek zakrywający treści pod notch na ekranie Start;
- iPhone: pasek notch jest sticky wewnątrz kontenera Startu i nie powinien przykrywać logo przy normalnym położeniu;
- iPhone: ograniczono dolny scroll Startu — zostaje tylko mały margines pod ostatnią treścią, bez prawie pustego ekranu;
- iPhone: powrót ze strony mapy na Start zeruje scroll przed renderowaniem ekranu Start, aby nie było widocznego przewijania z dołu do góry;
- iPhone: natywne WKWebView też zeruje contentOffset przed renderem Startu;
- iPhone: offset mapy zmniejszony z 92 px do 70 px, bliżej wskazanej czerwonej linii;
- zachowano: natywny loading mapy, reset ścieżki Wstecz, aktywny guzik dolnej nawigacji disabled na Android/iOS.
