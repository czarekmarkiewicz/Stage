# Gdzie z dzieckiem v2.8.5

Poprawki iPhone/iPad:
- start screen nie powinien już pokazywać przez chwilę webowej strony/przeglądarki po splash screenie;
- splash czeka aż ekran aplikacji zostanie wyrenderowany;
- dodano górny żółty pasek pod status bar / notch;
- dodano grafikę w żółtym banerze startowym;
- dodano żółte banery z grafiką na ekranach „Ulubione” i „Ostatnio oglądane”;
- poprawiono wyśrodkowanie ikon „Ulubione” i „Udostępnij” w białych kółkach;
- na stronie „Dodaj atrakcję” wrócił dolny pasek nawigacji;
- dodano przycisk „Wstecz” dla stron webowych, przydatny na iPhone i Androidach z gestami.

Android:
- dodano obsługę `GZDNative.goBack()` dla dodatkowego przycisku wstecz;
- zachowano splash screen minimum 1s / maksimum 5s.
