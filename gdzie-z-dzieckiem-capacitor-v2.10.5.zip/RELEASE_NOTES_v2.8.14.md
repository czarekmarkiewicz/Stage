# Gdzie z dzieckiem v2.8.14

Naprawione:
- krytyczna poprawka kliknięć na ekranie Start;
- usunięto wysyłanie prefiksu `gzd-reset:` z JS, bo mogło powodować wiszący ekran ładowania, jeżeli natywny mostek nie zareagował;
- nawigacja z ekranu Start ma fallback: jeśli native bridge nie przeładuje strony, po 900 ms uruchamia się `window.location.assign()`;
- nadpisano `bindAppRootClicks` czystą wersją, bez zduplikowanych replacementów;
- dekoracyjne warstwy Start/hero/safe-area nie przechwytują kliknięć;
- zachowano: Wstecz na Ulubione/Ostatnio, wyłączony bounce i scroll Start do góry.
